# REPORT.md — отчёт совета (этап 4 протокола)

Статистика: {"запросов_раунд1": 653, "запросов_раунд2_по_ходу": 283, "доля_по_ходу": 30.2, "исполнителей_раунд1": 30, "исполнителей_раунд2": 30, "руководителей_план": 10, "руководителей_разбор": 10, "голосов": 10, "результатов_раунд1": 4074, "результатов_раунд2": 304, "с_rel>=2": 2369}

## Рейтинг кандидатов (голосование 10 руководителей, очки Борда 3-2-1)

- **Context Compression & Summarization** (очков 26; руководители: L1, L3, L4) — Compress long context into summaries or summaries-as-messages to fit limits while preserving rules.
  источники: https://arxiv.org/html/2608.22752v1; https://github.com/Fr-e-d/ai-dev-assistant-framework; https://github.com/NousResearch/hermes-agent/issues/22244; https://github.com/NousResearch/hermes-agent/issues/38392
- **Agent Memory Persistence** (очков 22; руководители: L1, L3, L8) — Persist agent memory across sessions using vector+graph DBs or file-based backends. Apply to keep rules and dialogue intact.
  источники: https://github.com/DarkMatterCompiler/agentkv; https://github.com/NevaMind-AI/memU; https://github.com/can1357/oh-my-pi/pull/18755
- **Open-Source Agent Runtime** (очков 6; руководители: L3) — Use YAML-first or framework-agnostic runtimes to orchestrate agents with minimal custom code.
  источники: https://github.com/NikoSokratous/agentctl; https://github.com/TencentCloud/CubeSandbox; https://www.gitagent.sh/
- **Rule Enforcement & CI Checks** (очков 5; руководители: L1, L3, L4) — Automate rule compliance via CI pipelines or pre/post hooks to prevent violations.
  источники: https://doi.org/10.1007/978-3-032-22375-3_10; https://github.com/peterdays/flagoria/issues/5; https://www.incode.com/agentic-fraud-guide/; https://www.token.security/blog/agentic-ai-attack-vectors-emerging-threats-and-defense-strategies
- **Long-Term Memory Management** (очков 1; руководители: L1, L3) — Compact or archive long-lived conversations to extend context beyond window limits.
  источники: https://arxiv.org/html/2608.22752v1; https://github.com/colthreepv/openchamber/issues/2
- **Semantic Layer & Knowledge Graph** (очков 0; руководители: L3) — Build semantic layers over data to enable efficient retrieval and reasoning.
  источники: https://news.ycombinator.com/item?id=46452014
- **Memory Leak Detection** (очков 0; руководители: L10, L9) — Track peak memory usage of external commands to identify leaks in agent processes.
  источники: https://github.com/can1357/oh-my-pi/issues/19794; https://github.com/kubernetes/kubernetes/issues/139823; https://github.com/orgs/community/discussions/163309; https://support.mozilla.org/en-US/questions/1230632?page=2
- **Pre-Compact Hooks** (очков 0; руководители: L3) — Inject hooks before compression to ensure rule compliance and context integrity.
  источники: https://github.com/razvanneculai/litecode
- **Governance Layer Separation** (очков 0; руководители: L4) — Separate foundational models from governance to enforce rules at higher level.
  источники: https://news.ycombinator.com/item?id=42914867
- **Multi-Agent Team Coordination** (очков 0; руководители: L4) — Apply portfolio theory or team orchestration for high-consequence scenarios.
  источники: https://www.mnemom.ai/showcase

## Отчёт секретаря

**ЧАСТЬ A – Отчёт по протоколу заказчика (ЭТАП 4)**  

| Кандидат | Что дал | Что внедрить / отвергнуть | Причина |
|----------|---------|--------------------------|---------|
| **S2 – Context Compression & Summarization** | Сжимает длинный контекст в краткие резюме, сохраняя правила. | **Внедрить** – использовать существующий подход из `https://arxiv.org/html/2608.22752v1` и репозитория `https://github.com/Fr-e-d/ai-dev-assistant-framework`. | Документированно работает в рамках ограничений памяти и не требует изменения системного промта. |
| **S1 – Agent Memory Persistence** | Хранит память агента в векторно‑графовой БД или файловой системе. | **Внедрить** – использовать `https://github.com/DarkMatterCompiler/agentkv` или `https://github.com/NevaMind-AI/memU`. | Позволяет сохранять правила между сессиями без изменения промта. |
| **S5 – Open‑Source Agent Runtime** | YAML‑первый, без кастомного кода, оркеструет агентов. | **Отвергнуть** – не решает проблему памяти/правил напрямую и не подходит к текущему bash‑режиму. |
| **S3 – Rule Enforcement & CI Checks** | Автоматизирует проверку соблюдения правил через CI. | **Внедрить** – добавить CI‑проверки, основанные на `https://doi.org/10.1007/978-3-032-22375-3_10`. | Обеспечивает внешнюю детерминированную проверку, не меняя промта. |
| **S7 – Long‑Term Memory Management** | Архивирует долгосрочные разговоры. | **Отвергнуть** – не решает проблему потери правил при сжатии контекста. |
| **S4 – Semantic Layer & Knowledge Graph** | Создаёт семантический слой для поиска. | **Отвергнуть** – не предоставляет готового решения памяти/правил. |
| **S6 – Memory Leak Detection** | Отслеживает потребление памяти внешних команд. | **Отвергнуть** – не устраняет потерю правил, а лишь диагностирует утечки. |
| **S8 – Pre‑Compact Hooks** | Инжектирует хуки перед сжатием. | **Отвергнуть** – в Arena отсутствуют хуки, а решение не проверено. |
| **S9 – Governance Layer Separation** | Разделяет модели и управление. | **Отвергнуть** – не решает конкретную проблему памяти/правил. |
| **S10 – Multi‑Agent Team Coordination** | Координация команд агентов. | **Отвергнуть** – не относится к памяти/правилам. |

**Итог:**  
Для решения проблемы памяти и сохранения 108 правил в текущей среде (bash‑режим, без хуков, неизменяемый системный промт) следует **внедрить** решения из **S2** (сжатие контекста без потери правил) и **S1** (постоянное хранение памяти). Дополнительно рекомендуется добавить **S3** (CI‑проверки соблюдения правил) для внешней детерминированной проверки. Остальные кандидаты не дают готового решения в рамках заданных ограничений.

**ЧАСТЬ B – Отчёт по протоколу заказчика (ЭТАП 4)**  

1. **«Границы возможного» – что принципиально нельзя при этих условиях**  
   - Сжатие контекста платформой стирает постоянные правила пользователя (H1).  
   - Невозможно изменить системный промт или добавить хуки платформы.  
   - Нельзя запускать внешние сервисы, которые не находятся в рабочей папке (Telegram‑хранилище, веб‑поиск, bash).  
   - Нельзя использовать сторонние библиотеки, не входящие в std‑lib Python.  

2. **«Что делать, если не заработало» – 4–6 конкретных запасных шагов**  
   1. Сохраняйте правила в отдельный файл `rules.txt` и загружайте его в начале каждого диалога; убедитесь, что файл не попадает в сжатие.  
   2. После каждой сжатой сессии проверяйте, что `rules.txt` всё ещё присутствует в памяти, иначе перезапустите агент с тем же файлом.  
   3. При обнаружении потери правил запустите скрипт `check_rules.py`, который сравнивает текущий контекст с оригиналом из `rules.txt`.  
   4. Если `check_rules.py` обнаружит нарушение, автоматически откатитесь к последнему сохранённому состоянию (snapshot) и повторите запрос.  
   5. При повторных потерях правил включите режим «только чтение» для `rules.txt` и ограничьте количество сообщений в диалоге до 200, чтобы снизить нагрузку на сжатие.  
   6. Если всё равно возникают потери, переключитесь на режим «постоянный файл» – сохраняйте каждый ответ в отдельный файл и объединяйте их только при необходимости.  

3. **«Что осталось неясным» – по вердиктам unclear**  
   - Какой вес имеют правила, сохранённые в файле, по сравнению с правилами, размещёнными в сообщениях пользователя или в конце контекста.  
   - Почему запреты («не делай X») исчезают быстрее, чем положительные процедуры («делай Y»).  
   - Наличие внешней детерминированной проверки и «квитанций» на каждое «готово».  
   - Как повторные просьбы «доведи результат» могут восприниматься как разрешение отступить от правил.  
   - Эффективность метода «handoff» для бесконечного диалога (деградация многоходового диалога).

