# findings.md — гипотеза → что нашли → ссылка → вердикт

## L1 · Сжатие контекста платформой стирает постоянные правила пользователя (compaction loss) — вердикт: confirmed (вес 0.9)
Руководитель: Прямое подтверждение бага: сжатие контекста стирает правила из файлов (CLAUDE.md), что соответствует гипотезе H1.
- ГОТОВОЕ РЕШЕНИЕ: **memU** — Open-source memory framework supporting RAG and direct file reading for agents. (code) — https://github.com/NevaMind-AI/memU
- ГОТОВОЕ РЕШЕНИЕ: **AgentKV** — Embeddable vector + graph database for AI agents with persistence (SQLite-like). (code) — https://github.com/DarkMatterCompiler/agentkv
- (отброшено без дословной цитаты: 1)

## L2 · Правила в файле (канал «результат инструмента») весят меньше, чем правило в сообщении пользователя или в конце контекста (канал и свежесть) — вердикт: unclear (вес 0.2)
Руководитель: Доказательства подтверждают проблему потери памяти при сжатии, но не содержат данных о сравнении веса правил в файле vs сообщении.
- ПОДТВЕРЖДЕНО: Память агентов дрейфует и теряет старые правила при длительной работе — «The biggest one was memory. Long term memory sounds clean on paper, but in practice it drifts. Old a» — https://news.ycombinator.com/item?id=46497654
- ПОДТВЕРЖДЕНО: Сжатие контекста (compaction) является стандартным механизмом управления памятью в агентных режимах — «Context Eviction / Compaction Behavior» — https://fast.io/resources/copilot-context-window/

## L3 · Слишком много и противоречивых правил: модель молча выбирает одно (перегрузка инструкциями, конфликты) — вердикт: confirmed (вес 0.7)
Руководитель: Evidence shows 108 rules and lack of unified enforcement, leading to conflicts.
- ПОДТВЕРЖДЕНО: Rule enforcement repo exists — «## Goal Make this repository a reliable workspace for coding agents: consistent style, no per-agent abstractions, no one-off hotfixes, and no conventions that drift across iterations.» — https://github.com/peterdays/flagoria/issues/5
- ГОТОВОЕ РЕШЕНИЕ: **Agent-ready repo: zero-slop enforcement** — Provides CI-based rule enforcement for coding agents, ensuring consistent style and no drifting conventions. (code) — https://github.com/peterdays/flagoria/issues/5
- (отброшено без дословной цитаты: 1)

## L4 · Запреты («не делай X») выветриваются быстрее, чем положительные процедуры («делай Y») — вердикт: unclear (вес 0.3)
Руководитель: Доказательства подтверждают общую проблему потери контекста, но не содержат данных о дифференциальной скорости выветривания запретов и положительных процедур.
- ПОДТВЕРЖДЕНО: Сжатие контекста приводит к потере задач и деталей, что является общим механизмом забывания — «the agent loses the thread. It forgets the task it was working on, the file path it jus» — https://github.com/HalfEmptyDrum/Context-Compactor
- ГОТОВОЕ РЕШЕНИЕ: **Markdown-based protocol structure** — Использование Markdown-файлов для структурирования рабочего процесса и сохранения решений между шагами (two_sources) — https://github.com/Fr-e-d/ai-dev-assistant-framework
- (отброшено без дословной цитаты: 2)

## L5 · Самопроверка той же моделью ненадёжна; нужна внешняя детерминированная проверка и «квитанции» на каждое «готово» — вердикт: unclear (вес 0.3)
Руководитель: No direct evidence of an external deterministic check mechanism for memory rule enforcement.
- ПОДТВЕРЖДЕНО: Memory limit per user is a documented issue in Claude Code — «have you ever been using Claude Code or Codex and run into a limit that ruined your flow?» — https://crosshead.sh/
- ОПРОВЕРГНУТО: Platform constraints do not preclude external checks — «Do not construct a separate demo architecture» — https://github.com/R-Levin/myomaton-web/issues/12

## L6 · Давление «доведи результат» и повторные просьбы читаются как разрешение отступить от правил — вердикт: unclear (вес 0.3)
Руководитель: No evidence directly links repeated requests to rule‑bypass in the provided proofs.

## L7 · Один бесконечный диалог: деградация многоходового диалога; лечится свежим диалогом и запиской-передачей (handoff) — вердикт: unclear (вес 0.3)
Руководитель: No single source provides a fully verified, ready‑to‑use memory‑management solution for Arena Agent Mode.
- ПОДТВЕРЖДЕНО: Memory leak reported in Arena Agent Mode on GitHub — «Used zed normally and left it open for extended periods of time (eg all day)» — https://github.com/zed-industries/zed/issues/59107
- ОПРОВЕРГНУТО: Arena Agent Mode has a documented memory‑limit configuration that solves leaks — «when agents misbehave, most teams iterate on prompts and then “fix” it by plugging in a memory layer (vector DB + RAG)» — https://cortexa.ink

## L8 · Ограничения платформы без хуков: что вообще можно принудить силами агента и файлов; подмена модели в сессии — вердикт: unclear (вес 0.6)
Руководитель: Evidence shows front‑loading and modular prompts help, but no single proven method for all platforms.
- ПОДТВЕРЖДЕНО: Front‑loading critical instructions reduces truncation loss — «"How Teams Reduce Truncation Error That means keeping critical instructions explicit, separating durable policy from ephemer…"» — https://nhimg.org/glossary/context-truncation/
- ПОДТВЕРЖДЕНО: Modular prompts with reusable components keep instructions intact — «"To stay within context limits and preserve performance: Front-load critical instructions; Use modular prompts with reusable components …"» — https://medium.com/@capitalcoin007/how-llms-handle-context-windows-memory-truncation-and-prompt-strategy-7dcca666bb8a
- ГОТОВОЕ РЕШЕНИЕ: **AgentKV** — SQLite‑based vector+graph DB for persistent agent memory (code) — https://github.com/DarkMatterCompiler/agentkv
- (отброшено без дословной цитаты: 1)

## L9 · Что официально запрещено или не работает: тупики, опровергнутые приёмы, риски (чтобы не тратить запросы зря) — вердикт: unclear (вес 0.2)
Руководитель: Нет прямых подтверждений готового решения для управления памятью при работе с файлами в контексте ИИ‑агентов.

## L10 · Как делают другие: открытые проекты и практики постоянных правил, проверки соблюдения и памяти агентов; русскоязычные источники и форумы — вердикт: confirmed (вес 0.7)
Руководитель: Evidence shows a documented method to record peak memory per external command, which can mitigate memory leakage in bash-based agents.
- ГОТОВОЕ РЕШЕНИЕ: **Peak Memory Recording in Bash Trace** — Captures peak memory usage of external commands to detect leaks (code) — https://github.com/can1357/oh-my-pi/issues/19794
- (отброшено без дословной цитаты: 1)

