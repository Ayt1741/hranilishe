#!/bin/bash
for v in 0.15 0.45; do
  echo "=== важные слова, вес $v ==="
  IMP=$v python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
done
