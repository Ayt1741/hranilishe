#!/bin/bash
echo "=== база (куски и важные слова выключены) ==="
python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
for v in 0.3 1.0; do
  echo "=== лучший кусок, вес $v ==="
  CHUNK=$v python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
done
for v in 0.3 0.6; do
  echo "=== надбавка важным словам, вес $v ==="
  IMP=$v python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
done
