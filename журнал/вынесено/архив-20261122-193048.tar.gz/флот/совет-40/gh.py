#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Управление GitHub для запуска совета: файлы, секреты, запуск workflow, ожидание, скачивание логов и артефактов.
Токен читается из память/ключи.txt внутри процесса и нигде не печатается. Только то, что нужно для запуска совета."""
import base64
import io
import json
import os
import sys
import time
import urllib.error
import urllib.request
import zipfile

ВЛАДЕЛЕЦ = "Ayt1741"


def токен():
    for строка in open("/home/user/память/ключи.txt", encoding="utf-8"):
        if строка.startswith("github="):
            return строка.strip().split("=", 1)[1]
    raise SystemExit("нет github-токена в ключи.txt")


class _БезПерехода(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def api(метод, путь, тело=None, сырой=False):
    """Возвращает (код, json|bytes). Перенаправления не выполняет (для скачивания см. скачать_по_ссылке)."""
    данные = json.dumps(тело).encode("utf-8") if тело is not None else None
    req = urllib.request.Request("https://api.github.com" + путь, method=метод, data=данные, headers={
        "Authorization": "Bearer " + токен(), "Accept": "application/vnd.github+json", "User-Agent": "KuhnyaCouncil/1.0",
        "X-GitHub-Api-Version": "2022-11-28"})
    открыть = urllib.request.build_opener(_БезПерехода()).open
    try:
        r = открыть(req, timeout=60)
        б = r.read()
        return r.status, (б if сырой else (json.loads(б) if б else None))
    except urllib.error.HTTPError as e:
        б = e.read()
        if e.code in (301, 302, 303, 307, 308):
            return e.code, e.headers.get("Location")
        try:
            return e.code, json.loads(б)
        except Exception:
            return e.code, б[:300].decode("utf-8", "ignore")


def скачать_по_ссылке(url):
    req = urllib.request.Request(url, headers={"User-Agent": "KuhnyaCouncil/1.0"})
    return urllib.request.urlopen(req, timeout=180).read()


def создать_репо(имя, описание, приватный=False):
    return api("POST", "/user/repos", {"name": имя, "description": описание, "private": приватный, "auto_init": True})


def положить_файл(репо, путь, содержимое, сообщение, ветка="main"):
    if isinstance(содержимое, str):
        содержимое = содержимое.encode("utf-8")
    код, д = api("GET", "/repos/%s/%s/contents/%s?ref=%s" % (ВЛАДЕЛЕЦ, репо, путь, ветка))
    тело = {"message": сообщение, "content": base64.b64encode(содержимое).decode(), "branch": ветка}
    if код == 200 and isinstance(д, dict) and д.get("sha"):
        тело["sha"] = д["sha"]
    return api("PUT", "/repos/%s/%s/contents/%s" % (ВЛАДЕЛЕЦ, репо, путь), тело)


def секрет(репо, имя, значение):
    from nacl import encoding, public
    код, д = api("GET", "/repos/%s/%s/actions/secrets/public-key" % (ВЛАДЕЛЕЦ, репо))
    if код != 200:
        return код, д
    ящик = public.SealedBox(public.PublicKey(д["key"].encode("utf-8"), encoding.Base64Encoder))
    шифр = base64.b64encode(ящик.encrypt(значение.encode("utf-8"))).decode()
    return api("PUT", "/repos/%s/%s/actions/secrets/%s" % (ВЛАДЕЛЕЦ, репо, имя), {"encrypted_value": шифр, "key_id": д["key_id"]})


def запустить(репо, файл_workflow, входы=None, ветка="main"):
    return api("POST", "/repos/%s/%s/actions/workflows/%s/dispatches" % (ВЛАДЕЛЕЦ, репо, файл_workflow), {"ref": ветка, "inputs": входы or {}})


def последний_запуск(репо, файл_workflow):
    код, д = api("GET", "/repos/%s/%s/actions/workflows/%s/runs?per_page=1" % (ВЛАДЕЛЕЦ, репо, файл_workflow))
    if код == 200 and д.get("workflow_runs"):
        return д["workflow_runs"][0]
    return None


def задачи(репо, run_id):
    рез, стр = [], 1
    while True:
        код, д = api("GET", "/repos/%s/%s/actions/runs/%d/jobs?per_page=100&page=%d" % (ВЛАДЕЛЕЦ, репо, run_id, стр))
        if код != 200:
            break
        рез += д.get("jobs", [])
        if len(д.get("jobs", [])) < 100:
            break
        стр += 1
    return рез


def ждать(репо, run_id, лимит=1500, шаг=20, печать=True):
    t0 = time.time()
    последнее = ""
    while time.time() - t0 < лимит:
        код, д = api("GET", "/repos/%s/%s/actions/runs/%d" % (ВЛАДЕЛЕЦ, репо, run_id))
        if код == 200:
            js = задачи(репо, run_id)
            ст = {}
            for j in js:
                ключ = j["status"] if j["status"] != "completed" else "ok" if j["conclusion"] == "success" else "FAIL:" + str(j["conclusion"])
                ст[ключ] = ст.get(ключ, 0) + 1
            строка = "run %d: %s | задач %d %s" % (run_id, д["status"], len(js), ст)
            if печать and строка != последнее:
                print("[%4ds] %s" % (time.time() - t0, строка), flush=True)
                последнее = строка
            if д["status"] == "completed":
                return д
        time.sleep(шаг)
    return None


def логи(репо, run_id):
    """Скачивает логи запуска: {имя файла: текст}."""
    код, loc = api("GET", "/repos/%s/%s/actions/runs/%d/logs" % (ВЛАДЕЛЕЦ, репо, run_id))
    if код not in (301, 302, 303, 307, 308) or not loc:
        return {"_ошибка": "код %s %s" % (код, loc)}
    z = zipfile.ZipFile(io.BytesIO(скачать_по_ссылке(loc)))
    return {n: z.read(n).decode("utf-8", "ignore") for n in z.namelist() if not n.endswith("/")}


def артефакты(репо, run_id, в_каталог):
    os.makedirs(в_каталог, exist_ok=True)
    код, д = api("GET", "/repos/%s/%s/actions/runs/%d/artifacts?per_page=100" % (ВЛАДЕЛЕЦ, репо, run_id))
    скачано = []
    for a in (д.get("artifacts", []) if код == 200 else []):
        код2, loc = api("GET", "/repos/%s/%s/actions/artifacts/%d/zip" % (ВЛАДЕЛЕЦ, репо, a["id"]))
        if код2 in (301, 302, 303, 307, 308) and loc:
            z = zipfile.ZipFile(io.BytesIO(скачать_по_ссылке(loc)))
            каталог = os.path.join(в_каталог, a["name"])
            os.makedirs(каталог, exist_ok=True)
            for n in z.namelist():
                if n.endswith("/"):
                    continue
                путь = os.path.join(каталог, os.path.basename(n))
                open(путь, "wb").write(z.read(n))
            скачано.append((a["name"], len(z.namelist())))
    return скачано


if __name__ == "__main__":
    print("модуль; запуск напрямую ничего не делает", file=sys.stderr)
