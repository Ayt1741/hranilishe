#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Локальный пробный прогон конвейера совета на малом наборе (проверка кода до запуска на GitHub). Ключи — только в окружении процесса."""
import gzip, json, os, re, subprocess, sys, time
базa = os.path.dirname(os.path.abspath(__file__))
tmp = "/tmp/совет-тест"
os.makedirs(tmp, exist_ok=True)
env = dict(os.environ)
for л in open('/home/user/память/ключи.txt', encoding='utf-8'):
    if л.startswith('groq='):
        env['GROQ_API_KEY'] = л.strip().split('=', 1)[1]
    if л.startswith('github='):
        env['GITHUB_TOKEN'] = л.strip().split('=', 1)[1]
txt = gzip.open('/home/user/память/журнал.jsonl.gz', 'rt', encoding='utf-8', errors='ignore').read()
for имя, ш in (('TAVILY_API_KEY', r"tvly-[A-Za-z0-9_\-]{16,}"), ('FIRECRAWL_API_KEY', r"fc-[A-Za-z0-9]{20,}")):
    найд = sorted(set(re.findall(ш, txt)))
    if найд:
        env[имя] = найд[0]
# Jina: рабочий — первый из двух (второй даёт 401); проверим по очереди
import urllib.request
for к in sorted(set(re.findall(r"jina_[A-Za-z0-9]{20,}", txt))):
    try:
        urllib.request.urlopen(urllib.request.Request('https://s.jina.ai/?q=test', headers={'Authorization': 'Bearer ' + к, 'Accept': 'application/json', 'User-Agent': 'kuhnya/1.0'}), timeout=30)
        env['JINA_API_KEY'] = к
        break
    except Exception:
        pass
лидеры = sys.argv[1].split(',') if len(sys.argv) > 1 else ['L1', 'L5']
шардов = int(sys.argv[2]) if len(sys.argv) > 2 else 3
def запустить(скрипт, *арг):
    return subprocess.Popen([sys.executable, os.path.join(базa, скрипт)] + list(арг), env=env, cwd=базa, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
def ждать(процессы, метка):
    for п in процессы:
        вывод, _ = п.communicate(timeout=900)
        print("   ", метка, "код", п.returncode, "|", (вывод.strip().splitlines() or [""])[-1][:150])
t0 = time.time()
print("1) планы руководителей", лидеры); ждать([запустить('leader_plan.py', '--id', л, '--out', f'{tmp}/plan-{л}.json') for л in лидеры], 'план')
print("2) исполнители раунд 1 (%d)" % шардов); ждать([запустить('executor.py', '--round', '1', '--shard', str(s), '--total', str(шардов), '--src', tmp, '--out', f'{tmp}/exec1-{s}.json') for s in range(шардов)], 'раунд1')
print("3) разбор руководителей"); ждать([запустить('leader_analyze.py', '--id', л, '--plans', tmp, '--execs', tmp, '--out', f'{tmp}/analysis-{л}.json') for л in лидеры], 'разбор')
print("4) исполнители раунд 2"); ждать([запустить('executor.py', '--round', '2', '--shard', str(s), '--total', str(шардов), '--src', tmp, '--out', f'{tmp}/exec2-{s}.json') for s in range(шардов)], 'раунд2')
print("5) совет"); ждать([запустить('vote.py', '--plans', tmp, '--exec1', tmp, '--analyses', tmp, '--exec2', tmp, '--out', f'{tmp}/out')], 'совет')
print("всего %.0f с" % (time.time() - t0))
