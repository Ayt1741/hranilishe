#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Запуск совета-40 на GitHub Actions: секреты, код, запуск, ожидание, скачивание результата.
  python3 запуск-совета.py секреты | код | запуск | ждать [секунд] | забрать | всё
Ключи берутся внутри процесса (память/ключи.txt и журнал), в вывод не попадают; в репозиторий кладутся только секреты Actions."""
import gzip
import os
import re
import sys
import time
import urllib.error
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ЗДЕСЬ)
import gh  # noqa: E402

РЕПО = "council-40"
ВЫХОД = os.environ.get("COUNCIL_OUT", "/home/user/research/совет-ход55")
СЛЕД = os.path.join(ЗДЕСЬ, "последний-запуск.txt")
ФАЙЛЫ_СОВЕТА = ["cr_common.py", "leader_plan.py", "exec_plan.py", "executor.py", "leader_analyze.py", "vote.py", "lanes.json",
                "protocol.md", "protocol-short.md", "task.md", "task-short.md"]


def из_ключей(имя):
    for строка in open("/home/user/память/ключи.txt", encoding="utf-8"):
        if строка.startswith(имя + "="):
            return строка.strip().split("=", 1)[1]
    return None


def из_журнала():
    текст = gzip.open("/home/user/память/журнал.jsonl.gz", "rt", encoding="utf-8", errors="ignore").read()
    рез = {}
    for имя, шаблон in (("TAVILY_API_KEY", r"tvly-[A-Za-z0-9_\-]{16,}"), ("FIRECRAWL_API_KEY", r"fc-[A-Za-z0-9]{20,}")):
        найд = sorted(set(re.findall(шаблон, текст)))
        if найд:
            рез[имя] = найд[0]
    for к in sorted(set(re.findall(r"jina_[A-Za-z0-9]{20,}", текст))):
        try:
            urllib.request.urlopen(urllib.request.Request("https://s.jina.ai/?q=test", headers={
                "Authorization": "Bearer " + к, "Accept": "application/json", "User-Agent": "KuhnyaCouncil/1.0"}), timeout=30)
            рез["JINA_API_KEY"] = к
            break
        except Exception:
            continue
    return рез


def секреты():
    значения = {"GROQ_API_KEY": из_ключей("groq")}
    значения.update(из_журнала())
    for имя, зн in значения.items():
        if not зн:
            print("секрет %-18s НЕТ значения — пропуск" % имя)
            continue
        код, д = gh.секрет(РЕПО, имя, зн)
        print("секрет %-18s HTTP %s" % (имя, код))
    код, д = gh.api("GET", "/repos/%s/%s/actions/secrets" % (gh.ВЛАДЕЛЕЦ, РЕПО))
    print("секреты в репозитории:", sorted(x["name"] for x in д.get("secrets", [])) if isinstance(д, dict) else д)


def код_():
    for ф in ФАЙЛЫ_СОВЕТА:
        код, д = gh.положить_файл(РЕПО, "council/" + ф, open(os.path.join(ЗДЕСЬ, ф), "rb").read(), "council: " + ф)
        print("файл council/%-20s HTTP %s" % (ф, код), "" if код < 300 else str(д)[:160])
    код, д = gh.положить_файл(РЕПО, ".github/workflows/council-40.yml", open(os.path.join(ЗДЕСЬ, "workflows", "council-40.yml"), "rb").read(), "workflow council-40")
    print("workflow council-40.yml HTTP", код, "" if код < 300 else str(д)[:200])
    код, д = gh.положить_файл(РЕПО, "README.md", open(os.path.join(ЗДЕСЬ, "workflows", "README.md"), "rb").read(), "README")
    print("README HTTP", код)


def запуск():
    до = gh.последний_запуск(РЕПО, "council-40.yml")
    код, д = gh.запустить(РЕПО, "council-40.yml", {"note": "ход 60: 4000 запросов"})
    print("запуск HTTP", код, "" if код < 300 else str(д)[:300])
    if код >= 300:
        raise SystemExit(1)
    for _ in range(30):
        time.sleep(4)
        р = gh.последний_запуск(РЕПО, "council-40.yml")
        if р and (not до or р["id"] != до["id"]):
            open(СЛЕД, "w").write(str(р["id"]))
            print("run_id", р["id"], р["html_url"])
            return
    raise SystemExit("запуск не появился в списке")


def ждать(лимит=2400):
    run_id = int(open(СЛЕД).read().strip())
    д = gh.ждать(РЕПО, run_id, лимит=лимит, шаг=25)
    if not д:
        print("время ожидания вышло; запуск ещё идёт")
        raise SystemExit(2)
    print("итог запуска:", д["status"], д["conclusion"])
    for j in gh.задачи(РЕПО, run_id):
        if j["conclusion"] != "success":
            print("  не успех:", j["name"], j["conclusion"])


def забрать():
    run_id = int(open(СЛЕД).read().strip())
    os.makedirs(ВЫХОД, exist_ok=True)
    список = gh.артефакты(РЕПО, run_id, ВЫХОД)
    print("артефактов скачано: %d" % len(список))
    лог = gh.логи(РЕПО, run_id)
    os.makedirs(os.path.join(ВЫХОД, "логи"), exist_ok=True)
    for имя, текст in лог.items():
        безопасное = re.sub(r"[^\w.\-]+", "_", имя)[:120]
        open(os.path.join(ВЫХОД, "логи", безопасное), "w", encoding="utf-8").write(текст)
    print("файлов логов сохранено: %d" % len(лог))


if __name__ == "__main__":
    команда = sys.argv[1] if len(sys.argv) > 1 else ""
    if команда == "секреты":
        секреты()
    elif команда == "код":
        код_()
    elif команда == "запуск":
        запуск()
    elif команда == "ждать":
        ждать(int(sys.argv[2]) if len(sys.argv) > 2 else 2400)
    elif команда == "забрать":
        забрать()
    elif команда == "всё":
        секреты(); код_(); запуск(); ждать(); забрать()
    else:
        print(__doc__)
