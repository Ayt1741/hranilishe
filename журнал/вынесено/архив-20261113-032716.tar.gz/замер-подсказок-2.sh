#!/bin/bash
for v in 0.3 0.6 1.0; do
  echo "=== подсказки со своими словами, вес $v ==="
  RAS=$v python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
done
