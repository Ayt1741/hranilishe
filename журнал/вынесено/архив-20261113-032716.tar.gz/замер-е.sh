#!/bin/bash
python3 поиск.py --пересобрать | tail -1
python3 оценка-памяти.py 2>&1 | grep -E "набор|ИТОГ"
