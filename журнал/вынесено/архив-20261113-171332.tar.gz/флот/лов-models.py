#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Перехват ВСЕХ ответов страницы Direct — там приходит список моделей."""
import asyncio
import importlib.util
import json

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')


async def main():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        вижу = []

        async def ловить(r):
            try:
                if 'arena.ai' not in r.url:
                    return
                if any(x in r.url for x in ('analytics', 'google', 'gstatic', 'phc_', 'surveys')):
                    return
                if not r.url.startswith("https://arena.ai"):
                    return
                try:
                    тело = await r.text()
                except Exception:
                    тело = ''
                вижу.append({'status': r.status, 'url': r.url, 'bytes': len(тело),
                             'muse': 'muse' in тело.lower()})
                if 'muse' in тело.lower():
                    open("/home/user/research/arena-list-%d.json" % len(вижу), "w",
                         encoding="utf-8").write(тело)
            except Exception:
                pass

        pg.on("response", lambda r: asyncio.ensure_future(ловить(r)))
        await pg.goto("https://arena.ai/direct", wait_until="domcontentloaded", timeout=90000)
        for _ in range(40):
            await pg.wait_for_timeout(1500)
            if await pg.locator("textarea").count():
                break
            if await pg.get_by_role("button", name="Direct", exact=False).count():
                break
        await pg.wait_for_timeout(3000)
        к = pg.get_by_role("button", name="Direct", exact=False).first
        if await к.count():
            try:
                await к.click(timeout=8000)
                await pg.wait_for_timeout(4000)
            except Exception:
                pass
        for надпись in ("Max", "Router"):
            b2 = pg.get_by_role("button", name=надпись, exact=False).first
            if await b2.count():
                try:
                    await b2.click(timeout=8000)
                    await pg.wait_for_timeout(3000)
                    break
                except Exception:
                    pass
        await pg.wait_for_timeout(2500)
        print("перехвачено ответов:", len(вижу))
        for v in вижу:
            print("  %s %8d б muse=%-5s %s" % (v['status'], v['bytes'], v['muse'], v['url'][:110]))
        json.dump(вижу, open("/home/user/research/arena-ответы.json", "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        await b.close()


asyncio.run(main())
