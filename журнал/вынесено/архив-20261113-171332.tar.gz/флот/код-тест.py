#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Тест режима Код: какой эндпоинт создаёт оценку и режет ли он recaptcha."""
import asyncio
import importlib.util
import json

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')


async def main():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        вижу = []

        async def ловить(r):
            u = r.url
            if 'arena.ai' not in u:
                return
            if any(k in u for k in ('/nextjs-api/stream', 'create-evaluation', '/api/chat/', 'recaptcha')):
                try:
                    t = (await r.text())[:400]
                except Exception:
                    t = ''
                вижу.append((r.status, u[:140], t[:260]))

        pg.on('response', lambda r: asyncio.ensure_future(ловить(r)))
        for адрес, режим in (("https://arena.ai/code", "code"), ("https://arena.ai/text", "text")):
            вижу.clear()
            print("=" * 20, адрес)
            await pg.goto(адрес, wait_until="domcontentloaded", timeout=90000)
            await pg.wait_for_timeout(7000)
            # выбираем режим, если есть кнопка «Code»/«Battle»
            for надпись in ("Code", "Battle", "Text"):
                к = pg.get_by_role("button", name=надпись, exact=False).first
                if await к.count():
                    try:
                        await к.click(timeout=6000)
                        await pg.wait_for_timeout(3000)
                        print("  нажали", надпись)
                        break
                    except Exception:
                        pass
            box = pg.locator("textarea").first
            try:
                await box.click(timeout=20000)
                await box.fill("Напиши на Python функцию merge_sorted(lists), 2 строки пояснения.")
                await pg.wait_for_timeout(600)
                await box.press("Enter")
            except Exception as e:
                print("  не отправили:", str(e)[:80])
                continue
            for i in range(14):
                await pg.wait_for_timeout(5000)
                txt = await pg.inner_text("body")
                if "Something went wrong" in txt:
                    print("  ОШИБКА ГЕНЕРАЦИИ")
                    break
                if len(txt) > 1200:
                    print("  ответ появился, страница", len(txt), "символов")
                    break
            for s, u, t in вижу:
                print("   HTTP", s, u, "|", t.replace("\n", " "))
            txt = await pg.inner_text("body")
            print("  текст:", txt[:700].replace("\n", " | "))
        await b.close()


asyncio.run(main())
