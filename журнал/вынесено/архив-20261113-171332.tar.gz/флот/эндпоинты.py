#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Два дела за раз: прочитать ответы по cursor и найти полный список моделей.

Эндпоинты перебираются прямо в браузере (с куками арены), поэтому работают
там, где внешний запрос блокируется.
"""
import asyncio
import importlib.util
import json

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')

ПУТИ = [
    "/api/chat/models",
    "/api/models/all",
    "/api/arena/models",
    "/api/text/models",
    "/api/code/models",
    "/api/leaderboard/models",
    "/api/models/leaderboard",
    "/api/v2/models",
    "/nextjs-api/models",
    "/api/autoeval/models",
    "/api/release-banner",
    "/nextjs-api/autoeval/release-banner",
    "/api/history/unified?limit=5&includeArchived=false",
]


async def main():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        await pg.goto("https://arena.ai/text", wait_until="domcontentloaded", timeout=90000)
        await pg.wait_for_timeout(6000)

        async def api(path):
            return await pg.evaluate("""async (p) => {
                const r = await fetch(p, {headers:{'accept':'application/json'}});
                if (!r.ok) return {status:r.status, body:(await r.text()).slice(0,600)};
                const t = await r.text();
                try { return Object.assign({status:r.status}, JSON.parse(t)); }
                catch(e) { return {status:r.status, body:t.slice(0,600)}; }
            }""", path)

        hist = await api("/api/history/unified?limit=20&includeArchived=false")
        ents = hist.get("entries", [])
        print("диалогов:", len(ents))
        for e in ents:
            print("   ", e.get("id"), "|", (e.get("title") or "")[:60].replace("\n", " "))
        if ents:
            did = ents[0].get("id")
            for cur in ("", "0"):
                r = await api("/api/chat/%s/messages?limit=50&cursor=%s" % (did, cur))
                print("--- messages cursor=%r -> %s" % (cur, r.get("status")))
                print("   ", json.dumps(r, ensure_ascii=False)[:1200])
        print()
        for путь in ПУТИ:
            r = await api(путь)
            тело = json.dumps(r, ensure_ascii=False)
            print("%-46s -> %s %s" % (путь, r.get("status"), тело[:300].replace("\n", " ")))
        await b.close()


asyncio.run(main())
