#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Есть ли в Direct модель muse-wonder (поиск по имени в списке)."""
import asyncio
import importlib.util
import json

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')


async def main():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        await pg.goto("https://arena.ai/direct", wait_until="domcontentloaded", timeout=90000)
        for _ in range(40):
            await pg.wait_for_timeout(1500)
            if await pg.locator("textarea").count():
                break
            if await pg.get_by_role("button", name="Direct", exact=False).count():
                break
        await pg.wait_for_timeout(2500)
        к = pg.get_by_role("button", name="Direct", exact=False).first
        if await к.count():
            try:
                await к.click(timeout=8000)
                await pg.wait_for_timeout(3000)
            except Exception:
                pass
        for надпись in ("Max", "Router", "Select model"):
            b2 = pg.get_by_role("button", name=надпись, exact=False).first
            if await b2.count():
                try:
                    await b2.click(timeout=8000)
                    await pg.wait_for_timeout(2500)
                    if await pg.query_selector_all("[role=option]"):
                        break
                except Exception:
                    pass
        поиск = pg.get_by_placeholder("Search models").first
        if not await поиск.count():
            поиск = pg.locator("input[placeholder*=Search]").first
        for слово in ("wonder", "muse", "max"):
            try:
                await поиск.click(timeout=8000)
                await поиск.fill(слово)
                await pg.wait_for_timeout(2800)
                опции = await pg.query_selector_all("[role=option]")
                найдено = []
                for e in опции:
                    t = (await e.inner_text()).strip().split("\n")[0].strip()
                    if t:
                        найдено.append(t)
                print("поиск %-7s -> %d: %s" % (слово, len(найдено), найдено[:25]))
            except Exception as e:
                print("поиск", слово, "ошибка:", str(e)[:70])
        await b.close()


asyncio.run(main())
