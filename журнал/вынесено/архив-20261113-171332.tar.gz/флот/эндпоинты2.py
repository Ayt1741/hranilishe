#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Поиск эндпоинта со списком моделей Battle (с именами и рейтингами).

В Battle модели анонимны, но список «что играет» где-то есть — надо найти,
где арена его берёт.
"""
import asyncio
import importlib.util
import json
import re

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')

КАНДИДАТЫ = [
    "/nextjs-api/autoeval/leaderboard",
    "/nextjs-api/autoeval/leaderboard?arena=text",
    "/nextjs-api/autoeval/arena-models",
    "/nextjs-api/autoeval/models",
    "/nextjs-api/autoeval/config",
    "/nextjs-api/autoeval",
    "/api/autoeval/leaderboard",
    "/api/arena/leaderboard",
    "/api/leaderboard/v2",
    "/api/v1/leaderboard",
    "/api/text/leaderboard",
    "/api/code/leaderboard",
    "/nextjs-api/leaderboard",
    "/nextjs-api/text/leaderboard",
    "/api/battle/models",
    "/api/arena/battle",
    "/api/autoeval/pool",
    "/nextjs-api/autoeval/pool",
    "/api/available-models",
    "/nextjs-api/available-models",
]


async def main():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        await pg.goto("https://arena.ai/text", wait_until="domcontentloaded", timeout=90000)
        await pg.wait_for_timeout(6000)

        async def api(path):
            return await pg.evaluate("""async (p) => {
                try {
                  const r = await fetch(p, {headers:{'accept':'application/json'}});
                  if (!r.ok) return {status:r.status, body:(await r.text()).slice(0,400)};
                  const t = await r.text();
                  try { return Object.assign({status:r.status}, JSON.parse(t)); }
                  catch(e) { return {status:r.status, body:t.slice(0,400)}; }
                } catch(e) { return {status:0, body:String(e).slice(0,120)}; }
            }""", path)

        for путь in КАНДИДАТЫ:
            r = await api(путь)
            тело = json.dumps(r, ensure_ascii=False)
            muse = sorted(set(re.findall(r'[A-Za-z0-9\.\-]{0,12}[Mm]use[A-Za-z0-9\.\-]{0,18}', тело)))
            знак = "  <<< МОДЕЛИ" if muse else ""
            print("%-42s %s %s%s" % (путь, r.get("status"), тело[:220].replace("\n", " "),
                                     ((" muse=" + str(muse[:10])) if muse else "")))
        await b.close()


asyncio.run(main())
