#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Рейтинг арены: вытащить все модели (для поиска второй Muse)."""
import asyncio
import importlib.util
import json
import re

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')


async def main():
    from playwright.async_api import async_playwright
    почта, пароль = dm.знаки()[0][1], dm.знаки()[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        тела = []

        async def ловить(r):
            if 'arena.ai' in r.url and '/api/' in r.url and 'analytics' not in r.url:
                try:
                    t = (await r.text())
                except Exception:
                    t = ''
                тела.append((r.status, r.url, t))

        pg.on('response', lambda r: asyncio.ensure_future(ловить(r)))
        for адрес in ("https://arena.ai/leaderboard", "https://arena.ai/leaderboard/text",
                      "https://arena.ai/leaderboard/code"):
            тела.clear()
            try:
                await pg.goto(адрес, wait_until="domcontentloaded", timeout=90000)
                await pg.wait_for_timeout(9000)
            except Exception as e:
                print(адрес, "не открылась:", str(e)[:80])
                continue
            txt = await pg.inner_text("body")
            print("=" * 12, адрес, "| текст", len(txt))
            print(txt[:300].replace("\n", " | "))
            for s, u, t in тела:
                print("  ", s, u[:130], len(t))
                muse = sorted(set(re.findall(r'[A-Za-z0-9\.\- ]{0,15}[Mm]use[A-Za-z0-9\.\- ]{0,25}', t)))
                if muse:
                    print("     muse:", muse[:40])
        await b.close()


asyncio.run(main())
