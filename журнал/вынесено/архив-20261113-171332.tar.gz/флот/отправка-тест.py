#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверка отправки: Enter против кнопки, и есть ли grecaptcha в странице."""
import asyncio
import importlib.util
import json

spec = importlib.util.spec_from_file_location("dm", "/home/user/память/direct-модели.py")
dm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dm)
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
КЛЮЧ = "6LeTGMcsAAAAALuIlkVwIxaAuZA8VledA6d3Nnb0"
ВОПРОС = "Напиши на Python функцию merge_sorted(lists) — сливает отсортированные списки в новый отсортированный, исходные не меняет. Дай код."


async def основной():
    from playwright.async_api import async_playwright
    пары = dm.знаки()
    почта, пароль = пары[0][1], пары[0][2]
    токен, печ, полез = dm.вход(почта, пароль)
    print("вход:", (полез.get('user') or {}).get('email'))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печ)
        pg = await ctx.new_page()
        ошибки = []

        async def ловить(r):
            try:
                if 'arena.ai' in r.url and ('create-evaluation' in r.url or 'recaptcha' in r.url.lower()
                                            or 'google.com' in r.url):
                    try:
                        t = (await r.text())[:300]
                    except Exception:
                        t = ''
                    ошибки.append((r.status, r.url[:130], t[:200]))
            except Exception:
                pass

        pg.on('response', lambda r: asyncio.ensure_future(ловить(r)))
        await pg.goto("https://arena.ai/direct", wait_until="domcontentloaded", timeout=90000)
        for _ in range(40):
            await pg.wait_for_timeout(1500)
            if await pg.locator("textarea").count():
                break
            if await pg.get_by_role("button", name="Direct", exact=False).count():
                break
        await pg.wait_for_timeout(3000)
        к = pg.get_by_role("button", name="Direct", exact=False).first
        if await к.count():
            try:
                await к.click(timeout=8000)
                await pg.wait_for_timeout(3000)
            except Exception:
                pass
        for надпись in ("Max", "Router"):
            b2 = pg.get_by_role("button", name=надпись, exact=False).first
            if await b2.count():
                try:
                    await b2.click(timeout=8000)
                    await pg.wait_for_timeout(2200)
                    if await pg.query_selector_all("[role=option]"):
                        break
                except Exception:
                    pass
        for e in await pg.query_selector_all("[role=option]"):
            t = (await e.inner_text()).strip().split("\n")[0].strip()
            if t == "muse-spark-1.3-xhigh":
                await e.click(timeout=8000)
                print("модель выбрана")
                break
        await pg.wait_for_timeout(2500)
        # состояние recaptcha в странице
        сост = await pg.evaluate("""() => ({
            hasGrecaptcha: typeof window.grecaptcha !== 'undefined',
            hasEnterprise: !!(window.grecaptcha && window.grecaptcha.enterprise),
            hasExecute: !!(window.grecaptcha && window.grecaptcha.enterprise
                           && window.grecaptcha.enterprise.execute),
            scripts: Array.from(document.scripts).map(s=>s.src).filter(s=>s.includes('recaptcha'))
        })""")
        print("recaptcha в странице:", json.dumps(сост, ensure_ascii=False))
        ток = ""
        try:
            ток = await pg.evaluate("""async (key) => {
                try {
                  if (!window.grecaptcha || !window.grecaptcha.enterprise) return 'нет enterprise';
                  if (!window.grecaptcha.enterprise.execute) return 'нет execute';
                  await new Promise(r => window.grecaptcha.enterprise.ready(r));
                  return await new Promise((res) => {
                    window.grecaptcha.enterprise.execute(key, {action:'submit'})
                      .then(t => res('токен:' + String(t).slice(0,25)))
                      .catch(e => res('ошибка:' + String(e).slice(0,80)));
                  });
                } catch(e) { return 'исключение:' + String(e).slice(0,80); }
            }""", КЛЮЧ)
        except Exception as e:
            ток = "ошибка вызова:" + str(e)[:80]
        print("execute →", ток)
        # отправка КНОПКОЙ
        box = pg.locator("textarea").first
        await box.click(timeout=20000)
        await box.fill(ВОПРОС)
        await pg.wait_for_timeout(1200)
        стрелка = None
        for sel in ("button[aria-label*=Send]", "button[type=submit]", "button:has(svg.lucide-arrow-up)",
                    "button:has(svg[data-lucide='arrow-up'])"):
            эл = await pg.query_selector_all(sel)
            if эл:
                стрелка = эл[-1]
                print("кнопка найдена:", sel)
                break
        if стрелка is not None:
            await стрелка.click(timeout=8000)
        else:
            await box.press("Enter")
        for i in range(14):
            await pg.wait_for_timeout(5000)
            txt = await pg.inner_text("body")
            if "Something went wrong" in txt:
                print("ОШИБКА ГЕНЕРАЦИИ")
                break
            if len(txt) > 1500:
                i0 = txt.find(ВОПРОС[:40])
                print("ОТВЕТ:", (txt[i0 + len(ВОПРОС):] if i0 >= 0 else txt)[:1200].replace("\n", " | "))
                break
        for s, u, t in ошибки[-12:]:
            print("HTTP", s, u, "|", t.replace("\n", " "))
        await pg.screenshot(path="/tmp/otpravka.png", full_page=True)
        await b.close()


asyncio.run(основной())
