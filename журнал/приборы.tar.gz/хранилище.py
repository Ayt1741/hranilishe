#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ХРАНИЛИЩЕ — проверка закона «всё в хранилище» машиной, а не словами.

Страницы сверяются побайтово (sha256), а лента — по существу: сколько действий
и какое последнее, потому что публикатор сериализует JSON сам и байты заведомо
не совпадают с локальным файлом.

  python3 хранилище.py            # сверить
  python3 хранилище.py --список   # что сверяется и как

Коды: 0 всё совпало · 1 расхождение · 2 «не проверено» (сеть/лимит API).
По поиску №52 гейт обязан отличать «не выполнено» от «не проверено».
"""
import argparse
import base64
import hashlib
import json
import os
import sys
import urllib.error
import urllib.request

БАЗА = os.path.dirname(os.path.abspath(__file__))
ПОТОЛОК = 200   # панель/опубликовать.py кладёт в хранилище только 200 последних действий
РЕПОЗИТОРИЙ = "Ayt1741/hranilishe"
ВЕТКА = "main"
ТАЙМАУТ = 20
СТРАНИЦЫ = [("панель/panel.html", "panel.html"), ("панель/panel2.html", "panel2.html")]


def api_файл(имя):
    """Свежее содержимое из API (без кэша CDN). Возвращает (байты, источник)."""
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (РЕПОЗИТОРИЙ, имя, ВЕТКА)
    запрос = urllib.request.Request(url, headers={
        "User-Agent": "hranilishe-check", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(запрос, timeout=ТАЙМАУТ) as о:
        д = json.load(о)
    return base64.b64decode(д.get("content") or ""), "api"


def raw_файл(имя):
    """Запасной путь: raw.githubusercontent (кэш ~5 мин)."""
    url = "https://raw.githubusercontent.com/%s/%s/%s" % (РЕПОЗИТОРИЙ, ВЕТКА, имя)
    запрос = urllib.request.Request(url, headers={"User-Agent": "hranilishe-check"})
    with urllib.request.urlopen(запрос, timeout=ТАЙМАУТ) as о:
        return о.read(), "raw"


def достать(имя):
    try:
        return api_файл(имя)
    except urllib.error.HTTPError as e:
        if e.code in (403, 429):  # лимит API — идём в raw, но помечаем
            return raw_файл(имя)
        raise
    except Exception:
        return raw_файл(имя)


def локальные_действия():
    путь = os.path.join(БАЗА, "панель", "действия.jsonl")
    всего, последнее = 0, None
    with open(путь, encoding="utf-8") as f:
        for строка in f:
            строка = строка.strip()
            if not строка:
                continue
            try:
                з = json.loads(строка)
            except json.JSONDecodeError:
                continue
            всего += 1
            последнее = з.get("н")
    return всего, последнее


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--список", action="store_true")
    a = ap.parse_args()
    if a.список:
        print("Страницы — побайтово (sha256), лента — по существу (число действий и последний номер).")
        for локально, в_репо in СТРАНИЦЫ:
            print("  %-22s → %s" % (локально, в_репо))
        print("  %-22s → %s" % ("панель/действия.jsonl", "actions.json (число и последний №)"))
        return 0

    расхождения, непроверено = [], []
    print("%-24s %-22s %-22s %s" % ("ЧТО", "ЛОКАЛЬНО", "В ХРАНИЛИЩЕ", "ВЕРДИКТ"))

    for локально, в_репо in СТРАНИЦЫ:
        полный = os.path.join(БАЗА, локально)
        if not os.path.exists(полный):
            расхождения.append(локально)
            print("%-24s %-22s %-22s %s" % (локально, "нет файла", "—", "НЕТ ФАЙЛА"))
            continue
        свой = hashlib.sha256(open(полный, "rb").read()).hexdigest()
        try:
            байты, источник = достать(в_репо)
        except Exception as e:
            непроверено.append(локально)
            print("%-24s %-22s %-22s %s" % (локально, свой[:12], type(e).__name__, "НЕ ПРОВЕРЕНО"))
            continue
        чужой = hashlib.sha256(байты).hexdigest()
        ок = свой == чужой
        if not ок:
            расхождения.append(локально)
        print("%-24s %-22s %-22s %s" % (
            локально, свой[:12], "%s… (%s, %d б)" % (чужой[:12], источник, len(байты)),
            "СОВПАЛО" if ок else "РАСХОЖДЕНИЕ"))

    # лента — по существу
    всего_л, посл_л = локальные_действия()
    try:
        байты, источник = достать("actions.json")
        д = json.loads(байты.decode("utf-8"))
        действия = д.get("действия") or д.get("лента") or []
        всего_у = len(действия)
        посл_у = (действия[-1] or {}).get("н") if действия else None
        # публикатор намеренно режет ленту до 200 последних действий (предел=200),
        # поэтому требуем: последний номер совпал, а число в хранилище равно
        # min(локально, 200). Сравнивать «сколько у меня» с «сколько там» напрямую нельзя:
        # это давало вечное расхождение после 200-го действия.
        ждали_у = min(всего_л, ПОТОЛОК)
        ок = (всего_у == ждали_у) and (str(посл_у) == str(посл_л))
        if not ок:
            расхождения.append("actions.json")
        print("%-24s %-22s %-22s %s" % (
            "лента действий", "%d, №%s" % (всего_л, посл_л),
            "%d, №%s (%s)" % (всего_у, посл_у, источник),
            "СОВПАЛО" if ок else "РАСХОЖДЕНИЕ"))
    except Exception as e:
        непроверено.append("actions.json")
        print("%-24s %-22s %-22s %s" % ("лента действий", "%d, №%s" % (всего_л, посл_л),
                                        type(e).__name__, "НЕ ПРОВЕРЕНО"))

    print()
    if расхождения:
        print("ИТОГ: расхождений %d (%s), не проверено %d → код 1"
              % (len(расхождения), ", ".join(расхождения), len(непроверено)))
        return 1
    if непроверено:
        print("ИТОГ: не проверено %d (%s) → код 2 «не проверено», а не «провалено»"
              % (len(непроверено), ", ".join(непроверено)))
        return 2
    print("ИТОГ: страницы и лента в хранилище совпадают с локальными → код 0")
    return 0


if __name__ == "__main__":
    sys.exit(main())
