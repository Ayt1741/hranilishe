#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""СОБРАТЬ ПОИСКИ: результаты машин флота → один файл research/поиски-16.md.

Каждая строка: `N | запрос | что дало (заголовок — домен)`.
Коды: 0 собрано · 1 строк меньше минимума · 2 нет артефактов.
"""
import argparse
import glob
import json
import os
import re
import sys

БАЗА = "/home/user"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--папка", required=True, help="папка с search-*.json")
    ap.add_argument("--выход", default=os.path.join(БАЗА, "research", "поиски-16.md"))
    ap.add_argument("--минимум", type=int, default=100)
    a = ap.parse_args()
    файлы = sorted(glob.glob(os.path.join(a.папка, "**", "search-*.json"), recursive=True))
    if not файлы:
        print("НЕТ ФАЙЛОВ:", a.папка)
        return 2
    строки = []
    for f in файлы:
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception as e:
            print("  пропущен", os.path.basename(f), str(e)[:60])
            continue
        for r in d.get("results", []):
            что = (r.get("title") or "").replace("|", "/").strip()
            дом = (r.get("url") or "").replace("|", "/").strip()
            строки.append("| %d | %s | %s — %s |" % (len(строки) + 1, r.get("q", ""),
                                                     что if что else "ничего не нашлось",
                                                     дом or "—"))
    шапка = ("# Ход 52. Поиск в интернете флотом: %d запросов\n\n"
             "Формат: `N | запрос | что дало (заголовок — домен)`\n\n"
             "| № | запрос | что дало |\n|---|---|---|\n" % len(строки))
    with open(a.выход, "w", encoding="utf-8") as f:
        f.write(шапка)
        f.write("\n".join(строки))
        f.write("\n")
    всего = len(re.findall(r"^\| \d+ \|", open(a.выход, encoding="utf-8").read(), re.M))
    print("ИТОГ: строк в файле: %d (минимум %d)" % (всего, a.минимум))
    return 0 if всего >= a.минимум else 1


if __name__ == "__main__":
    sys.exit(main())
