#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""СЖАТЬ — закон 43: в воркспейсе не держать лишнего, ничего при этом не теряя.

Закон 4 запрещает удалять, закон 43 требует не держать лишнего. Оба выполняются,
если не удалять, а ПЕРЕВОДИТЬ в архив с доказательством обратимости:

  1. считаем sha256 исходника;
  2. сжимаем (gzip -9), получаем .gz;
  3. распаковываем копию во временный файл и сверяем sha256 с исходником;
  4. выкладываем .gz в хранилище и скачиваем обратно, сверяя sha256;
  5. только после трёх совпадений исходник убирается из воркспейса.

Итог: байты не потеряны (их можно вернуть из .gz и из хранилища), место освобождено.

  python3 сжать.py переписка/журнал-арена-1383.md
  python3 сжать.py <файл> --без-хранилища    # без выкладки (не рекомендуется)
  python3 сжать.py --что                     # что можно сжать: файлы больше 5 МБ

Коды: 0 архив создан и проверен · 1 проверка не прошла (исходник не тронут) ·
      2 нет токена/сети (исходник не тронут)
"""
import argparse
import gzip
import hashlib
import json
import os
import shutil
import sys
import urllib.parse
import urllib.request

БАЗА = os.path.dirname(os.path.abspath(__file__))
КЛЮЧИ = os.path.join(БАЗА, "память", "ключи.txt")
РЕПОЗИТОРИЙ = "Ayt1741/hranilishe"
ВЕТКА = "main"
ПОРОГ = 5 * 1024 * 1024
ЧАСТЬ = 8 * 1024 * 1024


def sha256(путь):
    h = hashlib.sha256()
    with open(путь, "rb") as ф:
        for кусок in iter(lambda: ф.read(1 << 20), b""):
            h.update(кусок)
    return h.hexdigest()


def токен():
    if not os.path.exists(КЛЮЧИ):
        return ""
    for строка in open(КЛЮЧИ, encoding="utf-8"):
        if строка.strip().startswith("github="):
            return строка.strip().split("=", 1)[1]
    return ""


def положить(путь_в_репо, данные, тк):
    url = "https://api.github.com/repos/%s/contents/%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"))
    есть = None
    try:
        r = urllib.request.Request(url + "?ref=" + ВЕТКА, headers={
            "Authorization": "Bearer " + тк, "User-Agent": "szhat",
            "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(r, timeout=30) as о:
            есть = json.load(о).get("sha")
    except Exception:
        есть = None
    import base64
    тело = {"message": "архив: " + путь_в_репо,
            "content": base64.b64encode(данные).decode(), "branch": ВЕТКА}
    if есть:
        тело["sha"] = есть
    r = urllib.request.Request(url, data=json.dumps(тело).encode(), method="PUT", headers={
        "Authorization": "Bearer " + тк, "User-Agent": "szhat",
        "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=120) as о:
        return json.load(о).get("content", {}).get("sha", "")[:12]


def скачать(путь_в_репо, тк):
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"), ВЕТКА)
    r = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + тк, "User-Agent": "szhat",
        "Accept": "application/vnd.github.raw"})
    with urllib.request.urlopen(r, timeout=120) as о:
        return о.read()


def что_можно():
    print("файлы больше %d МБ:" % (ПОРОГ // 1048576))
    всего = 0
    for корень, каталоги, файлы in os.walk(БАЗА):
        каталоги[:] = [к for к in каталоги if к not in (".git", "__pycache__", ".cache")]
        for ф in файлы:
            п = os.path.join(корень, ф)
            р = os.path.getsize(п)
            if р >= ПОРОГ:
                всего += р
                print("  %10.1f МБ  %s%s" % (р / 1048576, os.path.relpath(п, БАЗА),
                                             "  (уже сжат)" if ф.endswith(".gz") else ""))
    print("итого крупного: %.1f МБ" % (всего / 1048576))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("файл", nargs="?", default="")
    ap.add_argument("--что", action="store_true")
    ap.add_argument("--без-хранилища", action="store_true")
    a = ap.parse_args()

    if a.что or not a.файл:
        что_можно()
        return 0

    исходник = os.path.join(БАЗА, a.файл) if not os.path.isabs(a.файл) else a.файл
    if not os.path.exists(исходник):
        print("ОШИБКА: нет файла %s" % исходник)
        return 1
    if исходник.endswith(".gz"):
        print("уже сжат: %s" % исходник)
        return 0

    было = os.path.getsize(исходник)
    хеш_исходника = sha256(исходник)
    print("исходник: %s, %.1f МБ, sha256 %s…" % (a.файл, было / 1048576, хеш_исходника[:12]))

    архив = исходник + ".gz"
    # 1. сжатие
    with open(исходник, "rb") as вх, gzip.open(архив, "wb", compresslevel=9) as вых:
        shutil.copyfileobj(вх, вых, 1 << 20)
    стало = os.path.getsize(архив)
    print("архив:    %s, %.1f МБ (сжатие %.0f%%)" % (os.path.basename(архив), стало / 1048576,
                                                    100 - стало * 100.0 / было))

    # 2. проверка обратимости локально
    with gzip.open(архив, "rb") as ф:
        h = hashlib.sha256()
        for кусок in iter(lambda: ф.read(1 << 20), b""):
            h.update(кусок)
    if h.hexdigest() != хеш_исходника:
        print("ОТКАЗ: распакованный архив не совпал с исходником. Исходник не тронут.")
        return 1
    print("  ✓ распаковка совпала с исходником посимвольно")

    # 3. выкладка в хранилище и обратное скачивание
    if not a.без_хранилища:
        тк = токен()
        if not тк:
            print("ОТКАЗ: нет токена github — архив остался, исходник не тронут.")
            return 2
        имя = "журнал/архив/" + os.path.basename(архив)
        данные = open(архив, "rb").read()
        части = [данные[i:i + ЧАСТЬ] for i in range(0, len(данные), ЧАСТЬ)] or [b""]
        for i, кусок in enumerate(части, 1):
            ш = положить("%s.часть%d" % (имя, i) if len(части) > 1 else имя, кусок, тк)
            print("  ↑ %s%s → %s" % (имя, (".часть%d" % i) if len(части) > 1 else "", ш))
        склейка = b""
        for i in range(1, len(части) + 1):
            склейка += скачать("%s.часть%d" % (имя, i) if len(части) > 1 else имя, тк)
        if hashlib.sha256(склейка).hexdigest() != sha256(архив):
            print("ОТКАЗ: скачанное из хранилища не совпало с архивом. Исходник не тронут.")
            return 1
        print("  ✓ скачано из хранилища и совпало с архивом")

    # 4. только теперь убираем исходник — он восстановим из архива и из хранилища
    os.remove(исходник)
    print("исходник убран из воркспейса; восстановление: gunzip %s" % os.path.basename(архив))
    print("\nИТОГ: освобождено %.1f МБ, байты сохранены (проверено дважды) — код 0"
          % ((было - стало) / 1048576))
    return 0


if __name__ == "__main__":
    sys.exit(main())
