#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""СОБРАТЬ — делает ПАНЕЛЬ.html: один файл, данные внутри. Открывается двойным кликом, без интернета и без Python.

  python3 панель/собрать.py           # пересобрать /home/user/ПАНЕЛЬ.html
Вызывается автоматически после каждого действия (из действие.py).
"""
import json, os, sys, datetime

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
ЛОГ = os.path.join(ЗДЕСЬ, "действия.jsonl")
СОСТОЯНИЕ = os.path.join(КОРЕНЬ, "память", "полный-состояние.json")
ШАБЛОН = os.path.join(ЗДЕСЬ, "panel.html")
ВЫХОД = os.path.join(КОРЕНЬ, "ПАНЕЛЬ.html")
ИСКЛ = {".cache", ".local", ".npm", ".config", "node_modules", "__pycache__", ".git", "uploads"}


def действия(предел=150):
    out = []
    if os.path.exists(ЛОГ):
        for с in open(ЛОГ, encoding="utf-8"):
            с = с.strip()
            if с:
                try:
                    out.append(json.loads(с))
                except Exception:
                    pass
    return out[-предел:]


def всё():
    if not os.path.exists(ЛОГ):
        return []
    out = []
    for с in open(ЛОГ, encoding="utf-8"):
        с = с.strip()
        if с:
            try:
                out.append(json.loads(с))
            except Exception:
                pass
    return out


def проверка(все):
    разрывы, целая, пред = [], True, ""
    for i, з in enumerate(все):
        if з.get("пред", "") != пред:
            целая = False
            разрывы.append(з.get("н"))
        if i and з.get("н") != (все[i - 1].get("н") or 0) + 1:
            целая = False
            разрывы.append(з.get("н"))
        пред = з.get("хеш", "")
    ход = все[-1].get("ход", 0) if все else 0
    в_ходе = [з for з in все if з.get("ход") == ход] if ход else []
    запрос = ""
    for з in в_ходе:
        if з.get("запрос"):
            запрос = з["запрос"]
            break
    переп = {}
    try:
        переп = json.load(open(СОСТОЯНИЕ, encoding="utf-8"))
    except Exception:
        pass
    return {"записей": len(все), "ход": ход, "запрос": запрос, "цепочка_целая": целая,
            "разрывы": разрывы[-10:], "действий_в_ходе": len(в_ходе),
            "правило_переписка_первой": bool(в_ходе) and "полный.py" in (в_ходе[0].get("команда", "")),
            "правило_ход_дописан": bool(в_ходе) and "ход.py" in (в_ходе[-1].get("команда", "")),
            "переписка": переп,
            "опубликовано": datetime.datetime.now().isoformat(timespec="seconds")}


def файлы(предел=30):
    import time
    стоп = time.time() - 3600
    out = []
    for кор, кат, им in os.walk(КОРЕНЬ):
        кат[:] = [к for к in кат if к not in ИСКЛ]
        for и in им:
            п = os.path.join(кор, и)
            try:
                s = os.stat(п)
            except OSError:
                continue
            if s.st_mtime < стоп:
                continue
            out.append({"путь": os.path.relpath(п, КОРЕНЬ), "б": s.st_size,
                        "когда": datetime.datetime.fromtimestamp(s.st_mtime).strftime("%H:%M:%S")})
    return sorted(out, key=lambda x: x["когда"], reverse=True)[:предел]


def main():
    все = всё()
    пр = проверка(все)
    в_ходе = [з for з in все if з.get("ход") == пр.get("ход")]
    import importlib.util as _иу
    сп = _иу.spec_from_file_location("законы", os.path.join(ЗДЕСЬ, "законы.py"))
    м = _иу.module_from_spec(сп); сп.loader.exec_module(м)
    данные = {"действия": действия(150), "проверка": пр, "файлы": файлы(),
              "законы": м.состояние(пр, в_ходе, {})}
    ш = open(ШАБЛОН, encoding="utf-8").read()
    внутри = json.dumps(данные, ensure_ascii=False).replace("</", "<\\/")
    html = ш.replace("var ВСТРОЕНО = window.__ДАННЫЕ__ || null;",
                     "var ВСТРОЕНО = " + внутри + ";")
    html = html.replace('<div style="margin:18px 0 30px;color:#5d6a7a;font-size:11.5px">',
                        '<div style="margin:18px 0 6px;color:#8b97a8;font-size:12px">Это файл-снимок: открывается двойным кликом, '
                        'без интернета. Свежие данные — после каждого моего действия файл пересобирается заново.</div>'
                        '<div style="margin:0 0 30px;color:#5d6a7a;font-size:11.5px">')
    open(ВЫХОД, "w", encoding="utf-8").write(html)
    print("ПАНЕЛЬ.html:", os.path.getsize(ВЫХОД), "б ·", len(данные["действия"]), "действий · ход", данные["проверка"]["ход"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
