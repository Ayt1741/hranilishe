#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ОПУБЛИКОВАТЬ — выкладывает панель в интернет, чтобы её открывать с телефона/ПК без меня.

Кладёт в репозиторий на GitHub Pages два файла:
  panel.html       страница панели (сама тянет actions.json и рисует ленту)
  actions.json     лента действий + проверка цепочки + файлы + состояние переписки

  python3 панель/опубликовать.py

Токен берётся из память/ключи.txt (строка github=...). Ничего не удаляет, только кладёт/обновляет два файла.
"""
import base64, datetime, json, os, sys, time, urllib.error, urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
ЛОГ = os.path.join(ЗДЕСЬ, "действия.jsonl")
СОСТОЯНИЕ = os.path.join(КОРЕНЬ, "память", "полный-состояние.json")
РЕПО = "Ayt1741/hranilishe"
ВЕТКА = "main"
АДРЕС = "https://ayt1741.github.io/hranilishe/panel.html"


def токен():
    п = os.path.join(КОРЕНЬ, "память", "ключи.txt")
    for с in open(п, encoding="utf-8"):
        if с.strip().startswith("github="):
            return с.strip().split("=", 1)[1]
    return ""


def действия(предел=200):
    out = []
    if os.path.exists(ЛОГ):
        for с in open(ЛОГ, encoding="utf-8"):
            с = с.strip()
            if с:
                try:
                    out.append(json.loads(с))
                except Exception:
                    pass
    return out[-предел:]


def проверка(все):
    разрывы, связная, пред = [], True, ""
    for i, з in enumerate(все):
        if з.get("пред", "") != пред:
            связная = False
            разрывы.append(з.get("н"))
        if i and з.get("н") != (все[i - 1].get("н") or 0) + 1:
            связная = False
            разрывы.append(з.get("н"))
        пред = з.get("хеш", "")
    ход = все[-1].get("ход", 0) if все else 0
    в_ходе = [з for з in все if з.get("ход") == ход] if ход else []
    запрос = ""
    for з in в_ходе:
        if з.get("запрос"):
            запрос = з["запрос"]
            break
    переп = {}
    try:
        переп = json.load(open(СОСТОЯНИЕ, encoding="utf-8"))
    except Exception:
        pass
    return {
        "записей": len(все), "ход": ход, "запрос": запрос, "цепочка_целая": связная,
        "разрывы": разрывы[-10:], "действий_в_ходе": len(в_ходе),
        "правило_переписка_первой": bool(в_ходе) and "полный.py" in (в_ходе[0].get("команда", "")),
        "правило_ход_дописан": bool(в_ходе) and "ход.py" in (в_ходе[-1].get("команда", "")),
        "переписка": переп,
        "опубликовано": datetime.datetime.now().isoformat(timespec="seconds"),
    }


def файлы(минут=60, предел=40):
    стоп = time.time() - минут * 60
    иск = {".cache", ".local", ".npm", ".config", "node_modules", "__pycache__", ".git", "uploads"}
    out = []
    for кор, кат, им in os.walk(КОРЕНЬ):
        кат[:] = [к for к in кат if к not in иск]
        for и in им:
            п = os.path.join(кор, и)
            try:
                s = os.stat(п)
            except OSError:
                continue
            if s.st_mtime < стоп:
                continue
            out.append({"путь": os.path.relpath(п, КОРЕНЬ), "б": s.st_size,
                        "когда": datetime.datetime.fromtimestamp(s.st_mtime).strftime("%H:%M:%S")})
    return sorted(out, key=lambda x: x["когда"], reverse=True)[:предел]


def положить(путь, данные_байт, тк, сообщение, попыток=4):
    последняя = None
    for _ in range(попыток):
        try:
            return положить1(путь, данные_байт, тк, сообщение)
        except urllib.error.HTTPError as e:
            последняя = e
            if e.code in (409, 422, 500, 502, 504):
                time.sleep(2)
                continue
            raise
    raise последняя


def положить1(путь, данные_байт, тк, сообщение):
    url = "https://api.github.com/repos/%s/contents/%s" % (РЕПО, путь)
    ша = None
    try:
        r = urllib.request.Request(url, headers={"Authorization": "Bearer " + тк, "User-Agent": "panel"})
        ша = json.load(urllib.request.urlopen(r, timeout=40)).get("sha")
    except Exception:
        ша = None
    тело = {"message": сообщение, "branch": ВЕТКА,
            "content": base64.b64encode(данные_байт).decode()}
    if ша:
        тело["sha"] = ша
    r = urllib.request.Request(url, data=json.dumps(тело).encode(), method="PUT",
                               headers={"Authorization": "Bearer " + тк, "User-Agent": "panel",
                                        "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(r, timeout=180) as x:
        return x.status


def main():
    тк = токен()
    if not тк:
        print("нет токена github в память/ключи.txt")
        return 1
    все = действия(100000)
    пр = проверка(все)
    в_ходе = [з for з in все if з.get("ход") == пр.get("ход")]
    import importlib.util as _иу
    сп = _иу.spec_from_file_location("законы", os.path.join(ЗДЕСЬ, "законы.py"))
    м = _иу.module_from_spec(сп); сп.loader.exec_module(м)
    данные = {"действия": действия(200), "проверка": пр, "файлы": файлы(),
              "законы": м.состояние(пр, в_ходе, {})}
    # Ход 83: раньше здесь публиковался ШАБЛОН panel.html. Когда в шаблоне лежали вшитые
    # данные, это случайно давало запасной вариант для офлайна. В ходе 82 я заменил их маркером —
    # и на сайт стал уходить шаблон с ВСТРОЕНО = null: без сети панель не рисует НИЧЕГО.
    # Теперь собираем страницу тем же прибором, что делает ПАНЕЛЬ.html: данные внутри файла.
    import subprocess as _sp
    _сбор = _sp.run([sys.executable, os.path.join(ЗДЕСЬ, "собрать.py")],
                    capture_output=True, text=True, timeout=180)
    _готовая = os.path.join(КОРЕНЬ, "ПАНЕЛЬ.html")
    html = open(_готовая, encoding="utf-8").read() if os.path.exists(_готовая) else \
        open(os.path.join(ЗДЕСЬ, "panel.html"), encoding="utf-8").read()
    # Проверяем НЕ отсутствие маркера (он остаётся объявлением в шаблоне), а наличие данных:
    # без вшитых действий страница у заказчика без сети не нарисует ничего.
    import re as _re
    _м = _re.search(r"var ВСТРОЕНО = (\{.*?\});", html, _re.S)
    if not _м:
        print("ОТКАЗ ПУБЛИКАЦИИ: страница без вшитых данных (у заказчика без сети будет пусто)")
        return 1
    try:
        _д = json.loads(_м.group(1))
    except ValueError:
        print("ОТКАЗ ПУБЛИКАЦИИ: вшитые данные не разбираются — страница пустая")
        return 1
    if not (_д.get("действия") or []):
        print("ОТКАЗ ПУБЛИКАЦИИ: вшитых действий нет (у заказчика без сети будет пусто)")
        return 1
    # ход 55: перед публикацией — скан того, что уходит в интернет (ключи, пароли, почты аккаунтов). Находка = отказ.
    _с = _иу.spec_from_file_location("скан", os.path.join(ЗДЕСЬ, "скан-ленты.py"))
    _скан = _иу.module_from_spec(_с); _с.loader.exec_module(_скан)
    _h2 = open(os.path.join(ЗДЕСЬ, "panel2.html"), encoding="utf-8").read() if os.path.exists(os.path.join(ЗДЕСЬ, "panel2.html")) else ""
    находки = _скан.найти(json.dumps(данные, ensure_ascii=False)) + _скан.найти(html) + _скан.найти(_h2)
    if находки:
        print("ОТКАЗ ПУБЛИКАЦИИ: в ленте найдены секреты:", sorted(set(находки)))
        return 1
    print("panel.html:", положить("panel.html", html.encode("utf-8"), тк, "панель действий: страница"))
    h2 = open(os.path.join(ЗДЕСЬ, "panel2.html"), encoding="utf-8").read() if os.path.exists(os.path.join(ЗДЕСЬ,"panel2.html")) else html
    print("panel2.html:", положить("panel2.html", h2.encode("utf-8"), тк, "панель действий: страница (новое имя без кэша CDN)"))
    print("actions.json:", положить("actions.json", json.dumps(данные, ensure_ascii=False).encode("utf-8"),
                                    тк, "панель действий: лента"))
    print("адрес:", АДРЕС)
    return 0


if __name__ == "__main__":
    sys.exit(main())
