#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ЧАТ — обмен сообщениями между тобой и агентом прямо во время работы.

  python3 панель/чат.py --я "текст"          # ты пишешь агенту
  python3 панель/чат.py --агент "текст"      # агент отвечает
  python3 панель/чат.py --новые              # что агент ещё не прочитал
  python3 панель/чат.py --отметить           # отметить прочитанным
  python3 панель/чат.py --все                # вся переписка чата

Хранится в панель/чат.jsonl, только дозапись, ничего не удаляется.
"""
import argparse, datetime, json, os, sys

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
ФАЙЛ = os.path.join(ЗДЕСЬ, "чат.jsonl")
МЕТКА = os.path.join(ЗДЕСЬ, ".чат-прочитано")


def все():
    out = []
    if os.path.exists(ФАЙЛ):
        for с in open(ФАЙЛ, encoding="utf-8"):
            с = с.strip()
            if с:
                try:
                    out.append(json.loads(с))
                except Exception:
                    pass
    return out


def добавить(кто, текст):
    з = все()
    зап = {"н": len(з) + 1, "кто": кто, "текст": текст,
           "в": datetime.datetime.now().isoformat(timespec="seconds")}
    with open(ФАЙЛ, "a", encoding="utf-8") as f:
        f.write(json.dumps(зап, ensure_ascii=False) + "\n")
    return зап


def прочитано_до():
    try:
        return int(open(МЕТКА).read().strip() or 0)
    except Exception:
        return 0


def main():
    а = argparse.ArgumentParser()
    а.add_argument("--я", default="")
    а.add_argument("--агент", default="")
    а.add_argument("--новые", action="store_true")
    а.add_argument("--отметить", action="store_true")
    а.add_argument("--все", action="store_true")
    п = а.parse_args()
    if п.я:
        з = добавить("ты", п.я)
        print("ты → №%d: %s" % (з["н"], з["текст"][:120]))
    if п.агент:
        з = добавить("агент", п.агент)
        print("агент → №%d: %s" % (з["н"], з["текст"][:120]))
    if п.новые:
        до = прочитано_до()
        новые = [з for з in все() if з["н"] > до and з["кто"] == "ты"]
        if не_пусто := новые:
            print("=== НОВЫЕ СООБЩЕНИЯ ОТ ПОЛЬЗОВАТЕЛЯ: %d ===" % len(новые))
            for з in новые:
                print("№%d %s: %s" % (з["н"], з["в"][11:], з["текст"]))
        return 0
    if п.отметить:
        з = все()
        open(МЕТКА, "w").write(str(з[-1]["н"] if з else 0))
        print("отмечено прочитанным до №%s" % (з[-1]["н"] if з else 0))
    if п.все:
        for з in все():
            print("#%d %s %s: %s" % (з["н"], з["в"][11:], з["кто"], з["текст"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
