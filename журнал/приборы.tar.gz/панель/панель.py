#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ПАНЕЛЬ — живой экран действий агента. Только стандартная библиотека.

  python3 панель/панель.py            # слушает 0.0.0.0:8099

Страницы:
  /            живая лента (обновляется по SSE, без перезагрузки)
  /снимок      полный JSON: действия + проверка цепочки + файлы + состояние переписки
  /проверка    только проверка цепочки
  /файлы       файлы воркспейса, изменённые за последние 60 минут
"""
import datetime, json, os, time, hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
ЛОГ = os.path.join(ЗДЕСЬ, "действия.jsonl")
СОСТОЯНИЕ = os.path.join(КОРЕНЬ, "память", "полный-состояние.json")
ПОРТ = 8099
ИСКЛЮЧИТЬ = {".cache", ".local", ".npm", ".config", "node_modules", "__pycache__", ".git",
             ".playwright-cli", "uploads", ".arena", ".venv"}


def действия(предел=300):
    out = []
    if os.path.exists(ЛОГ):
        with open(ЛОГ, encoding="utf-8") as f:
            for s in f:
                s = s.strip()
                if s:
                    try:
                        out.append(json.loads(s))
                    except Exception:
                        pass
    return out[-предел:]


def проверка():
    все = действия(100000)
    разрывы, связная = [], True
    пред = ""
    for i, з in enumerate(все):
        if з.get("пред", "") != пред:
            связная = False
            разрывы.append(з.get("н"))
        if i and з.get("н") != (все[i - 1].get("н") or 0) + 1:
            связная = False
            разрывы.append(з.get("н"))
        пред = з.get("хеш", "")
    ход = все[-1].get("ход", 0) if все else 0
    в_ходе = [з for з in все if з.get("ход") == ход] if ход else []
    запрос = ""
    for з in в_ходе:
        if з.get("запрос"):
            запрос = з["запрос"]
            break
    if not запрос:
        for з in reversed(все):
            if з.get("запрос"):
                запрос = з["запрос"]
                break
    правило1 = bool(в_ходе) and any("полный.py" == ч or "полный.py" in ч.split()[1:3] for ч in [в_ходе[0].get("команда","")])
    правило3 = bool(в_ходе) and "ход.py" in (в_ходе[-1].get("команда", "") + в_ходе[-1].get("что", ""))
    переписка = {}
    try:
        with open(СОСТОЯНИЕ, encoding="utf-8") as f:
            переписка = json.load(f)
    except Exception:
        pass
    return {"записей": len(все), "ход": ход, "запрос": запрос, "цепочка_целая": связная,
            "разрывы": разрывы[-10:], "действий_в_ходе": len(в_ходе),
            "правило_переписка_первой": правило1, "правило_ход_дописан": правило3,
            "переписка": переписка}


def файлы(минут=60):
    предел = time.time() - минут * 60
    out = []
    for корень, каталоги, имена in os.walk(КОРЕНЬ):
        каталоги[:] = [к for к in каталоги if к not in ИСКЛЮЧИТЬ and not к.startswith(".git")]
        for и in имена:
            п = os.path.join(корень, и)
            try:
                s = os.stat(п)
            except OSError:
                continue
            if s.st_mtime < предел:
                continue
            out.append({"путь": os.path.relpath(п, КОРЕНЬ), "б": s.st_size,
                        "когда": datetime.datetime.fromtimestamp(s.st_mtime).strftime("%H:%M:%S")})
    return sorted(out, key=lambda x: x["когда"], reverse=True)[:60]


СТРАНИЦА = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Панель действий агента</title></head>
<body style="margin:0;background:#0b0e13;color:#dfe7f2;font:13px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace">
<div style="max-width:980px;margin:0 auto;padding:14px">
  <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <b style="font-size:17px;color:#cfe3ff">Панель действий агента</b>
    <span id="ж" style="display:inline-flex;align-items:center;gap:6px;background:#16202c;border:1px solid #24303f;border-radius:20px;padding:3px 10px">
      <span id="точка" style="width:9px;height:9px;border-radius:50%;background:#8b97a8"></span><span id="жт">ожидание</span>
    </span>
    <span id="обн" style="color:#6b7889;font-size:11.5px"></span>
  </div>

  <div style="background:#101c2b;border:1px solid #2b4a7a;border-radius:12px;padding:11px 13px;margin:12px 0">
    <div style="font-size:11.5px;color:#8b97a8;text-transform:uppercase;letter-spacing:.5px">Запрос пользователя, над которым идёт работа</div>
    <div id="запрос" style="margin-top:5px;color:#e8f0fb">—</div>
  </div>

  <div style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:12px">
    <div style="flex:1 1 150px;background:#0f1520;border:1px solid #222c3a;border-radius:11px;padding:9px 11px">
      <b id="цзаписей" style="display:block;font-size:21px;color:#9fc6ff">0</b><span style="font-size:11px;color:#8b97a8">действий записано</span></div>
    <div style="flex:1 1 150px;background:#0f1520;border:1px solid #222c3a;border-radius:11px;padding:9px 11px">
      <b id="цход" style="display:block;font-size:21px;color:#9fc6ff">0</b><span style="font-size:11px;color:#8b97a8">действий в этом ходе</span></div>
    <div style="flex:1 1 150px;background:#0f1520;border:1px solid #222c3a;border-radius:11px;padding:9px 11px">
      <b id="цпереп" style="display:block;font-size:21px;color:#9fc6ff">—</b><span style="font-size:11px;color:#8b97a8">записей переписки прочитано</span></div>
    <div style="flex:1 1 150px;background:#0f1520;border:1px solid #222c3a;border-radius:11px;padding:9px 11px">
      <b id="ццеп" style="display:block;font-size:21px">—</b><span style="font-size:11px;color:#8b97a8">хеш-цепочка</span></div>
  </div>

  <div id="правила" style="background:#0f1520;border:1px solid #222c3a;border-radius:11px;padding:10px 13px;margin-bottom:12px;font-size:12.5px"></div>

  <div style="font-size:11.5px;color:#8b97a8;text-transform:uppercase;letter-spacing:.5px;margin:14px 0 6px">Лента действий — каждое, по порядку</div>
  <div id="лента"></div>

  <div style="font-size:11.5px;color:#8b97a8;text-transform:uppercase;letter-spacing:.5px;margin:18px 0 6px">Файлы, изменённые за последний час (независимо от журнала)</div>
  <div id="файлы" style="font-size:12px;color:#a9b8cb"></div>

  <div style="margin:18px 0 30px;color:#5d6a7a;font-size:11.5px">
    Лента пишется скриптом <b>панель/действие.py</b>: каждая запись ссылается хешем на предыдущую, поэтому пропуск или правку видно.
    Файлы справа считаются по времени изменения на диске — это не мои слова.
  </div>
</div>
<script>
function esc(t){return String(t==null?"":t).replace(/[<>&]/g,function(c){return {"<":"&lt;",">":"&gt;","&":"&amp;"}[c]})}
function зн(v){return v?'<span style="color:#5ee6a0">✓</span>':'<span style="color:#ff7d7d">✗</span>'}
function рисовать(д){
  var п=д.проверка||{}, актив=д.активно;
  document.getElementById("точка").style.background=актив?"#5ee6a0":"#8b97a8";
  document.getElementById("жт").textContent=актив?"агент работает":"ожидание";
  document.getElementById("обн").textContent="обновлено "+new Date().toLocaleTimeString("ru-RU");
  document.getElementById("запрос").textContent=п.запрос||"—";
  document.getElementById("цзаписей").textContent=п["записей"]||0;
  document.getElementById("цход").textContent=п["действий_в_ходе"]||0;
  var пер=п.переписка||{};
  document.getElementById("цпереп").textContent=пер["записей"]?(пер["записей"]+" / "+пер["символов"]):"—";
  var ц=document.getElementById("ццеп");
  ц.textContent=п["цепочка_целая"]?"целая":"порвана";
  ц.style.color=п["цепочка_целая"]?"#5ee6a0":"#ff7d7d";
  document.getElementById("правила").innerHTML=
    зн(п["правило_переписка_первой"])+' первым действием хода прочитана вся переписка'+
    (пер.sha256?' <span style="color:#6b7889">· sha256 '+esc(String(пер.sha256).slice(0,16))+'…</span>':'')+'<br>'+
    зн(п["правило_ход_дописан"])+' ход (запрос и ответ) дописан в журнал переписки<br>'+
    зн(п["цепочка_целая"])+' ни одно действие не выпало из цепочки'+
    ((п.разрывы&&п.разрывы.length)?' <span style="color:#ff7d7d">· разрывы на №'+esc(п.разрывы.join(", "))+'</span>':'');
  var л=(д.действия||[]).slice().reverse(), с="";
  for(var i=0;i<л.length;i++){var з=л[i];
    var цвет=з.код===0?"#5ee6a0":"#ff7d7d";
    с+='<details style="background:#0f1520;border:1px solid #222c3a;border-left:3px solid '+цвет+';border-radius:9px;padding:8px 11px;margin-bottom:6px">'+
       '<summary style="cursor:pointer;list-style:none">'+
       '<span style="color:#6b7889">№'+з.н+' · '+(з.ход?("ход "+з.ход):"без хода")+' · '+esc(з.в.split("T")[1])+'</span> '+
       '<b style="color:#dfe7f2">'+esc(з.что)+'</b>'+
       '<span style="color:#6b7889"> · код '+з.код+' · '+з.сек+' с · '+з["символов"]+' симв. · sha '+esc((з.хеш||"").slice(0,8))+'</span></summary>'+
       '<div style="margin-top:6px;color:#8b97a8;font-size:11.5px;word-break:break-all">команда: '+esc(з.команда||"—")+'</div>'+
       '<pre style="margin:6px 0 0;white-space:pre-wrap;word-break:break-word;color:#b8c6d8;font-size:11.5px">'+esc((з.вывод||"").slice(0,1200))+'</pre></details>';}
  document.getElementById("лента").innerHTML=с||'<div style="color:#6b7889">пока пусто</div>';
  var ф=д.файлы||[], фс="";
  for(var j=0;j<ф.length;j++)фс+='<div>'+esc(ф[j].когда)+' · '+esc(ф[j].путь)+' · '+ф[j].б+' б</div>';
  document.getElementById("файлы").innerHTML=фс||'<div style="color:#6b7889">нет изменений</div>';
}
function тян(){
  fetch("снимок",{cache:"no-store"}).then(function(r){return r.json()}).then(рисовать).catch(function(){});
}
тян(); setInterval(тян,2000);
</script></body></html>"""


class Обработчик(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _отдать(self, код, тело, тип):
        д = тело.encode("utf-8") if isinstance(тело, str) else тело
        self.send_response(код)
        self.send_header("Content-Type", тип)
        self.send_header("Content-Length", str(len(д)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(д)

    def do_POST(self):
        import json as _j, datetime as _dt
        длин = int(self.headers.get("Content-Length") or 0)
        тело = self.rfile.read(длин).decode("utf-8", "replace") if длин else "{}"
        сырой = urlparse(self.path).path
        try:
            сырой = сырой.encode("iso-8859-1").decode("utf-8")
        except Exception:
            pass
        if unquote(сырой).rstrip("/") == "/чат":
            try:
                д = _j.loads(тело)
            except Exception:
                д = {}
            текст = (д.get("текст") or "").strip()
            if not текст:
                self._отдать(400, "пусто", "text/plain; charset=utf-8")
                return
            фа = os.path.join(ЗДЕСЬ, "чат.jsonl")
            з = []
            if os.path.exists(фа):
                for с in open(фа, encoding="utf-8"):
                    с = с.strip()
                    if с:
                        try:
                            з.append(_j.loads(с))
                        except Exception:
                            pass
            зап = {"н": len(з) + 1, "кто": "ты", "текст": текст,
                   "в": _dt.datetime.now().isoformat(timespec="seconds")}
            with open(фа, "a", encoding="utf-8") as f:
                f.write(_j.dumps(зап, ensure_ascii=False) + "\n")
            self._отдать(200, _j.dumps(зап, ensure_ascii=False), "application/json; charset=utf-8")
        else:
            self._отдать(404, "нет такой страницы", "text/plain; charset=utf-8")

    def do_GET(self):
        сырой = urlparse(self.path).path
        try:  # http.server отдаёт путь в iso-8859-1 — возвращаем кириллицу как есть
            сырой = сырой.encode("iso-8859-1").decode("utf-8")
        except Exception:
            pass
        п = unquote(сырой).rstrip("/") or "/"
        if п in ("/", "/index.html"):
            ф = os.path.join(ЗДЕСЬ, "panel.html")
            html = open(ф, encoding="utf-8").read() if os.path.exists(ф) else СТРАНИЦА
            self._отдать(200, html, "text/html; charset=utf-8")
        elif п == "/снимок":
            д = действия()
            актив = bool(д) and (time.time() - datetime.datetime.fromisoformat(д[-1]["в"]).timestamp()) < 90
            self._отдать(200, json.dumps({"действия": д, "проверка": проверка(), "файлы": файлы(), "активно": актив},
                                         ensure_ascii=False), "application/json; charset=utf-8")
        elif п == "/проверка":
            self._отдать(200, json.dumps(проверка(), ensure_ascii=False), "application/json; charset=utf-8")
        elif п == "/actions.json":
            пр = проверка()
            в_ходе = [з for з in действия() if з.get("ход") == пр.get("ход")]
            import importlib.util as _иу
            сп = _иу.spec_from_file_location("законы", os.path.join(ЗДЕСЬ, "законы.py"))
            м = _иу.module_from_spec(сп); сп.loader.exec_module(м)
            д = {"действия": действия(), "проверка": пр, "файлы": файлы(),
                 "законы": м.состояние(пр, в_ходе, {})}
            self._отдать(200, json.dumps(д, ensure_ascii=False), "application/json; charset=utf-8")
        elif п == "/чат":
            import json as _j
            з = []
            if os.path.exists(os.path.join(ЗДЕСЬ, "чат.jsonl")):
                for с in open(os.path.join(ЗДЕСЬ, "чат.jsonl"), encoding="utf-8"):
                    с = с.strip()
                    if с:
                        try:
                            з.append(_j.loads(с))
                        except Exception:
                            pass
            self._отдать(200, _j.dumps(з[-100:], ensure_ascii=False), "application/json; charset=utf-8")
        elif п == "/файлы":
            self._отдать(200, json.dumps(файлы(), ensure_ascii=False), "application/json; charset=utf-8")
        else:
            self._отдать(404, "нет такой страницы", "text/plain; charset=utf-8")


if __name__ == "__main__":
    серв = ThreadingHTTPServer(("0.0.0.0", ПОРТ), Обработчик)
    print("панель: http://0.0.0.0:%d/" % ПОРТ, flush=True)
    серв.serve_forever()
