#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ДЕЙСТВИЕ — единственный способ, которым агент выполняет что-либо в этом воркспейсе.

Каждый вызов запускает команду и ДОПИСЫВАЕТ в панель/действия.jsonl запись:
  номер, время, номер хода, текст запроса пользователя, что именно сделано,
  сама команда, код выхода, размер и sha256 вывода, фрагмент вывода,
  хеш предыдущей записи (цепочка — порвать незаметно нельзя).

  python3 панель/действие.py "что делаю" -- команда аргументы...
  python3 панель/действие.py "новый ход" --ход N --запрос "текст запроса" -- команда...

Записи только добавляются. Ничего не удаляет.
"""
import argparse, datetime, hashlib, json, os, re, subprocess, sys, time

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
ЛОГ = os.path.join(ЗДЕСЬ, "действия.jsonl")
ФРАГМЕНТ = 1500
# П1 (ход 62): проверка ДЕЙСТВИЙ до выполнения. Выключается только явно переменной КУХНЯ_СТРАЖ=0.
СТРАЖ_ВКЛЮЧЁН = os.environ.get("КУХНЯ_СТРАЖ", "1") != "0"
СТРАЖ_ФАЙЛ = os.path.join(ЗДЕСЬ, "страж.py")

# ход 55: ключи, которые заказчик присылает в чат, раньше попадали в ПУБЛИЧНУЮ ленту через поле «запрос»
# (так в actions.json оказался ключ DeepSeek). Теперь всё, что похоже на ключ, маскируется ДО записи и публикации.
_ШАБЛОНЫ_КЛЮЧЕЙ = [
    (r"\b\d{8,10}:[A-Za-z0-9_\-\\]{30,50}", "токен Telegram"),
    (r"github_pat_[A-Za-z0-9_]{20,}", "токен GitHub"),
    (r"\bgh[pousr]_[A-Za-z0-9]{20,}", "токен GitHub"),
    (r"\bgsk_[A-Za-z0-9]{20,}", "ключ Groq"),
    (r"\bsk-or-v1-[A-Za-z0-9]{20,}", "ключ OpenRouter"),
    (r"\bsk-[A-Za-z0-9\-]{20,}", "ключ sk-"),
    (r"\btvly-[A-Za-z0-9_\-]{16,}", "ключ Tavily"),
    (r"\bhf_[A-Za-z0-9]{20,}", "ключ Hugging Face"),
    (r"\bKGAT_[A-Za-z0-9]{16,}", "ключ Kaggle"),
    (r"\bjina_[A-Za-z0-9]{20,}", "ключ Jina"),
    (r"\bfc-[A-Za-z0-9]{20,}", "ключ Firecrawl"),
    (r"\bmstrl_[A-Za-z0-9_\-]{16,}", "ключ Mistral"),
    (r"VENICE_INFERENCE_KEY_[A-Za-z0-9]{16,}", "ключ Venice"),
    (r"\bcfat_[A-Za-z0-9]{16,}", "ключ Cloudflare"),
    (r"\beyJ[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{10,}", "JWT"),
]


def маска(текст):
    """Скрыть ключи в тексте, который уходит в ленту. Исполняемую команду это не затрагивает."""
    if not текст:
        return текст
    for шаблон, имя in _ШАБЛОНЫ_КЛЮЧЕЙ:
        текст = re.sub(шаблон, "[скрыто: %s]" % имя, текст)
    try:  # точные значения из файла ключей (кроме id канала)
        п = os.path.join(os.path.dirname(ЗДЕСЬ), "память", "ключи.txt")
        for с in open(п, encoding="utf-8"):
            if "=" in с and not с.lstrip().startswith("#"):
                к, з = с.strip().split("=", 1)
                if к.strip() != "телеграм_канал" and len(з.strip()) >= 12:
                    текст = текст.replace(з.strip(), "[скрыто: %s]" % к.strip())
    except OSError:
        pass
    try:  # логины и пароли аккаунтов Arena (формат: NN|почта|пароль)
        п = os.path.join(os.path.dirname(ЗДЕСЬ), "память", "аккаунты.txt")
        for с in open(п, encoding="utf-8"):
            ч = с.strip().split("|")
            if len(ч) >= 3 and not с.startswith("#"):
                for з in ч[1:3]:
                    if len(з) >= 6:
                        текст = текст.replace(з, "[скрыто: аккаунт Arena]")
    except OSError:
        pass
    return текст


def записи():
    out = []
    if os.path.exists(ЛОГ):
        with open(ЛОГ, encoding="utf-8") as f:
            for s in f:
                s = s.strip()
                if s:
                    try:
                        out.append(json.loads(s))
                    except Exception:
                        pass
    return out


def main():
    argv = sys.argv[1:]
    ход = 0
    запрос = ""
    if "--ход" in argv:
        i = argv.index("--ход")
        ход = int(argv[i + 1])
        del argv[i:i + 2]
    if "--запрос" in argv:
        i = argv.index("--запрос")
        запрос = argv[i + 1]
        del argv[i:i + 2]
    if "--" in argv:
        i = argv.index("--")
        что = " ".join(argv[:i]).strip()
        cmd = argv[i + 1:]
    else:
        что = " ".join(argv).strip()
        cmd = []
    if not что:
        what = "пусто"
    старые = записи()
    пред = старые[-1].get("хеш", "") if старые else ""
    ном = (старые[-1].get("н") or 0) + 1 if старые else 1
    # --- ЧАТ: сначала проверяем, не написал ли пользователь что-то во время работы ---
    чат_новые = ""
    try:
        import subprocess as _sp2
        р2 = _sp2.run([sys.executable, os.path.join(ЗДЕСЬ, "чат.py"), "--новые"],
                      capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        if "НОВЫЕ СООБЩЕНИЯ" in (р2.stdout or ""):
            чат_новые = р2.stdout.strip()
    except Exception:
        pass
    # --- П1: СТРАЖ ДЕЙСТВИЙ (проверка ДО выполнения, как PreToolUse-хук) ---
    решение = {"исход": "allow", "правило": "", "причина": ""}
    if cmd and СТРАЖ_ВКЛЮЧЁН and os.path.exists(СТРАЖ_ФАЙЛ):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("страж", СТРАЖ_ФАЙЛ)
            страж = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(страж)
            решение = страж.проверить_действие(что, cmd)
        except Exception as e:
            решение = {"исход": "allow", "правило": "", "причина": "страж упал: %s" % e}
    if решение["исход"] == "block":
        print("[страж] ДЕЙСТВИЕ ЗАБЛОКИРОВАНО (%s): %s" % (решение["правило"], решение["причина"]))
        print("[страж] команда не выполнена. Если это ошибка — переформулируй действие или КУХНЯ_СТРАЖ=0 с причиной.")

    начало = datetime.datetime.now()
    код, вывод = 0, ""
    if cmd and решение["исход"] != "block":
        try:
            р = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1500)
            код = р.returncode
            вывод = (р.stdout or "") + (("\n[stderr] " + р.stderr) if р.stderr else "")
        except subprocess.TimeoutExpired:
            код, вывод = -9, "таймаут 1500 с"
        except Exception as e:
            код, вывод = -1, "ошибка запуска: %s" % e
    if решение["исход"] == "block":
        код = 3   # блок стража виден в журнале как код 3, а не как «успех 0»
    секунд = round((datetime.datetime.now() - начало).total_seconds(), 2)
    вывод = маска(вывод)
    хеш = hashlib.sha256(вывод.encode("utf-8", "ignore")).hexdigest()
    # ход 55: номер и хеш предыдущей записи берём В МОМЕНТ ЗАПИСИ под блокировкой — два параллельных вызова раньше получили один номер (№509 дважды)
    import fcntl
    блок = open(ЛОГ + ".lock", "a")
    fcntl.flock(блок, fcntl.LOCK_EX)
    старые = записи()
    пред = старые[-1].get("хеш", "") if старые else ""
    ном = (старые[-1].get("н") or 0) + 1 if старые else 1
    зап = {
        "н": ном, "в": начало.isoformat(timespec="seconds"), "ход": ход, "запрос": маска(запрос),
        "что": маска(что), "команда": маска(" ".join(cmd)), "код": код, "сек": секунд,
        "символов": len(вывод), "хеш": хеш, "пред": пред,
        # хранить голову И ХВОСТ: результат публикации печатается в конце команды,
        # при обрезке только головы он терялся (поймано проверкой К5)
        "страж": решение,
        "вывод": (вывод if len(вывод) <= ФРАГМЕНТ
                  else вывод[:ФРАГМЕНТ - 900] + "\n…(середина опущена)…\n" + вывод[-900:]),
    }
    with open(ЛОГ, "a", encoding="utf-8") as f:
        f.write(json.dumps(зап, ensure_ascii=False) + "\n")
    fcntl.flock(блок, fcntl.LOCK_UN)
    блок.close()
    # сразу обновляем локальный снимок для страницы (в интернет его выкладывает опубликовать.py)
    try:
        снимок = os.path.join(ЗДЕСЬ, "actions.json")
        json.dump({"действия": (старые[-199:] + [зап])}, open(снимок, "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass
    if вывод:
        sys.stdout.write(вывод if len(вывод) <= 20000 else вывод[:20000] + "\n…(обрезано в консоли, целиком в панели)\n")
    if чат_новые:
        print("\n" + "!" * 70)
        print("ПОЛЬЗОВАТЕЛЬ НАПИСАЛ В ЧАТ ВО ВРЕМЯ РАБОТЫ:")
        print(чат_новые)
        print("!" * 70 + "\n")
        try:
            import subprocess as _sp3
            _sp3.run([sys.executable, os.path.join(ЗДЕСЬ, "чат.py"), "--отметить"], timeout=20)
        except Exception:
            pass
    try:  # автоматически выложить свежую ленту на сайт (не чаще раза в 40 с, в фоне)
        метка = os.path.join(ЗДЕСЬ, ".публикация")
        прошло = time.time() - (os.path.getmtime(метка) if os.path.exists(метка) else 0)
        if прошло > 40:
            open(метка, "w").write(str(time.time()))
            subprocess.Popen([sys.executable, os.path.join(ЗДЕСЬ, "опубликовать.py")],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
    try:  # пересобрать файл-снимок ПАНЕЛЬ.html, чтобы его можно было открыть двойным кликом
        import subprocess as _sp
        _sp.run([sys.executable, os.path.join(ЗДЕСЬ, "собрать.py")], capture_output=True, timeout=120)
    except Exception:
        pass
    print("\n[панель] запись №%d · ход %s · код %d · %s с · sha256 %s…%s" % (
        ном, ход or "-", код, секунд, хеш[:12],
        " · страж: блок (%s)" % решение["правило"] if решение["исход"] == "block" else ""))
    if решение["исход"] == "block":
        return 3
    return код if код >= 0 else 1


if __name__ == "__main__":
    sys.exit(main())
