#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""СКАН-ЛЕНТЫ — перед публикацией панели: нет ли в ней ключей, паролей и почт аккаунтов.

  python3 панель/скан-ленты.py          # проверить локальные файлы ленты; код 0 — чисто, код 1 — найдено
  (как модуль) найти(текст) -> список находок (имена, не значения); пусто — чисто

`панель/опубликовать.py` вызывает найти() для всего, что уходит в интернет, и при находке отказывает в публикации (ход 55).
"""
import os
import re
import sys

КОРЕНЬ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ФАЙЛЫ = ("панель/actions.json", "панель/действия.jsonl", "ПАНЕЛЬ.html", "панель/panel.html", "панель/panel2.html")
ШАБЛОНЫ = [r"\b\d{8,10}:[A-Za-z0-9_\-]{35}\b", r"github_pat_[A-Za-z0-9_]{40,}", r"\bgh[pousr]_[A-Za-z0-9]{30,}",
           r"\bgsk_[A-Za-z0-9]{30,}", r"\bsk-[A-Za-z0-9\-]{20,}", r"\btvly-[A-Za-z0-9_\-]{20,}"]


def значения():
    знач = {}
    п = os.path.join(КОРЕНЬ, "память", "ключи.txt")
    if os.path.exists(п):
        for л in open(п, encoding="utf-8"):
            if "=" in л and not л.lstrip().startswith("#"):
                к, в = л.strip().split("=", 1)
                if к != "телеграм_канал" and len(в) >= 10:
                    знач["ключ:" + к] = в
    п = os.path.join(КОРЕНЬ, "память", "аккаунты.txt")
    if os.path.exists(п):
        for л in open(п, encoding="utf-8"):
            ч = л.strip().split("|")
            if len(ч) >= 3 and not л.startswith("#"):
                знач["почта-" + ч[0]] = ч[1]
                знач["пароль-" + ч[0]] = ч[2]
    return знач


ЗНАЧЕНИЯ = значения()


def найти(текст):
    """Список находок в тексте (ключи, пароли, почты аккаунтов). Значения не возвращает."""
    р = [к for к, в in ЗНАЧЕНИЯ.items() if в in текст]
    р += ["шаблон %d" % i for i, ш in enumerate(ШАБЛОНЫ) if re.search(ш, текст)]
    return р


def main():
    плохо = []
    for ф in ФАЙЛЫ:
        п = os.path.join(КОРЕНЬ, ф)
        if os.path.exists(п):
            плохо += [(ф, н) for н in найти(open(п, encoding="utf-8", errors="ignore").read())]
    print("СКАН ЛЕНТЫ:", "ЧИСТО" if not плохо else "НАЙДЕНО: %s" % плохо)
    return 1 if плохо else 0


if __name__ == "__main__":
    sys.exit(main())
