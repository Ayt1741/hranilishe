#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ВОССТАНОВИТЬ — проверить, что память реально восстанавливается из хранилища.

Закон 42 говорит «всё автоматически уходит в хранилище». Но «ушло» и «из этого
можно восстановиться» — разные вещи. Этот скрипт не смотрит на местные файлы как
на источник правды: он скачивает части журнала из репозитория, склеивает их,
распаковывает и проверяет три вещи:

  1. склейка частей даёт ровно тот же файл, что лежит на диске (sha256);
  2. распакованный журнал читается и число записей совпадает с местным;
  3. нумерация записей без дыр и без повторов (1..N подряд).

Если хоть что-то не так — код 1: значит копия в хранилище не является копией.

  python3 восстановить.py            # скачать и сверить
  python3 восстановить.py --тихо     # только итог

Коды: 0 восстановление подтверждено · 1 расхождение · 2 нет токена/сети (не проверено)
"""
import gzip
import hashlib
import io
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

БАЗА = os.path.dirname(os.path.abspath(__file__))
РЕПОЗИТОРИЙ = "Ayt1741/hranilishe"
ВЕТКА = "main"
ЖУРНАЛ = os.path.join(БАЗА, "память", "журнал.jsonl.gz")
КЛЮЧИ = os.path.join(БАЗА, "память", "ключи.txt")


def токен():
    if not os.path.exists(КЛЮЧИ):
        return ""
    for строка in open(КЛЮЧИ, encoding="utf-8"):
        if строка.strip().startswith("github="):
            return строка.strip().split("=", 1)[1]
    return ""


def api_raw(путь, тк):
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь, safe="/"), ВЕТКА)
    r = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + тк, "User-Agent": "hranilishe-restore",
        "Accept": "application/vnd.github.raw"})
    with urllib.request.urlopen(r, timeout=120) as о:
        return о.read()


def номера(данные_gz):
    """Номера записей из распакованного журнала: нужен для проверки нумерации."""
    текст = gzip.decompress(данные_gz).decode("utf-8")
    номера_записей = []
    for строка in текст.splitlines():
        строка = строка.strip()
        if not строка:
            continue
        try:
            з = json.loads(строка)
        except json.JSONDecodeError:
            return None, "строка не разбирается как JSON: %s…" % строка[:60]
        н = з.get("н") or з.get("n") or з.get("номер")
        if н is None:
            return None, "в записи нет номера: %s…" % строка[:60]
        номера_записей.append(int(н))
    return номера_записей, ""


def main():
    тихо = "--тихо" in sys.argv
    тк = токен()
    if not тк:
        print("ОШИБКА КОНФИГУРАЦИИ: нет github= в память/ключи.txt → не проверено")
        return 2

    местные = open(ЖУРНАЛ, "rb").read()
    # сколько частей ждать: узнаём из ответа API на список каталога
    try:
        url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (
            РЕПОЗИТОРИЙ, urllib.parse.quote("журнал", safe="/"), ВЕТКА)
        r = urllib.request.Request(url, headers={
            "Authorization": "Bearer " + тк, "User-Agent": "hranilishe-restore",
            "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(r, timeout=60) as о:
            список = json.load(о)
        части = sorted([э["name"] for э in список
                        if э["name"].startswith("журнал.jsonl.gz.часть")],
                       key=lambda и: int(и.rsplit("часть", 1)[1]))
    except urllib.error.HTTPError as e:
        print("НЕ ПРОВЕРЕНО: api.github.com вернул %d → код 2" % e.code)
        return 2
    except Exception as e:
        print("НЕ ПРОВЕРЕНО: %s → код 2" % type(e).__name__)
        return 2

    if not части:
        print("РАСХОЖДЕНИЕ: в хранилище нет ни одной части журнала → код 1")
        return 1

    склейка = b""
    for имя in части:
        try:
            кусок = api_raw("журнал/" + имя, тк)
        except Exception as e:
            print("НЕ ПРОВЕРЕНО: %s не скачалась (%s) → код 2" % (имя, type(e).__name__))
            return 2
        if not тихо:
            print("  ↓ %-34s %9d б  sha256 %s…" % (имя, len(кусок),
                                                   hashlib.sha256(кусок).hexdigest()[:12]))
        склейка += кусок

    свой = hashlib.sha256(местные).hexdigest()
    собранный = hashlib.sha256(склейка).hexdigest()
    ок = True
    print("  склейка частей: %s… (%d б)" % (собранный[:12], len(склейка)))
    print("  местный файл:   %s… (%d б)" % (свой[:12], len(местные)))
    if собранный == свой:
        print("  ✓ склейка = местный журнал побайтово")
    else:
        ок = False
        print("  ✗ СКЛЕЙКА НЕ СОВПАЛА с местным журналом")

    местные_номера, беда_м = номера(местные)
    сбор_номера, беда_с = номера(склейка)
    if беда_м or беда_с:
        ок = False
        print("  ✗ журнал не разбирается: %s" % (беда_м or беда_с))
    else:
        print("  ✓ журнал читается: записей местно %d, в склейке %d"
              % (len(местные_номера), len(сбор_номера)))
        if len(местные_номера) != len(сбор_номера):
            ок = False
            print("  ✗ ЧИСЛО ЗАПИСЕЙ РАЗОШЛОСЬ")
        дыры = [н for н in range(1, (сбор_номера[-1] if сбор_номера else 0) + 1)
                if н not in set(сбор_номера)]
        повторы = len(сбор_номера) - len(set(сбор_номера))
        print("  %s нумерация: 1..%s, дыр %d, повторов %d"
              % ("✓" if not дыры and not повторы else "✗",
                 сбор_номера[-1] if сбор_номера else 0, len(дыры), повторы))
        if дыры:
            print("    первые дыры: %s" % дыры[:10])
        if дыры or повторы:
            ок = False

    # полная лента действий — отдельный файл: панель держит только 200 последних
    try:
        лента_у = api_raw("журнал/действия-все.jsonl", тк)
        местная = open(os.path.join(БАЗА, "панель", "действия.jsonl"), "rb").read()
        if hashlib.sha256(лента_у).hexdigest() == hashlib.sha256(местная).hexdigest():
            строк = [с for с in лента_у.decode("utf-8").splitlines() if с.strip()]
            print("  ✓ полная лента действий: %d записей, sha256 %s… совпал"
                  % (len(строк), hashlib.sha256(лента_у).hexdigest()[:12]))
        else:
            ок = False
            print("  ✗ ПОЛНАЯ ЛЕНТА не совпала с местной")
    except Exception as e:
        print("  ! полная лента не скачалась (%s) — считается как расхождение" % type(e).__name__)
        ок = False

    print("\nИТОГ: %s" % ("память восстанавливается из хранилища — код 0"
                          if ок else "ВОССТАНОВЛЕНИЕ НЕ ПОДТВЕРЖДЕНО — код 1"))
    return 0 if ок else 1


if __name__ == "__main__":
    sys.exit(main())
