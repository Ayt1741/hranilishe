#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""УЧЁТ ПОИСКОВ — сверяет, сколько поисков в интернете записано видимым шагом и
сколько строк лежит в research/поиски-*.md.

Зачем: ты сказал «Почему я не вижу что ты ищешь в интернете?». Причина была в том,
что вызов поиска не попадал ни в панель, ни в журнал — то есть в записях его нет,
и проверить мои слова нечем. Прибор считает это число и показывает расхождение.

  python3 учёт-поисков.py            # сводка по всем ходам
  python3 учёт-поисков.py --ход 44   # только этот ход

Коды: 0 всё записано · 1 есть поиски, не записанные видимым шагом
"""
import argparse
import json
import os
import re
import sys

БАЗА = os.path.dirname(os.path.abspath(__file__))
ДЕЙСТВИЯ = os.path.join(БАЗА, "панель", "actions.json")
RESEARCH = os.path.join(БАЗА, "research")


def строк_в_файлах():
    """Сколько запросов записано в файлах поисков: строки вида «| 12 | запрос | ...»."""
    итог = {}
    if not os.path.isdir(RESEARCH):
        return итог
    for имя in sorted(os.listdir(RESEARCH)):
        if not (имя.startswith("поиски") and имя.endswith(".md")):
            continue
        with open(os.path.join(RESEARCH, имя), encoding="utf-8") as ф:
            m = re.search(r"ход\s+(\d+)", ф.readline() + ф.readline())
            сколько = len(re.findall(r"^\| (\d+) \|", open(os.path.join(RESEARCH, имя),
                                                           encoding="utf-8").read(), re.M))
        итог[имя] = (int(m.group(1)) if m else None, сколько)
    return итог


def видимые_поиски(ход=None):
    """Действия панели, в которых прямо написано «поиск в интернете»."""
    if not os.path.exists(ДЕЙСТВИЯ):
        return []
    данные = json.load(open(ДЕЙСТВИЯ, encoding="utf-8")).get("действия", [])
    out = []
    for д in данные:
        if ход is not None and str(д.get("ход")) != str(ход):
            continue
        if "поиск в интернете" in (д.get("что") or "").lower():
            out.append(д)
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ход", type=int, default=None)
    a = p.parse_args()

    файлы = строк_в_файлах()
    видимые = видимые_поиски(a.ход)
    print("ПОИСКИ В ИНТЕРНЕТЕ: где они записаны")
    for имя, (ход, сколько) in файлы.items():
        print("  %-24s ход %-4s строк %d" % (имя, ход if ход else "?", сколько))
    print("  видимых шагов в панели%s: %d" % (
        "" if a.ход is None else " (ход %s)" % a.ход, len(видимые)))
    for д in видимые[-5:]:
        print("    №%s %s" % (д.get("н"), (д.get("что") or "")[:70]))

    всего_строк = sum(s for _, s in файлы.values())
    print("\nстрок в файлах поисков: %d · видимых шагов в панели: %d" % (всего_строк, len(видимые)))
    if a.ход is None:
        print("ИТОГ: сводка без вердикта (укажи --ход, чтобы проверить ход)")
        return 0
    if not видимые:
        print("ИТОГ: за этот ход нет ни одного видимого шага поиска — в записях поиска не видно")
        return 1
    print("ИТОГ: за этот ход видимых шагов поиска %d" % len(видимые))
    return 0


if __name__ == "__main__":
    sys.exit(main())
