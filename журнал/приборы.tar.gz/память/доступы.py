#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ДОСТУПЫ — «что подключено и что работает» одной командой (запрос заказчика №1502: отчёт в конце каждого хода).

Проверяет только то, что можно проверять законно и без вреда: Telegram-бот и канал, токен GitHub,
ключ Groq, воркфлоу репозитория arena-fleet (есть ли расписание), заливки в память Telegram.
НЕ входит в аккаунты Arena и не обращается к arena.ai: условия Arena запрещают автоматический доступ
(Terms of Use от 2026-02-23, раздел «User conduct», пункты (vi) и (vii)).
Ключи в вывод не попадают. Коды: 0 всё живо · 1 что-то не работает · 2 нет ключей.
"""
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))


def ключи():
    д = {}
    п = os.path.join(ЗДЕСЬ, "ключи.txt")
    if os.path.exists(п):
        for с in open(п, encoding="utf-8"):
            if "=" in с and not с.lstrip().startswith("#"):
                к, з = с.strip().split("=", 1)
                д[к.strip()] = з.strip()
    return д


def запрос(url, заголовки=None, данные=None, таймаут=25):
    з = urllib.request.Request(url, headers=заголовки or {}, data=данные)
    try:
        with urllib.request.urlopen(з, timeout=таймаут) as о:
            return о.status, о.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(type(e).__name__).encode()


def строка(ок, что, подробно):
    print(" %s %-34s %s" % ("✓" if ок else "✗", что, подробно))
    return ок


def main():
    к = ключи()
    if not к:
        print("нет память/ключи.txt")
        return 2
    итог = []

    # --- Telegram
    т = к.get("telegram", "")
    канал = к.get("телеграм_канал", "-1003772678641")
    if т:
        с, б = запрос("https://api.telegram.org/bot%s/getMe" % т)
        ок = с == 200 and json.loads(б).get("ok")
        имя = json.loads(б)["result"]["username"] if ок else "—"
        итог.append(строка(ок, "Telegram-бот", "@%s жив" % имя if ок else "ответ %s" % с))
        if ок:
            с, б = запрос("https://api.telegram.org/bot%s/getChatMember" % т,
                          {"Content-Type": "application/json"},
                          json.dumps({"chat_id": int(канал), "user_id": json.loads(запрос("https://api.telegram.org/bot%s/getMe" % т)[1])["result"]["id"]}).encode())
            р = json.loads(б).get("result", {}) if с == 200 else {}
            итог.append(строка(р.get("status") == "administrator", "Канал «Хранилище»",
                               "роль %s · публиковать %s · удалять %s" % (р.get("status"), р.get("can_post_messages"), р.get("can_delete_messages"))))
    else:
        итог.append(строка(False, "Telegram-бот", "нет ключа telegram в ключи.txt"))

    # --- GitHub
    г = к.get("github", "")
    ЗГ = {"Authorization": "Bearer " + г, "User-Agent": "dostupy-check", "Accept": "application/vnd.github+json"}
    if г:
        с, б = запрос("https://api.github.com/user", ЗГ)
        ок = с == 200
        итог.append(строка(ок, "GitHub-токен", "аккаунт %s" % json.loads(б).get("login") if ок else "ответ %s" % с))
        с, б = запрос("https://api.github.com/repos/Ayt1741/arena-fleet/actions/workflows", ЗГ)
        if с == 200:
            вф = json.loads(б)["workflows"]
            сами = []
            for в in вф:
                с2, б2 = запрос("https://api.github.com/repos/Ayt1741/arena-fleet/contents/" + в["path"], ЗГ)
                if с2 == 200:
                    текст = base64.b64decode(json.loads(б2)["content"]).decode("utf-8", "ignore")
                    блок = re.search(r"(?ms)^on:\s*(.*?)(?=^\S|\Z)", текст)
                    триггеры = set(re.findall(r"\b(push|pull_request|schedule|workflow_run|issues|repository_dispatch|release|watch)\b",
                                             блок.group(0) if блок else ""))
                    if триггеры:
                        сами.append("%s (%s)" % (в["name"], ", ".join(sorted(триггеры))))
            итог.append(строка(True, "Воркфлоу arena-fleet", "%d шт.; сами запускаются: %s" % (len(вф), "; ".join(сами) or "нет")))
        else:
            итог.append(строка(False, "Воркфлоу arena-fleet", "ответ %s" % с))

    # --- Groq
    гр = к.get("groq", "")
    if гр:
        с, б = запрос("https://api.groq.com/openai/v1/models", {"Authorization": "Bearer " + гр, "User-Agent": "dostupy-check"})
        итог.append(строка(с == 200, "Groq", "моделей: %d" % len(json.loads(б).get("data", [])) if с == 200 else "ответ %s" % с))

    # --- память в Telegram
    п = os.path.join(ЗДЕСЬ, "в-памяти.jsonl")
    if os.path.exists(п):
        for с_ in open(п, encoding="utf-8"):
            if с_.strip():
                з = json.loads(с_)
                итог.append(строка(bool(з.get("проверено_возвратом")), "В памяти: " + з["имя"][:22],
                                   "%.1f МБ · частей %d · возврат %s" % (з["размер"] / 1e6, len(з["части"]), "сверен" if з.get("проверено_возвратом") else "НЕ сверен")))
    print(" – Arena (Battle/Direct/Agent)  не проверялось: автоматический доступ запрещён условиями Arena")
    print("\nИТОГ: %d из %d проверок зелёные" % (sum(1 for x in итог if x), len(итог)))
    return 0 if all(итог) else 1


if __name__ == "__main__":
    sys.exit(main())
