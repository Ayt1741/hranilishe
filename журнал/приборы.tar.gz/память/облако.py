#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ОБЛАКО — только чтение: что есть в Ayt1741/cloud-pc и в Codespaces, и можно ли назначить на задачу агента Copilot.
Запуск: python3 память/облако.py   (ничего не меняет, ключ GitHub берёт из память/ключи.txt, не печатает)"""
import json
import os
import urllib.error
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
кл = {}
for с in open(os.path.join(ЗДЕСЬ, "ключи.txt"), encoding="utf-8"):
    if "=" in с:
        к, з = с.strip().split("=", 1)
        кл[к] = з
Н = {"Authorization": "Bearer " + кл.get("github", ""), "User-Agent": "oblako", "Accept": "application/vnd.github+json"}


def запрос(url, данные=None, метод="GET"):
    try:
        з = urllib.request.Request(url, headers=Н, method=метод, data=json.dumps(данные).encode() if данные else None)
        with urllib.request.urlopen(з, timeout=30) as о:
            return о.status, json.loads(о.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}


с, р = запрос("https://api.github.com/repos/Ayt1741/cloud-pc")
print("cloud-pc: код %s · приватный: %s · последний пуш: %s" % (с, р.get("private"), р.get("pushed_at")))
с, р = запрос("https://api.github.com/repos/Ayt1741/cloud-pc/contents/")
print("файлов и папок в корне: %d" % (len(р) if isinstance(р, list) else -1))
с, р = запрос("https://api.github.com/user/codespaces")
for ц in (р.get("codespaces") or []):
    print("Codespace: %s · состояние: %s · %s" % (ц.get("name"), ц.get("state"), (ц.get("machine") or {}).get("display_name")))
if not (р.get("codespaces") or []):
    print("Codespaces: нет (код %s)" % с)
q = {"query": 'query{repository(owner:"Ayt1741",name:"cloud-pc"){suggestedActors(capabilities:[CAN_BE_ASSIGNED],first:20){nodes{__typename ... on Bot{login} ... on User{login}}}}}'}
с, р = запрос("https://api.github.com/graphql", q, "POST")
узлы = (((р.get("data") or {}).get("repository") or {}).get("suggestedActors") or {}).get("nodes") or []
print("на задачу в cloud-pc можно назначить: %s" % ", ".join(u.get("login", "?") for u in узлы))
print("агент Copilot среди них: %s" % ("ДА" if any("copilot" in (u.get("login") or "").lower() for u in узлы) else "НЕТ"))
