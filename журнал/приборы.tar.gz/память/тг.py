#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ТГ — доступ к памяти в Telegram (канал «Хранилище») одной командой. Только стандартная библиотека.

  python3 память/тг.py проверка                  # бот жив? права в канале? закреплённый указатель на месте?
  python3 память/тг.py индекс                    # прочитать указатель ГЛАВНОЕ1 → список файлов приложения «Хранилище»
                                                 #   (только чтение: пересылки сразу удаляются; закреп НЕ трогается)
  python3 память/тг.py залить ПУТЬ [--без-сжатия] [--имя ИМЯ]
                                                 # gzip → части ≤ 18 МиБ → отправка → скачивание ОБРАТНО → сверка sha256
                                                 #   → запись в память/в-памяти.jsonl. Оригинал не удаляется.
  python3 память/тг.py список                    # что уже лежит в памяти (из в-памяти.jsonl)
  python3 память/тг.py вернуть ИМЯ [КУДА]        # скачать части по file_id, собрать, сверить sha256

Ключ берётся из память/ключи.txt (строка telegram=…) или из переменной TG_TOKEN. В вывод ключ не попадает.
Коды: 0 всё сошлось · 1 расхождение/ошибка проверки · 2 нет ключа или сети («не проверено»).
Ограничения Bot API (по документации Telegram, проверено прогоном): отправка до 50 МБ, скачивание до 20 МБ,
~1 сообщение/с в чат (429 → retry_after). Поэтому часть = 18 МиБ: её можно и отправить, и скачать обратно.
В multipart имя файла и граница — только ASCII (урок 10.11), русский текст — только в подписи.
"""
import gzip
import hashlib
import io
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КЛЮЧИ = os.path.join(ЗДЕСЬ, "ключи.txt")
УЧЁТ = os.path.join(ЗДЕСЬ, "в-памяти.jsonl")
ИНДЕКС = os.path.join(ЗДЕСЬ, "тг-индекс.json")
ЧАСТЬ = 18 * 1024 * 1024
ПАУЗА = 3.1          # между пересылками при чтении указателя: ≤ 20 сообщений в минуту


def ключи():
    д = {}
    if os.path.exists(КЛЮЧИ):
        for с in open(КЛЮЧИ, encoding="utf-8"):
            if "=" in с and not с.lstrip().startswith("#"):
                к, з = с.strip().split("=", 1)
                д[к.strip()] = з.strip()
    return д


def токен_и_канал():
    к = ключи()
    т = os.environ.get("TG_TOKEN") or к.get("telegram", "")
    канал = int(os.environ.get("TG_CHAT") or к.get("телеграм_канал", "-1003772678641"))
    return т, канал


ТОКЕН, КАНАЛ = токен_и_канал()


def sha(б):
    return hashlib.sha256(б).hexdigest()


def sha_файла(путь):
    х = hashlib.sha256()
    with open(путь, "rb") as ф:
        for к in iter(lambda: ф.read(1 << 20), b""):
            х.update(к)
    return х.hexdigest()


def api(метод, **п):
    """JSON-вызов. Возвращает словарь ответа; 429 переждёт и повторит."""
    for попытка in range(6):
        з = urllib.request.Request("https://api.telegram.org/bot%s/%s" % (ТОКЕН, метод),
                                   data=json.dumps(п).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(з, timeout=60) as о:
                return json.loads(о.read())
        except urllib.error.HTTPError as e:
            try:
                т = json.loads(e.read())
            except Exception:
                т = {"ok": False, "description": "HTTP %s" % e.code}
            if e.code == 429:
                time.sleep(int((т.get("parameters") or {}).get("retry_after", 5)) + 1)
                continue
            return т
        except Exception as e:
            if попытка == 5:
                return {"ok": False, "description": "сеть: %s" % type(e).__name__}
            time.sleep(2)
    return {"ok": False, "description": "429 не прошёл"}


def отправить_документ(данные, имя_ascii, подпись):
    граница = "tg" + uuid.uuid4().hex
    тело = io.BytesIO()

    def поле(имя, значение):
        тело.write(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n" % (граница, имя)).encode())
        тело.write(значение.encode("utf-8") + b"\r\n")

    поле("chat_id", str(КАНАЛ))
    поле("disable_notification", "true")
    поле("caption", подпись[:1000])
    тело.write(("--%s\r\nContent-Disposition: form-data; name=\"document\"; filename=\"%s\"\r\n"
                "Content-Type: application/octet-stream\r\n\r\n" % (граница, имя_ascii)).encode())
    тело.write(данные)
    тело.write(("\r\n--%s--\r\n" % граница).encode())
    for попытка in range(6):
        з = urllib.request.Request("https://api.telegram.org/bot%s/sendDocument" % ТОКЕН, data=тело.getvalue(),
                                   headers={"Content-Type": "multipart/form-data; boundary=%s" % граница})
        try:
            with urllib.request.urlopen(з, timeout=300) as о:
                return json.loads(о.read())
        except urllib.error.HTTPError as e:
            try:
                т = json.loads(e.read())
            except Exception:
                т = {"ok": False, "description": "HTTP %s" % e.code}
            if e.code == 429:
                time.sleep(int((т.get("parameters") or {}).get("retry_after", 5)) + 1)
                continue
            return т
        except Exception as e:
            if попытка == 5:
                return {"ok": False, "description": "сеть: %s" % type(e).__name__}
            time.sleep(3)
    return {"ok": False, "description": "429 не прошёл"}


def скачать(file_id):
    """Скачать файл из Telegram по file_id. Возвращает байты или None."""
    р = api("getFile", file_id=file_id)
    if not р.get("ok"):
        print("  getFile отказал:", р.get("description"))
        return None
    путь = р["result"].get("file_path")
    for попытка in range(4):
        try:
            with urllib.request.urlopen("https://api.telegram.org/file/bot%s/%s" % (ТОКЕН, путь), timeout=300) as о:
                return о.read()
        except Exception as e:
            if попытка == 3:
                print("  скачивание не удалось:", type(e).__name__)
                return None
            time.sleep(3)


def записать_учёт(з):
    with open(УЧЁТ, "a", encoding="utf-8") as ф:
        ф.write(json.dumps(з, ensure_ascii=False) + "\n")


def прочесть_учёт():
    if not os.path.exists(УЧЁТ):
        return []
    return [json.loads(с) for с in open(УЧЁТ, encoding="utf-8") if с.strip()]


# ------------------------------------------------------------------ команды
def проверка():
    if not ТОКЕН:
        print("НЕ ПРОВЕРЕНО: нет ключа telegram в память/ключи.txt и нет TG_TOKEN")
        return 2
    я = api("getMe")
    if not я.get("ok"):
        print("ПРОВАЛ: getMe →", я.get("description"))
        return 1
    print("бот: @%s (id %s) — жив" % (я["result"]["username"], я["result"]["id"]))
    ч = api("getChat", chat_id=КАНАЛ)
    if not ч.get("ok"):
        print("ПРОВАЛ: getChat →", ч.get("description"))
        return 1
    r = ч["result"]
    print("канал: «%s» (%s), id %s" % (r.get("title"), r.get("type"), r["id"]))
    чл = api("getChatMember", chat_id=КАНАЛ, user_id=я["result"]["id"])
    if чл.get("ok"):
        c = чл["result"]
        print("роль бота: %s · публиковать: %s · править: %s · удалять: %s" % (
            c.get("status"), c.get("can_post_messages"), c.get("can_edit_messages"), c.get("can_delete_messages")))
    п = r.get("pinned_message") or {}
    т = п.get("text", "")
    if т.startswith("ГЛАВНОЕ1|"):
        ч = т.split("|")
        print("закреп: сообщение %s, ГЛАВНОЕ1, раскладка: %s ч., индекс: %s ч." % (
            п.get("message_id"), len([x for x in ч[2].split(",") if x]), len([x for x in ч[3].split(",") if x])))
    else:
        print("закреп:", п.get("message_id"), "(не ГЛАВНОЕ1)")
    return 0


def индекс():
    if not ТОКЕН:
        print("НЕ ПРОВЕРЕНО: нет ключа")
        return 2
    ч = api("getChat", chat_id=КАНАЛ)
    т = ((ч.get("result") or {}).get("pinned_message") or {}).get("text", "")
    if not т.startswith("ГЛАВНОЕ1|"):
        print("ПРОВАЛ: в закрепе нет указателя ГЛАВНОЕ1")
        return 1
    части = т.split("|")
    идыИ = [int(x) for x in части[3].split(",") if x.strip().isdigit()]
    print("частей индекса файлов: %d (чтение ~%d с, пересылки удаляются сразу)" % (len(идыИ), int(len(идыИ) * ПАУЗА)))
    файлы, ошибки = [], 0
    for i, mid in enumerate(идыИ, 1):
        р = api("forwardMessage", chat_id=КАНАЛ, from_chat_id=КАНАЛ, message_id=mid, disable_notification=True)
        if not р.get("ok"):
            ошибки += 1
            print("  часть", mid, "не прочиталась:", р.get("description"))
        else:
            м = р["result"]
            api("deleteMessage", chat_id=КАНАЛ, message_id=м["message_id"])
            for с in (м.get("text") or "").split("\n"):
                if "|" in с:
                    п = с.split("|")
                    if len(п) >= 3:
                        файлы.append({"имя": п[0], "размер": int(п[1]) if п[1].isdigit() else 0,
                                      "file_id": п[2], "метка": п[3] if len(п) > 3 else ""})
        if i % 20 == 0:
            print("  прочитано частей: %d из %d, файлов: %d" % (i, len(идыИ), len(файлы)))
        time.sleep(ПАУЗА)
    json.dump({"время": time.strftime("%Y-%m-%dT%H:%M:%S"), "частей": len(идыИ), "ошибок": ошибки, "файлы": файлы},
              open(ИНДЕКС, "w", encoding="utf-8"), ensure_ascii=False)
    всего = sum(ф["размер"] for ф in файлы)
    print("ИТОГ: файлов в индексе %d · суммарно %.1f ГБ · ошибок чтения %d → %s" % (
        len(файлы), всего / 1e9, ошибки, os.path.relpath(ИНДЕКС)))
    return 0 if not ошибки else 1


def залить(путь, сжимать=True, имя=None):
    if not ТОКЕН:
        print("НЕ ПРОВЕРЕНО: нет ключа")
        return 2
    if not os.path.exists(путь):
        print("нет файла:", путь)
        return 1
    имя = имя or os.path.basename(путь)
    t0 = time.time()
    sha_ориг = sha_файла(путь)
    размер_ориг = os.path.getsize(путь)
    if сжимать and not путь.endswith(".gz"):
        буфер = io.BytesIO()
        with open(путь, "rb") as ф, gzip.GzipFile(fileobj=буфер, mode="wb", compresslevel=6, mtime=0) as г:
            for к in iter(lambda: ф.read(1 << 20), b""):
                г.write(к)
        данные = буфер.getvalue()
        сжатие = "gzip"
    else:
        данные = open(путь, "rb").read()
        сжатие = "нет"
    sha_данных = sha(данные)
    куски = [данные[i:i + ЧАСТЬ] for i in range(0, len(данные), ЧАСТЬ)] or [b""]
    print("«%s»: %.1f МБ → %s %.1f МБ → частей: %d" % (имя, размер_ориг / 1e6, сжатие, len(данные) / 1e6, len(куски)))
    части = []
    for n, к in enumerate(куски, 1):
        sha_к = sha(к)
        подпись = "ПАМЯТЬ|%s|часть %d/%d|sha256 части %s|sha256 оригинала %s|%s" % (
            имя, n, len(куски), sha_к[:16], sha_ориг[:16], time.strftime("%Y-%m-%d %H:%M"))
        р = отправить_документ(к, "part-%03d.bin" % n, подпись)
        if not р.get("ok"):
            print("  часть %d/%d НЕ ушла: %s" % (n, len(куски), р.get("description")))
            return 1
        док = р["result"]["document"]
        части.append({"n": n, "message_id": р["result"]["message_id"], "file_id": док["file_id"],
                      "file_unique_id": док.get("file_unique_id"), "размер": len(к), "sha256": sha_к})
        print("  отправлена часть %d/%d: %.1f МБ, message_id %s" % (n, len(куски), len(к) / 1e6, р["result"]["message_id"]))
        time.sleep(1.2)
    # обратная сверка: скачать каждую часть по file_id и сравнить sha256 с тем, что отправляли
    расхождения = 0
    склейка = io.BytesIO()
    for ч in части:
        б = скачать(ч["file_id"])
        ок = б is not None and sha(б) == ч["sha256"] and len(б) == ч["размер"]
        print("  возврат части %d/%d: %s" % (ч["n"], len(части), "СОВПАЛО" if ок else "РАСХОЖДЕНИЕ"))
        if not ок:
            расхождения += 1
        else:
            склейка.write(б)
    итог_ок = False
    if not расхождения:
        собранное = склейка.getvalue()
        итог_ок = sha(собранное) == sha_данных
        if итог_ок and сжатие == "gzip":
            итог_ок = sha(gzip.decompress(собранное)) == sha_ориг
        print("  склейка и распаковка → sha256 оригинала: %s" % ("СОВПАЛО" if итог_ок else "РАСХОЖДЕНИЕ"))
    записать_учёт({
        "время": time.strftime("%Y-%m-%dT%H:%M:%S"), "имя": имя, "путь": путь, "размер": размер_ориг,
        "sha256": sha_ориг, "сжатие": сжатие, "размер_после": len(данные), "sha256_после": sha_данных,
        "канал": КАНАЛ, "части": части, "проверено_возвратом": bool(итог_ок),
    })
    print("%s · %.0f с · запись в %s" % ("ГОТОВО: байты вернулись и совпали" if итог_ок else "ПРОВАЛ: расхождение, оригинал не тронут",
                                        time.time() - t0, os.path.relpath(УЧЁТ)))
    return 0 if итог_ок else 1


def список():
    з = прочесть_учёт()
    if not з:
        print("в памяти (в-памяти.jsonl) пока ничего")
        return 0
    for x in з:
        print("%s  %-46s %9.1f МБ  частей %d  message_id %s…  возврат: %s" % (
            x["время"][:16], x["имя"][:46], x["размер"] / 1e6, len(x["части"]),
            x["части"][0]["message_id"], "да" if x.get("проверено_возвратом") else "НЕТ"))
    return 0


def вернуть(имя, куда=None):
    з = [x for x in прочесть_учёт() if x["имя"] == имя]
    if not з:
        print("в памяти нет «%s»" % имя)
        return 1
    x = з[-1]
    куда = куда or os.path.join("/tmp", имя)
    буфер = io.BytesIO()
    for ч in x["части"]:
        б = скачать(ч["file_id"])
        if б is None or sha(б) != ч["sha256"]:
            print("часть %d не сошлась — остановка" % ч["n"])
            return 1
        буфер.write(б)
    данные = буфер.getvalue()
    if sha(данные) != x["sha256_после"]:
        print("склейка не сошлась")
        return 1
    if x["сжатие"] == "gzip":
        данные = gzip.decompress(данные)
    if sha(данные) != x["sha256"]:
        print("sha256 оригинала не сошёлся")
        return 1
    os.makedirs(os.path.dirname(os.path.abspath(куда)), exist_ok=True)
    open(куда, "wb").write(данные)
    print("ВОЗВРАЩЕНО: %s (%.1f МБ), sha256 совпал → %s" % (имя, len(данные) / 1e6, куда))
    return 0


def main():
    а = sys.argv[1:]
    if not а:
        print(__doc__)
        return 0
    к = а[0]
    if к == "проверка":
        return проверка()
    if к == "индекс":
        return индекс()
    if к == "список":
        return список()
    if к == "залить" and len(а) > 1:
        имя = None
        if "--имя" in а:
            имя = а[а.index("--имя") + 1]
        return залить(а[1], сжимать="--без-сжатия" not in а, имя=имя)
    if к == "вернуть" and len(а) > 1:
        return вернуть(а[1], а[2] if len(а) > 2 else None)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
