#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
СОВЕТ — флот отвечает на каждый запрос, а не я один.

Как работает: вопрос уходит параллельно в несколько бесплатных моделей через
OpenAI-совместимый API (Groq), ответы складываются в память и печатаются.
Ключи читаются из память/ключи.txt (строки вида groq=...), ничего не хардкодится.

    python3 память/совет.py "вопрос"
    python3 память/совет.py "вопрос" --моделей 3
"""
import concurrent.futures as cf
import json
import os
import re
import sys
import time
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КЛЮЧИ = os.path.join(ЗДЕСЬ, "ключи.txt")

МОДЕЛИ_ПО_УМОЛЧАНИЮ = [
    ("openai/gpt-oss-120b", "мозг-120b"),
    ("qwen/qwen3.8-27b", "кухня-qwen-27b"),
    ("openai/gpt-oss-safeguard-20b", "проверяющий-20b"),
]
АДРЕС = "https://api.groq.com/openai/v1/chat/completions"


def ключи():
    данные = {}
    if os.path.exists(КЛЮЧИ):
        for строка in open(КЛЮЧИ, encoding="utf-8"):
            строка = строка.strip()
            if "=" in строка and not строка.startswith("#"):
                к, з = строка.split("=", 1)
                данные[к.strip().lower()] = з.strip()
    if os.environ.get("GROQ_API_KEY"):
        данные["groq"] = os.environ["GROQ_API_KEY"]
    return данные


def спросить(модель, вопрос, ключ, системное, предел=1600, таймаут=120):
    тело = json.dumps({
        "model": модель,
        "messages": [{"role": "system", "content": системное},
                     {"role": "user", "content": вопрос}],
        "temperature": 0.3,
        "max_tokens": предел,
    }).encode("utf-8")
    запрос = urllib.request.Request(
        АДРЕС, data=тело,
        headers={"Authorization": "Bearer " + ключ, "Content-Type": "application/json",
                 "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) pamyat-fleet"})
    начало = time.time()
    try:
        with urllib.request.urlopen(запрос, timeout=таймаут) as о:
            ответ = json.loads(о.read().decode("utf-8"))
        сообщение = ответ["choices"][0]["message"]
        текст = (сообщение.get("content") or "").strip()
        if not текст:                       # у gpt-oss рассуждение может съесть весь лимит
            текст = "（только рассуждение) " + (сообщение.get("reasoning") or "")[:800]
        return модель, текст, time.time() - начало, None
    except Exception as е:
        описание = str(е)
        try:
            описание = json.loads(е.read().decode("utf-8")).get("error", {}).get("message", описание)
        except Exception:
            pass
        return модель, "", time.time() - начало, описание[:200]


def совет(вопрос, моделей=3, системное=None):
    к = ключи()
    if not к.get("groq"):
        print("СОВЕТ: нет ключа groq в память/ключи.txt — флот не может ответить")
        return 1
    системное = системное or (
        "Ты в составе совета флота. Отвечай по-русски, коротко и по делу: "
        "сначала прямой ответ, потом 2-4 конкретных шага или цифры. Без вступлений.")
    выбрано = МОДЕЛИ_ПО_УМОЛЧАНИЮ[:моделей]
    начало = time.time()
    итоги = []
    with cf.ThreadPoolExecutor(max_workers=len(выбрано)) as пул:
        задачи = [пул.submit(спросить, модель, вопрос, к["groq"], системное) for модель, _ in выбрано]
        for з in cf.as_completed(задачи):
            итоги.append(з.result())
    стена = time.time() - начало
    строки = ["# СОВЕТ флота · %s" % time.strftime("%Y-%m-%d %H:%M:%S"),
              "", "вопрос: %s" % вопрос, "",
              "моделей: %d · стена: %.1f с" % (len(итоги), стена), ""]
    удачных = 0
    for модель, текст, секунды, ошибка in sorted(итоги, key=lambda z: z[0]):
        строки.append("## %s · %.1f с" % (модель, секунды))
        if ошибка:
            строки.append("ошибка: %s" % ошибка)
        else:
            удачных += 1
            строки.append(текст)
        строки.append("")
    файл = os.path.join(ЗДЕСЬ, "СОВЕТ.md")
    open(файл, "w", encoding="utf-8").write("\n".join(строки))
    print("\n".join(строки))
    print("→ %s · удачных ответов %d из %d · стена %.1f с" % (файл, удачных, len(итоги), стена))
    return 0 if удачных else 1


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    моделей = 3
    for а in sys.argv[1:]:
        if а.startswith("--моделей"):
            моделей = int(а.split("=")[-1]) if "=" in а else 3
    совет(" ".join(args), моделей)


if __name__ == "__main__":
    sys.exit(main() or 0)
