#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Спросить у конкретной модели Arena в Direct и забрать её ответ.

Зачем: в Battle модели анонимны (кто ответил — не видно), поэтому сравнивать
конкретные модели по коду можно только в Direct, где имя выбирается рукой.
Ответ кладётся в JSON — его потом читает совет.

  python3 память/direct-спрос.py --модель muse-spark-1.3-xhigh --вопрос "текст"
  python3 память/direct-спрос.py --модель claude-sonnet-5-5-high --вопрос "текст" --ждать 240
"""
import argparse
import asyncio
import base64
import json
import os
import time
import urllib.request

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
АККАУНТЫ = "/home/user/память/аккаунты.txt"


def знаки():
    out = []
    for l in open(АККАУНТЫ, encoding="utf-8"):
        l = l.strip()
        if "|" in l and "@" in l and not l.startswith("#"):
            out.append(l.split("|"))
    return out


def вход(почта, пароль, повторов=4):
    """Вход с повтором: арена отвечает 429 при частых входах."""
    последняя = None
    for попытка in range(повторов):
        try:
            return _вход(почта, пароль)
        except Exception as e:
            последняя = e
            time.sleep(8 * (попытка + 1))
    raise последняя


def _вход(почта, пароль):
    r = urllib.request.Request("https://arena.ai/nextjs-api/sign-in/email",
                               data=json.dumps({'email': почта, 'password': пароль}).encode(),
                               method="POST")
    for k, v in {'content-type': 'application/json', 'user-agent': UA,
                 'origin': 'https://arena.ai', 'referer': 'https://arena.ai/text'}.items():
        r.add_header(k, v)
    with urllib.request.urlopen(r, timeout=45) as x:
        печеньки = []
        for c in x.headers.get_all("Set-Cookie") or []:
            n, rest = c.split("=", 1)
            печеньки.append((n, rest.split(";")[0]))
        полез = json.loads(x.read().decode())
    raw = "".join(v for n, v in печеньки if n.startswith("arena-auth"))
    raw = raw[7:] if raw.startswith("base64-") else raw
    js = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4)).decode())
    return js.get("access_token", ""), [
        {"name": "arena-auth-prod-v1.0", "value": "base64-" + raw[:len(raw) // 2],
         "domain": "arena.ai", "path": "/"},
        {"name": "arena-auth-prod-v1.1", "value": raw[len(raw) // 2:],
         "domain": "arena.ai", "path": "/"}], полез


async def спросить(почта, пароль, модель, вопрос, ждать):
    from playwright.async_api import async_playwright
    токен, печеньки, полез = вход(почта, пароль)
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US",
                                  viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печеньки)
        pg = await ctx.new_page()
        await pg.goto("https://arena.ai/direct", wait_until="domcontentloaded", timeout=90000)
        await pg.wait_for_timeout(4000)
        # ждём, пока страница перестанет быть скелетом (появится поле ввода)
        for _ in range(40):
            await pg.wait_for_timeout(1500)
            if await pg.locator("textarea").count():
                break
            if await pg.get_by_role("button", name="Direct", exact=False).count():
                break
        await pg.wait_for_timeout(2000)
        # стартовая заглушка → Direct
        for надпись in ("Direct", "Direct Chat"):
            к = pg.get_by_role("button", name=надпись, exact=False).first
            if await к.count():
                await к.click(timeout=8000)
                await pg.wait_for_timeout(3000)
                break
        # открыть список моделей
        открыт = False
        for надпись in ("Max", "Select model", "Router"):
            к = pg.get_by_role("button", name=надпись, exact=False).first
            if await к.count():
                try:
                    await к.click(timeout=8000)
                    await pg.wait_for_timeout(2500)
                    if await pg.query_selector_all("[role=option]"):
                        открыт = True
                        break
                except Exception:
                    pass
        if not открыт:
            # список мог не открыться — жмём чип модели внизу по тексту
            for текст in ("Max", "Router"):
                эл = pg.get_by_text(текст, exact=True).last
                if await эл.count():
                    try:
                        await эл.click(timeout=8000)
                        await pg.wait_for_timeout(2500)
                        if await pg.query_selector_all("[role=option]"):
                            break
                    except Exception:
                        pass
        await pg.wait_for_timeout(1500)
        # выбрать модель по точному имени
        выбрана = False
        for e in await pg.query_selector_all("[role=option]"):
            t = (await e.inner_text()).strip().split("\n")[0].strip()
            if t == модель:
                await e.click(timeout=8000)
                выбрана = True
                break
        if not выбрана:
            # иначе — через поиск в списке
            поиск = pg.get_by_placeholder("Search models").first
            if await поиск.count():
                await поиск.click(timeout=6000)
                await поиск.fill(модель)
                await pg.wait_for_timeout(2500)
                for e in await pg.query_selector_all("[role=option]"):
                    t = (await e.inner_text()).strip().split("\n")[0].strip()
                    if t == модель:
                        await e.click(timeout=8000)
                        выбрана = True
                        break
        if not выбрана:
            await pg.screenshot(path="/tmp/direct-нет-модели.png")
            await b.close()
            return {"ok": False, "ошибка": "модель не выбрана: " + модель, "модель": модель}
        await pg.wait_for_timeout(2000)
        # ввод вопроса
        коробка = pg.locator("textarea").first
        await коробка.click(timeout=20000)
        await коробка.fill(вопрос)
        await pg.wait_for_timeout(800)
        await коробка.press("Enter")
        # ждём ответ: ловим появление текста ответа и его длину
        ответ = ""
        for _ in range(max(6, ждать // 6)):
            await pg.wait_for_timeout(6000)
            текст = await pg.inner_text("body")
            # ответ лежит после текста вопроса
            i = текст.find(вопрос[:60])
            if i >= 0:
                хвост = текст[i + len(вопрос):]
                хвост = хвост.replace("\n\n", "\n").strip()
                if len(хвост) > len(ответ):
                    ответ = хвост
            if len(ответ) > 1200:
                break
        await pg.screenshot(path="/tmp/direct-ответ-%s.png" % модель.replace("/", "_"))
        await b.close()
        return {"ok": bool(ответ), "модель": модель, "аккаунт": почта,
                "вопрос": вопрос, "ответ": ответ[:12000],
                "символов": len(ответ)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--модель", required=True)
    ap.add_argument("--вопрос", required=True)
    ap.add_argument("--ждать", type=int, default=180)
    ap.add_argument("--номер", type=int, default=1, help="какой аккаунт по списку")
    ap.add_argument("--выход", default="")
    a = ap.parse_args()
    пары = знаки()
    почта, пароль = пары[(a.номер - 1) % len(пары)][1], пары[(a.номер - 1) % len(пары)][2]
    рез = asyncio.run(спросить(почта, пароль, a.модель, a.вопрос, a.ждать))
    текст = json.dumps(рез, ensure_ascii=False, indent=1)
    print(текст)
    if a.выход:
        open(a.выход, "w", encoding="utf-8").write(текст)
    return 0 if рез.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
