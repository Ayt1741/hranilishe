#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ЖИВОЙ СТАТУС ФЛОТА — спрашивает GitHub и саму арену, а не память.

  python3 память/флот.py            # статус: аккаунты, машины, последний прогон
  python3 память/флот.py --кратко   # одна строка (для старта запроса)

Правило: цифры о флоте брать только отсюда, не из ФАКТЫ.md.
"""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

РЕПО = "Ayt1741/arena-fleet"
КЭШ = "/tmp/флот-статус.json"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))


def токен():
    if os.environ.get("GH_TOKEN"):
        return os.environ["GH_TOKEN"].strip()
    файл = os.path.join(ЗДЕСЬ, "ключи.txt")
    if os.path.exists(файл):
        for строка in open(файл, encoding="utf-8"):
            if строка.startswith("github="):
                return строка.split("=", 1)[1].strip()
    return ""


def гит(путь):
    r = urllib.request.Request("https://api.github.com/" + путь,
                               headers={"Authorization": "Bearer " + токен(), "User-Agent": "fleet"})
    with urllib.request.urlopen(r, timeout=30) as x:
        return json.load(x)


def проверка_входа(почта, пароль):
    тело = json.dumps({"email": почта, "password": пароль}).encode()
    r = urllib.request.Request("https://arena.ai/nextjs-api/sign-in/email", data=тело, method="POST")
    for k, v in {"content-type": "application/json", "user-agent": UA,
                 "origin": "https://arena.ai", "referer": "https://arena.ai/text"}.items():
        r.add_header(k, v)
    try:
        with urllib.request.urlopen(r, timeout=40) as x:
            return x.status, "ок"
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode()).get("code", "")[:40]
        except Exception:
            return e.code, ""


def считать():
    т = токен()
    if not т:
        return {"ошибка": "нет токена GitHub (память/ключи.txt: github=…)"}
    итог = {"время": time.strftime("%Y-%m-%d %H:%M:%S"), "аккаунты": [], "прогоны": []}
    секреты = {с["name"] for с in гит("repos/%s/actions/secrets" % РЕПО).get("secrets", [])}
    пары = {}
    файл = os.path.join(ЗДЕСЬ, "аккаунты.txt")
    if os.path.exists(файл):
        for строка in open(файл, encoding="utf-8"):
            строка = строка.strip()
            if not строка or строка.startswith("#"):
                continue
            части = строка.split("|")
            if len(части) >= 3:
                пары[части[0].strip()] = (части[1].strip(), части[2].strip())
    for номер in range(1, 11):
        имя = "ARENA_ACC_%02d" % номер
        почта, пароль = пары.get("%02d" % номер, ("", ""))
        запись = {"номер": "%02d" % номер, "секрет": имя in секреты, "почта": почта}
        if почта and пароль:
            код, причина = проверка_входа(почта, пароль)
            запись.update({"код": код, "причина": причина, "годен": код == 200})
        else:
            запись.update({"код": 0, "причина": "нет пары в память/аккаунты.txt", "годен": False})
        итог["аккаунты"].append(запись)
    try:
        for r in гит("repos/%s/actions/runs?per_page=8" % РЕПО)["workflow_runs"]:
            if r["name"] in ("fleet-20-accounts", "council-arena"):
                итог["прогоны"].append({"имя": r["name"], "id": r["id"], "статус": r["status"],
                                        "итог": r["conclusion"], "когда": r["created_at"]})
    except Exception as е:
        итог["ошибка_прогонов"] = str(е)[:80]
    итог["годных"] = sum(1 for а in итог["аккаунты"] if а["годен"])
    итог["машин_в_работе"] = итог["годных"] * 2
    return итог


def кратко() -> str:
    try:
        if os.path.exists(КЭШ) and time.time() - os.path.getmtime(КЭШ) < 600:
            д = json.load(open(КЭШ, encoding="utf-8"))
        else:
            д = считать()
            open(КЭШ, "w", encoding="utf-8").write(json.dumps(д, ensure_ascii=False))
    except Exception as е:
        return "флот: проверить не смог (%s)" % str(е)[:60]
    if "ошибка" in д:
        return "флот: " + д["ошибка"]
    плохие = [а["номер"] for а in д["аккаунты"] if not а["годен"]]
    return ("флот (живая проверка %s): годных аккаунтов %d из 10 → машин в работе %d из 20; "
            "не годятся: %s" % (д["время"][11:16], д["годных"], д["машин_в_работе"],
                                ", ".join(плохие) or "нет"))


def main():
    if "--кратко" in sys.argv:
        print(кратко())
        return 0
    д = считать()
    open(КЭШ, "w", encoding="utf-8").write(json.dumps(д, ensure_ascii=False))
    if "ошибка" in д:
        print(д["ошибка"])
        return 1
    print("проверка %s · репозиторий %s" % (д["время"], РЕПО))
    print("%-4s %-14s %-28s %-6s %s" % ("№", "секрет", "почта", "код", "что говорит арена"))
    for а in д["аккаунты"]:
        print("%-4s %-14s %-28s %-6s %s" % (а["номер"], "есть" if а["секрет"] else "НЕТ",
                                            а["почта"] or "—", а["код"] or "—", а["причина"]))
    print("годных %d из 10 · машин в работе %d из 20" % (д["годных"], д["машин_в_работе"]))
    for п in д["прогоны"][:4]:
        print("  прогон %s id %s · %s/%s · %s" % (п["имя"], п["id"], п["статус"], п["итог"], п["когда"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
