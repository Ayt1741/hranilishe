#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ПАКЕТ — материалы для «мозга» (Battle Code) ссылкой, а не PDF (запрос заказчика №1502 и ход 55).

  python3 память/пакет.py собрать            # собрать очищенный пакет в пакет-55/ и просканировать
  python3 память/пакет.py опубликовать       # положить в ПУБЛИЧНЫЙ репозиторий Ayt1741/battle-pack, напечатать ссылки
  python3 память/пакет.py ссылки             # напечатать raw-ссылки

Правила (законы 21 и 65): в пакет не попадают ключи, пароли, почты, IP и город заказчика. Перед сборкой текст чистится,
после сборки — сканируется; найдено хоть что-то секретное → код 1, публикации не будет.
Имена файлов пакета — латиницей (модели в Code-режиме скачивают их по ссылке).
"""
import base64
import glob
import gzip
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
ВЫХОД = os.path.join(КОРЕНЬ, "пакет-55")
РЕПО = "Ayt1741/battle-pack"
ВЕТКА = "main"
СЫРОЙ = "https://raw.githubusercontent.com/%s/%s/" % (РЕПО, ВЕТКА)

ФАЙЛЫ = [  # имя в пакете ← файл в воркспейсе
    ("LAWS.md", "ЗАКОНЫ.md"),
    ("HANDOFF.md", "ПЕРЕДАЧА.md"),
    ("CONTRACT.md", "КОНТРАКТ.md"),
    ("CORE.md", "память/ядро.md"),
    ("LESSONS.md", "память/УРОКИ.md"),
    ("FACTS.md", "память/ФАКТЫ.md"),
    ("RESEARCH.md", "research/причины-и-решение-55.md"),
    ("CORE12.md", "память/ядро-12.md"),
    ("CHECKER.py", "память/проверка-ответа.py"),
    ("COUNCIL_REPORT.md", "research/совет-ход55/council-result/REPORT.md"),
    ("COUNCIL_FINDINGS.md", "research/совет-ход55/council-result/findings.md"),
    ("COUNCIL_PLAN.md", "research/совет-ход55/council-result/plan.md"),
    ("MY_REPORT.md", "research/мои-поиски-55/REPORT.md"),
    ("MY_FINDINGS.md", "research/мои-поиски-55/findings.md"),
    ("MY_PLAN.md", "research/мои-поиски-55/plan.md"),
    ("TRACE_2026.md", "research/trace-57.md"),
    ("COUNCIL57_REPORT.md", "research/совет-ход57/council-result/REPORT.md"),
    ("LEAK_REPORT.md", "research/утечка-57.md"),
]

ШАБЛОНЫ = [
    (r"\b\d{8,10}:[A-Za-z0-9_\-\\]{30,50}", "токен-telegram"),
    (r"github_pat_[A-Za-z0-9_]{20,}", "токен-github"),
    (r"\bgh[pousr]_[A-Za-z0-9]{20,}", "токен-github"),
    (r"\bgsk_[A-Za-z0-9]{20,}", "ключ-groq"),
    (r"\bsk-or-v1-[A-Za-z0-9]{20,}", "ключ-openrouter"),
    (r"\bsk-[A-Za-z0-9\-]{20,}", "ключ-sk"),
    (r"\btvly-[A-Za-z0-9_\-]{16,}", "ключ-tavily"),
    (r"\bhf_[A-Za-z0-9]{20,}", "ключ-hf"),
    (r"\bKGAT_[A-Za-z0-9]{16,}", "ключ-kaggle"),
    (r"\bjina_[A-Za-z0-9]{20,}", "ключ-jina"),
    (r"\bfc-[A-Za-z0-9]{20,}", "ключ-firecrawl"),
    (r"\bmstrl_[A-Za-z0-9_\-]{16,}", "ключ-mistral"),
    (r"VENICE_INFERENCE_KEY_[A-Za-z0-9]{16,}", "ключ-venice"),
    (r"\bcfat_[A-Za-z0-9]{16,}", "ключ-cloudflare"),
    (r"\beyJ[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{10,}", "jwt"),
    (r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", "почта"),
    (r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "ip"),
    (r"Новосибирск\w*", "город"),
]


def значения_секретов():
    """Точные значения, которые ни при каких условиях не должны оказаться в пакете."""
    знач = set()
    for п in (os.path.join(ЗДЕСЬ, "ключи.txt"),):
        if os.path.exists(п):
            for с in open(п, encoding="utf-8"):
                if "=" in с and not с.lstrip().startswith("#"):
                    к, з = с.strip().split("=", 1)
                    if к.strip() != "телеграм_канал" and len(з.strip()) >= 10:
                        знач.add(з.strip())
    п = os.path.join(ЗДЕСЬ, "аккаунты.txt")
    if os.path.exists(п):
        for с in open(п, encoding="utf-8"):
            ч = с.strip().split("|")
            if len(ч) >= 3 and not с.startswith("#"):
                знач.update(x for x in ч[1:3] if len(x) >= 8)
    return знач


СЕКРЕТЫ = значения_секретов()


ЧУВСТВИТЕЛЬНЫЕ_МЕТКИ = ("cloud-pc", "Codespace", "codespace", "TOTP", "ga_secret", "organic-space", "arena-profile", "my-api-keys")


def убрать_чувствительные_строки(текст):
    """Из публичного пакета выбрасываются целые строки про приватные репозитории, Codespace и 2FA-секреты."""
    return "\n".join(с for с in текст.split("\n") if not any(м in с for м in ЧУВСТВИТЕЛЬНЫЕ_МЕТКИ))


def очистить(текст):
    текст = убрать_чувствительные_строки(текст)
    for з in sorted(СЕКРЕТЫ, key=len, reverse=True):
        текст = текст.replace(з, "[скрыто]")
    for шаблон, имя in ШАБЛОНЫ:
        текст = re.sub(шаблон, "[скрыто:%s]" % имя, текст)
    return текст


def найти_секреты(текст):
    """Что осталось в тексте, чего там быть не должно (после очистки должно быть пусто)."""
    найдено = [з[:4] + "…" for з in СЕКРЕТЫ if з in текст]
    for шаблон, имя in ШАБЛОНЫ:
        for м in re.finditer(шаблон, текст):
            if "[скрыто" in м.group(0):
                continue
            найдено.append("%s:%s…" % (имя, м.group(0)[:4]))
    return найдено


def жалобы():
    """Последние запросы заказчика (из экспорта переписки в воркспейсе), очищенные."""
    п = glob.glob(os.path.join(КОРЕНЬ, "переписка", "*.md.gz"))
    if not п:
        return "# нет экспорта переписки в воркспейсе\n"
    txt = gzip.open(п[0], "rt", encoding="utf-8").read()
    части = re.split(r"(?m)^<!-- msg #(\d+) id: [0-9a-f\-]+ -->\n", txt)
    строки = ["# Запросы заказчика — последние 100 непустых (дословно, очищено от ключей и личных данных)",
              "", "Это его собственные слова из переписки с предыдущим ИИ. Номер — адрес сообщения в экспорте.", ""]
    собрано = []
    for i in range(1, len(части), 2):          # одна группа в шаблоне → пары (номер, текст)
        номер, тело = int(части[i]), части[i + 1]
        if not тело.startswith("## 👤 User"):
            continue
        т = тело.split("\n", 1)[1] if "\n" in тело else ""
        т = re.sub(r"\n---\s*$", "", т.strip()).strip()
        т = re.sub(r"📎 \*\*Файл:\*\* \[[^\]]*\]\([^)]*\)", "[файл]", т).strip()
        if not т or т.startswith("_(пустое сообщение)_") or номер < 1200:
            continue
        if len(т) < 45 and re.match(r"(?i)^(продолж\w*|давай|делай|дальше|доделай)", т):
            continue
        собрано.append((номер, т[:1800] + (" …[обрезано]" if len(т) > 1800 else "")))
    for номер, т in собрано[-100:]:
        строки += ["## #%d" % номер, "", т, ""]
    return "\n".join(строки) + "\n"


def инструменты():
    строки = ["# Инструменты в воркспейсе (имя — первая строка описания)", ""]
    for маска in ("*.py", "память/*.py", "панель/*.py"):
        for п in sorted(glob.glob(os.path.join(КОРЕНЬ, маска))):
            try:
                с = open(п, encoding="utf-8").read()
            except OSError:
                continue
            м = re.search(r'"""(.*?)"""', с, flags=re.S)
            первая = ""
            if м:
                первая = " ".join(м.group(1).strip().splitlines()[:2]).strip()
            строки.append("- `%s` — %s" % (os.path.relpath(п, КОРЕНЬ), первая[:230]))
    return "\n".join(строки) + "\n"


def задание():
    """Текст задания «мозгу» хранится в файле память/шаблон-задания-battle.md (версия 2: роли исправлены заказчиком)."""
    return open(os.path.join(ЗДЕСЬ, "шаблон-задания-battle.md"), encoding="utf-8").read()


def индекс():
    с = ["# Пакет материалов — порядок чтения", "",
         "Репозиторий: https://github.com/%s (публичный, очищен от ключей, паролей, почт, IP)." % РЕПО, "",
         "| № | Файл | Что это | Прямая ссылка |", "|---|---|---|---|"]
    опис = {  # первые 7 — обязательные к прочтению
        "TASK.md": "само задание (версия 2, роли исправлены) — читать первым",
        "MY_REPORT.md": "итог независимого поиска агента по протоколу заказчика (этап 4) — ПРОВЕРИТЬ",
        "COUNCIL_REPORT.md": "отчёт совета из 40 агентов (этап 4) — ПРОВЕРИТЬ, часть советов нарушает условия среды",
        "COUNCIL_FINDINGS.md": "находки совета: гипотеза → цитата → ссылка → вердикт — выборочно ПРОВЕРИТЬ цитаты",
        "MY_FINDINGS.md": "находки агента: гипотеза → цитата → ссылка → вердикт — выборочно ПРОВЕРИТЬ цитаты",
        "CORE12.md": "закреплённое ядро из 12 правил (черновик агента) — ОЦЕНИТЬ",
        "CHECKER.py": "проверка ответа перед отправкой, замена Stop-хука (черновик агента) — ОЦЕНИТЬ",
        "COUNCIL_PLAN.md": "план совета (этап 0): таблица запросов по гипотезам",
        "MY_PLAN.md": "план агента (этап 0) и запросы «по ходу»",
        "TOOLS.md": "инструменты рабочей папки",
        "USER_COMPLAINTS.md": "100 последних запросов заказчика (его слова)",
        "CORE.md": "короткое ядро законов",
        "LAWS.md": "законы заказчика (полный список, архив)",
        "HANDOFF.md": "состояние работы, решения, частые претензии (§4г — этот ход)",
        "CONTRACT.md": "что построено прошлым ИИ против нарушений",
        "LESSONS.md": "уроки (что ломалось)",
        "FACTS.md": "проверенные факты",
        "RESEARCH.md": "прежний разбор агента на 100 запросах, сделанных самим агентом (заказчик назвал это ошибкой ролей); использовать как справку, не как основу",
    }
    for н, (имя, о) in enumerate(опис.items(), 1):
        с.append("| %d | %s | %s | %s%s |" % (н, имя, о, СЫРОЙ, имя))
    return "\n".join(с) + "\n"


def собрать():
    os.makedirs(ВЫХОД, exist_ok=True)
    содержимое = {"TASK.md": задание(), "USER_COMPLAINTS.md": жалобы(), "TOOLS.md": инструменты()}
    for имя, путь in ФАЙЛЫ:
        п = os.path.join(КОРЕНЬ, путь)
        содержимое[имя] = open(п, encoding="utf-8").read() if os.path.exists(п) else "(файл %s не найден)\n" % путь
    содержимое["INDEX.md"] = индекс()
    плохо = 0
    for имя, т in содержимое.items():
        чистый = очистить(т)
        остаток = найти_секреты(чистый)
        if остаток:
            плохо += 1
            print("СЕКРЕТ ОСТАЛСЯ в %s: %s" % (имя, остаток[:5]))
        open(os.path.join(ВЫХОД, имя), "w", encoding="utf-8").write(чистый)
        print("%-20s %7d симв." % (имя, len(чистый)))
    print("ИТОГ: файлов %d · всего %.0f КБ · секретов после очистки: %s" % (
        len(содержимое), sum(len(очистить(x)) for x in содержимое.values()) / 1024, "НАЙДЕНЫ" if плохо else "0"))
    return 1 if плохо else 0


def ключ_github():
    for с in open(os.path.join(ЗДЕСЬ, "ключи.txt"), encoding="utf-8"):
        if с.startswith("github="):
            return с.strip().split("=", 1)[1]
    return ""


def гх(метод, url, данные=None):
    з = urllib.request.Request(url, method=метод, data=json.dumps(данные).encode() if данные is not None else None,
                               headers={"Authorization": "Bearer " + ключ_github(), "User-Agent": "paket",
                                        "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(з, timeout=60) as о:
            return о.status, json.loads(о.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}


def опубликовать():
    if собрать() != 0:
        print("ОТКАЗ: в пакете остались секреты — публикации нет")
        return 1
    с, р = гх("GET", "https://api.github.com/repos/%s" % РЕПО)
    if с == 404:
        с, р = гх("POST", "https://api.github.com/user/repos",
                  {"name": РЕПО.split("/")[1], "private": False, "auto_init": True,
                   "description": "Материалы для Battle Code (очищены от ключей и личных данных)"})
        print("репозиторий создан:" if с in (200, 201) else "репозиторий не создан:", с, р.get("html_url") or р.get("message"))
        if с not in (200, 201):
            return 1
    for имя in sorted(os.listdir(ВЫХОД)):
        данные = open(os.path.join(ВЫХОД, имя), "rb").read()
        url = "https://api.github.com/repos/%s/contents/%s" % (РЕПО, urllib.parse.quote(имя))
        с, р = гх("GET", url)
        тело = {"message": "пакет хода 55: " + имя, "content": base64.b64encode(данные).decode(), "branch": ВЕТКА}
        if с == 200:
            тело["sha"] = р["sha"]
        с, р = гх("PUT", url, тело)
        print("  %-20s %s" % (имя, "ok %s" % с if с in (200, 201) else "ОШИБКА %s %s" % (с, р.get("message"))))
        if с not in (200, 201):
            return 1
    ссылки()
    return 0


def ссылки():
    for имя in sorted(os.listdir(ВЫХОД)):
        print(СЫРОЙ + имя)


if __name__ == "__main__":
    к = sys.argv[1] if len(sys.argv) > 1 else ""
    sys.exit({"собрать": собрать, "опубликовать": опубликовать, "ссылки": lambda: (ссылки() or 0)}.get(к, lambda: print(__doc__) or 2)())
