#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
УБОРКА — воркспейс держим чистым, но НИЧЕГО не теряем.

Правило заказчика: удалять нельзя абсолютно ничего. Поэтому:
  1) всё лишнее упаковывается в архив;
  2) архив уходит в Телеграм (постоянное хранилище, канал -1003772678641);
  3) каждый предмет записывается в память/уборки.jsonl: имя, размер, sha256,
     message_id, file_id;
  4) только после подтверждённой записи в Телеграм локальная копия убирается;
  5) любую вещь можно вернуть: `--вернуть <имя>` — скачает архив из Телеграма
     по file_id и распакует обратно.

    python3 память/уборка.py --показать          # что ушло бы в память
    python3 память/уборка.py                     # убрать (с записью в Телеграм)
    python3 память/уборка.py --вернуть "имя"     # вернуть предмет в воркспейс
    python3 память/уборка.py --список            # что уже убрано и где лежит
"""
import fnmatch
import importlib.util
import json
import os
import shutil
import sys
import tarfile
import time
import urllib.request

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
АРХИВ = os.path.join(ЗДЕСЬ, "архив")
СПИСОК = os.path.join(ЗДЕСЬ, "что-держать.txt")
УЧЁТ = os.path.join(ЗДЕСЬ, "уборки.jsonl")
КАНАЛ = "-1003772678641"

ПО_УМОЛЧАНИЮ = """# Что остаётся в воркспейсе. Одна маска на строку. Остальное уходит в память (Телеграм) и может быть возвращено.
память/*
ПК/*
переписка/*
ИНСТРУКЦИЯ-ПРОСТО.md
ПАМЯТЬ-ПРОСТО.md
ПЛАН-РЕАЛИЗАЦИИ.md
ОТЧЁТ-ПАМЯТЬ-1295.md
index.html
ХРАНИЛИЩЕ-v7.0.html
"""


def список():
    if not os.path.exists(СПИСОК):
        open(СПИСОК, "w", encoding="utf-8").write(ПО_УМОЛЧАНИЮ)
    return [с.strip() for с in open(СПИСОК, encoding="utf-8")
            if с.strip() and not с.strip().startswith("#")]


def держать(имя, маски):
    return any(fnmatch.fnmatch(имя, м) or имя == м.rstrip("/*") for м in маски)


def собрать_лишнее(маски):
    return [и for и in sorted(os.listdir(КОРЕНЬ)) if not и.startswith(".") and not держать(и, маски)]


def размер(путь):
    if os.path.isfile(путь):
        return os.path.getsize(путь)
    всего = 0
    for основа, папки, файлы in os.walk(путь):
        for ф in файлы:
            try:
                всего += os.path.getsize(os.path.join(основа, ф))
            except OSError:
                pass
    return всего


def память_модуль():
    с = importlib.util.spec_from_file_location("п", os.path.join(ЗДЕСЬ, "память.py"))
    м = importlib.util.module_from_spec(с)
    с.loader.exec_module(м)
    return м


def записать_учёт(строка):
    with open(УЧЁТ, "a", encoding="utf-8") as ф:
        ф.write(json.dumps(строка, ensure_ascii=False) + "\n")


def прочесть_учёт():
    if not os.path.exists(УЧЁТ):
        return []
    return [json.loads(с) for с in open(УЧЁТ, encoding="utf-8") if с.strip()]


def убрать(показать=False, в_тг=True):
    маски = список()
    лишнее = собрать_лишнее(маски)
    if not лишнее:
        print("уборка: лишнего нет — в воркспейсе только нужное. Ничего не удалено.")
        return 0
    объём = sum(размер(os.path.join(КОРЕНЬ, и)) for и in лишнее)
    print("лишнее: %d объектов · %.1f МБ" % (len(лишнее), объём / 1e6))
    for и in лишнее:
        print("   %-38s %8.1f КБ" % (и[:38], размер(os.path.join(КОРЕНЬ, и)) / 1024))
    токен = os.environ.get("TG_TOKEN")
    if показать or not в_тг or not токен:
        if not показать:
            print("НЕ убираю: %s" % ("нет TG_TOKEN — без копии в памяти ничего не удаляется" if not токен else "выключен Телеграм"))
        else:
            print("это показ — ничего не тронуто")
        return 0
    os.makedirs(АРХИВ, exist_ok=True)
    метка = time.strftime("%Y%m%d-%H%M%S")
    путь = os.path.join(АРХИВ, "уборка-%s.tar.gz" % метка)
    with tarfile.open(путь, "w:gz") as т:
        for и in лишнее:
            т.add(os.path.join(КОРЕНЬ, и), arcname=и)
    итог = {"время": метка, "объектов": len(лишнее), "байт": os.path.getsize(путь),
            "предметы": лишнее}
    п = память_модуль()
    file_id, mid, разм = п.в_телеграм(путь, п._sha(путь), токен)
    итог.update({"message_id": mid, "file_id": file_id, "файл": os.path.basename(путь)})
    записать_учёт(итог)
    print("в памяти: message_id %s · %d байт · запись в %s" % (mid, разм, os.path.basename(УЧЁТ)))
    if not mid or not file_id:
        print("НЕ убираю: Телеграм не подтвердил запись")
        return 1
    shutil.rmtree(АРХИВ, ignore_errors=True)   # локальная копия не нужна: она в Телеграме
    for и in лишнее:
        полный = os.path.join(КОРЕНЬ, и)
        if os.path.isdir(полный):
            shutil.rmtree(полный, ignore_errors=True)
        else:
            os.chmod(полный, 0o644)
            os.remove(полный)
    осталось = sum(размер(os.path.join(КОРЕНЬ, и)) for и in os.listdir(КОРЕНЬ) if not и.startswith("."))
    print("убрано из воркспейса %d объектов · осталось %.1f МБ · всё возвращаемо командой --вернуть" %
          (len(лишнее), осталось / 1e6))
    return 0


def показать_учёт():
    записи = прочесть_учёт()
    if not записи:
        print("учёт пуст")
        return 0
    for з in записи:
        print("%s · %.1f МБ · message_id %s · предметов %d" %
              (з["время"], з["байт"] / 1e6, з["message_id"], len(з["предметы"])))
        for и in з["предметы"]:
            print("     ", и)
    return 0


def вернуть(что):
    токен = os.environ.get("TG_TOKEN")
    if not токен:
        print("нужен TG_TOKEN, чтобы скачать архив из памяти")
        return 1
    совпало = [з for з in прочесть_учёт() if any(что in и for и in з["предметы"])]
    if not совпало:
        print("в учёте нет предмета «%s» — смотри --список" % что)
        return 1
    з = совпало[-1]
    с = urllib.request.Request("https://api.telegram.org/bot%s/getFile?file_id=%s" % (токен, з["file_id"]))
    with urllib.request.urlopen(с, timeout=60) as х:
        путь_тг = json.load(х)["result"]["file_path"]
    местный = os.path.join("/tmp", з["файл"])
    with urllib.request.urlopen("https://api.telegram.org/file/bot%s/%s" % (токен, путь_тг), timeout=300) as х, open(местный, "wb") as ф:
        shutil.copyfileobj(х, ф)
    с_архивом = tarfile.open(местный, "r:gz")
    имена = [и for и in с_архивом.getnames() if и == что or и.startswith(что.rstrip("/") + "/")]
    if not имена:
        print("в архиве %s нет «%s»" % (з["файл"], что))
        return 1
    с_архивом.extractall(КОРЕНЬ, members=[с_архивом.getmember(и) for и in имена])
    print("возвращено %d элементов «%s» из %s (message_id %s)" % (len(имена), что, з["файл"], з["message_id"]))
    return 0


def main():
    а = sys.argv[1:]
    if "--вернуть" in а:
        return вернуть(а[а.index("--вернуть") + 1])
    if "--список" in а:
        return показать_учёт()
    return убрать(показать="--показать" in а, в_тг="--без-тг" not in а)


if __name__ == "__main__":
    sys.exit(main())
