#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ЦИКЛ — вся память одной командой, на этой машине, на каждый запрос.

    python3 память/цикл.py начало "<текст запроса>"
        • подхватывает новые файлы экспорта из uploads/ и переписка/ (если появились)
        • пишет запрос в память (до работы)
        • проверяет базу, целостность хвоста, гейт старта
        • делает впрыск по теме запроса (6 фрагментов, <=2000 токенов)

    python3 память/цикл.py конец "<текст ответа>"
        • пишет ответ в память (после работы)
        • проверяет, что долга нет
        • раз в сутки делает архив и отправляет его в Телеграм
        • печатает короткий итог

Почему так: процессы в песочнице между запросами не живут, а файлы — живут.
Поэтому «постоянную программу» заменяет цикл, который запускается сам
на каждом запросе: начало → работа → конец.
"""
import glob
import gzip
import hashlib
import importlib.util
import json
import os
import sys
import time

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
КОРЕНЬ = os.path.dirname(ЗДЕСЬ)
СОСТОЯНИЕ = os.path.join(ЗДЕСЬ, "состояние.json")
АРХИВ = os.path.join(ЗДЕСЬ, "архив")
СЛЕДЫ = os.path.join(ЗДЕСЬ, "просмотренные-экспорты.json")
ПАПКИ_ВХОДА = [os.path.join(КОРЕНЬ, "uploads"), os.path.join(КОРЕНЬ, "переписка")]


def память():
    спецификация = importlib.util.spec_from_file_location("п", os.path.join(ЗДЕСЬ, "память.py"))
    м = importlib.util.module_from_spec(спецификация)
    спецификация.loader.exec_module(м)
    return м


def состояние():
    if os.path.exists(СОСТОЯНИЕ):
        try:
            return json.loads(open(СОСТОЯНИЕ, encoding="utf-8").read())
        except Exception:
            return {}
    return {}


def сохранить(данные):
    сейчас = состояние()
    сейчас.update(данные)
    open(СОСТОЯНИЕ, "w", encoding="utf-8").write(
        json.dumps(сейчас, ensure_ascii=False, indent=1))


def хэш_файла(путь):
    х = hashlib.sha256()
    with open(путь, "rb") as ф:
        for кусок in iter(lambda: ф.read(1 << 20), b""):
            х.update(кусок)
    return х.hexdigest()[:16]


МАРКЕРЫ_ЭКСПОРТА = ("<!-- msg #", "## 👤 User", "## 🤖 Assistant", "## user", "## assistant")


def это_переписка(текст):
    """Файл считается экспортом переписки только если в нём размечены роли."""
    начало = текст[:5000]
    return any(м in начало for м in МАРКЕРЫ_ЭКСПОРТА)


def подхватить_экспорты(п):
    """Любой новый файл переписки, попавший в uploads/ или переписка/, вливается сам."""
    следы = {}
    if os.path.exists(СЛЕДЫ):
        try:
            следы = json.loads(open(СЛЕДЫ, encoding="utf-8").read())
        except Exception:
            следы = {}
    добавлено_всего = 0
    for папка in ПАПКИ_ВХОДА:
        for путь in sorted(glob.glob(os.path.join(папка, "*"))):
            if not os.path.isfile(путь):
                continue
            if not путь.lower().endswith((".md", ".txt", ".gz", ".jsonl")):
                continue
            след = хэш_файла(путь)
            if следы.get(путь) == след:
                continue
            try:
                if путь.endswith(".gz"):
                    with gzip.open(путь, "rt", encoding="utf-8", errors="ignore") as ф:
                        текст = ф.read()
                else:
                    текст = open(путь, encoding="utf-8", errors="ignore").read()
                if not это_переписка(текст):
                    следы[путь] = след
                    print("пропуск %s — это не переписка (нет разметки ролей)" %
                          os.path.basename(путь))
                    continue
                сообщения = п.разобрать(текст, путь)
                известно = {п.отпечаток(м["роль"], м["текст"]) for м in п.читать_журнал()}
                совпало = sum(1 for р, т in сообщения if п.отпечаток(р, т) in известно)
                доля = совпало / max(len(сообщения), 1)
                # 1) файл не длиннее журнала, но часть содержимого знакома → это старая версия
                #    (журнал только растёт, поэтому короткий файл того же диалога всегда старше)
                if len(сообщения) <= п.последний_номер() and доля >= 0.10:
                    следы[путь] = след
                    print("пропуск %s — старая версия диалога "
                          "(сообщений %d ≤ записей %d, совпало %.0f %%)" %
                          (os.path.basename(путь), len(сообщения), п.последний_номер(), доля * 100))
                    continue
                # 2) почти всё уже есть
                if доля >= 0.6 and len(сообщения) <= п.последний_номер():
                    следы[путь] = след
                    print("пропуск %s — уже в памяти (совпало %.0f %%, сообщений %d)" %
                          (os.path.basename(путь), доля * 100, len(сообщения)))
                    continue
                было = п.последний_номер()
                if сообщения:
                    п.записать(сообщения, путь, тихо=True)
                стало = п.последний_номер()
                следы[путь] = след
                if стало > было:
                    добавлено_всего += стало - было
                    print("экспорт подхвачен: %s → разобрано %d, добавлено %d" %
                          (os.path.basename(путь), len(сообщения), стало - было))
            except Exception as е:
                print("экспорт не разобран (%s): %s" % (os.path.basename(путь), е))
    open(СЛЕДЫ, "w", encoding="utf-8").write(json.dumps(следы, ensure_ascii=False, indent=1))
    return добавлено_всего


def начало(запрос):
    п = память()
    print("═══ НАЧАЛО ═══")
    подхватить_экспорты(п)
    п.убедиться_база()
    п.записать_запрос(запрос)
    п.старт(тихо=True)
    сохранить({"начало": time.strftime("%Y-%m-%dT%H:%M:%S")})
    код = п.гейт()
    if код:
        print("ВНИМАНИЕ: гейт не пройден — сначала старт")
    тема = " ".join(запрос.split()[:12])
    текст = open(os.path.join(ЗДЕСЬ, "ВПРЫСК.md"), encoding="utf-8").read() \
        if os.path.exists(os.path.join(ЗДЕСЬ, "ВПРЫСК.md")) else ""
    print("── впрыск по теме запроса ──")
    буфер = sys.stdout
    try:
        import io
        from contextlib import redirect_stdout
        with redirect_stdout(io.StringIO()):
            п.впрыск(тема)
    finally:
        sys.stdout = буфер
    if os.path.exists(os.path.join(ЗДЕСЬ, "ВПРЫСК.md")):
        print(open(os.path.join(ЗДЕСЬ, "ВПРЫСК.md"), encoding="utf-8").read()[:2500])
    # ПОЛНЫЙ ПРОХОД: 100% переписки перед каждым запросом (машинно, с доказательством)
    try:
        import subprocess
        print("── полный проход по переписке ──")
        р = subprocess.run([sys.executable, os.path.join(ЗДЕСЬ, "полный.py"), "--запрос", тема],
                           capture_output=True, text=True, timeout=300)
        print(р.stdout.strip()[:200000] if р.stdout else "полный проход: пусто (%s)" % р.stderr[:200])
    except Exception as е:
        print("полный проход не удался: %s" % е)
    # живая проверка флота: цифры только от GitHub и арены
    try:
        import subprocess
        print("── флот (живая проверка) ──")
        print(subprocess.run([sys.executable, os.path.join(ЗДЕСЬ, "флот.py"), "--кратко"],
                             capture_output=True, text=True, timeout=180).stdout.strip())
    except Exception as е:
        print("флот: проверить не смог (%s)" % е)
    # совет флота: на каждый запрос, а не по праздникам
    try:
        import subprocess
        print("── совет флота ──")
        код = subprocess.call([sys.executable, os.path.join(ЗДЕСЬ, "совет.py"), тема])
        if код != 0:
            print("совет не ответил (код %d) — продолжаю сам" % код)
    except Exception as е:
        print("совет недоступен: %s" % е)
    файл_фактов = os.path.join(ЗДЕСЬ, "ФАКТЫ.md")
    if os.path.exists(файл_фактов):
        print("── ключевые факты (проверять перед утверждением) ──")
        print("\n".join(open(файл_фактов, encoding="utf-8").read().splitlines()[:26]))
    print("═══ ГОТОВ К РАБОТЕ ═══")


def конец(ответ):
    п = память()
    print("═══ КОНЕЦ ═══")
    п.записать_ответ(ответ)
    код = п.долг()
    п.быстрый_чек()
    с = состояние()
    последний = с.get("архив_последний", 0)
    if time.time() - float(последний) > 24 * 3600:
        try:
            путь, сумма = п.архив(в_тг=False)
            с["архив_последний"] = time.time()
            с["архив_имя"] = os.path.basename(путь)
            сохранить(с)
            print("архив за сутки: %s" % os.path.basename(путь))
            токен = os.environ.get("TG_TOKEN")
            if токен:
                file_id, mid, размер = п.в_телеграм(путь, сумма, токен)
                print("в Телеграм: message_id %s · %d байт" % (mid, размер))
                п.ротация(3)
        except Exception as е:
            print("архив не сделан: %s" % е)
    print("итог: записей %d · долг %s" % (п.последний_номер(), "нет" if код == 0 else "ЕСТЬ"))


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return
    режим, текст = sys.argv[1], " ".join(sys.argv[2:])
    if режим == "начало":
        начало(текст)
    elif режим == "конец":
        конец(текст)
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
