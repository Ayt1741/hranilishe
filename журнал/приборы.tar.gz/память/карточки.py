#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""СЧЁТЧИК КАРТОЧЕК ОШИБОК (П5, ход 62). Ловит признаки из память/КАРТОЧКИ.md в ответе и действиях хода.

  python3 память/карточки.py --ответ ответы/ХОД-N.md --ход N
Код 0 — повторов нет; 1 — есть повторы (печатает, какие).
Каждая ловля дописывается в память/карточки-ловля.jsonl (append-only, как audit log в C-Trace).
"""
import argparse, datetime, json, os, re, sys

КОРЕНЬ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ЖУРНАЛ = os.path.join(КОРЕНЬ, "память", "карточки-ловля.jsonl")
ДЕЙСТВИЯ = os.path.join(КОРЕНЬ, "панель", "действия.jsonl")

ПРИЗНАКИ = [
    ("К2", "квитанция без действия", re.compile(r"Проверка ответа:\s*№\s*_+")),
    ("К5", "просьба нажать/капча", re.compile(r"(?i)(нажми|пройди капчу|введи капчу|подтверди окно)")),
    ("К8", "число без источника", re.compile(r"(?i)\b(\d+)-?е место\b(?!.*http)")),
]

def ловить_в_тексте(текст, ход):
    найдено = []
    for код, имя, шаблон in ПРИЗНАКИ:
        м = шаблон.search(текст)
        if м:
            найдено.append((код, имя, м.group(0)[:60]))
    return найдено

def ловить_в_действиях(ход):
    """К3: правка .py без ast.parse; К6: блокирующее ожидание."""
    найдено = []
    записи = []
    if os.path.exists(ДЕЙСТВИЯ):
        for строка in open(ДЕЙСТВИЯ, encoding="utf-8"):
            try:
                д = json.loads(строка)
            except Exception:
                continue
            if str(д.get("ход")) == str(ход):
                записи.append(д)
    for д in записи:
        ком = д.get("команда", "") or ""
        выв = д.get("вывод", "") or ""
        # К3: правили .py, а следа проверки синтаксиса нет.
        # Ход 66, ложное срабатывание: «python3 выложить.py 2>&1 | tail -4» считалось правкой,
        # потому что в команде есть «>» (это 2>&1) и имя .py. Правка — это ЗАПИСЬ В ФАЙЛ:
        # python3 - <<PY ... write, sed -i по .py, или перенаправление в .py.
        правим_питон = (
            re.search(r"sed\s+-i[^|;&]*\.py", ком)
            or re.search(r">\s*\S*\.py\b", ком)
            or (re.search(r"(write_file|open\([^)]*\.py[^)]*,\s*['\"]w)", ком))
        )
        if правим_питон and "ast.parse" not in (выв or "") and "ast.parse" not in ком:
            найдено.append(("К3", "правка .py без ast.parse", ком[:70]))
        м = re.search(r"\b(ждать|sleep)\s+(\d{3,})", ком)
        if м and int(м.group(2)) > 120 and "start_process" not in ком:
            найдено.append(("К6", "блокирующее ожидание %s с" % м.group(2), ком[:70]))
    return найдено

def main():
    п = argparse.ArgumentParser()
    п.add_argument("--ответ")
    п.add_argument("--ход", required=True)
    а = п.parse_args()
    найдено = []
    if а.ответ and os.path.exists(а.ответ):
        найдено += ловить_в_тексте(open(а.ответ, encoding="utf-8").read(), а.ход)
    найдено += ловить_в_действиях(а.ход)
    if not найдено:
        print("КАРТОЧКИ: повторов нет — код 0")
        return 0
    with open(ЖУРНАЛ, "a", encoding="utf-8") as ф:
        for код, имя, где in найдено:
            ф.write(json.dumps({"время": datetime.datetime.now().isoformat(timespec="seconds"),
                                "ход": а.ход, "карточка": код, "что": имя, "где": где}, ensure_ascii=False) + "\n")
    print("КАРТОЧКИ: повторов %d" % len(найдено))
    for код, имя, где in найдено:
        print("  %s %s — %s" % (код, имя, где))
    return 1

if __name__ == "__main__":
    sys.exit(main())
