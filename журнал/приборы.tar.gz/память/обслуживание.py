#!/usr/bin/env python3
"""
Обслуживание памяти — один запуск раз в неделю (cron / Планировщик Windows).

Что делает:
  1. быстрая проверка целостности хвоста журнала;
  2. ротация архивов (держим последние 3);
  3. новый неизменяемый архив + отправка в Телеграм;
  4. отчёт ОТЧЁТ-ПАМЯТИ.md.

Запуск:
  python3 память/обслуживание.py                 # локально
  TG_TOKEN=... python3 память/обслуживание.py    # с копией в Телеграм

Расписание (Linux):  0 4 * * 1  TG_TOKEN=... python3 /home/user/память/обслуживание.py
Расписание (Windows):
  schtasks /Create /SC WEEKLY /D MON /TN "Память" /TR "python C:\\путь\\обслуживание.py"
"""
import os
import subprocess
import sys

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
ПАМЯТЬ = os.path.join(ЗДЕСЬ, "память.py")


def шаг(команда, *аргументы):
    print("\n=== %s ===" % " ".join([команда] + list(аргументы)))
    код = subprocess.call([sys.executable, ПАМЯТЬ, команда] + list(аргументы))
    if код != 0 and команда != "гейт":
        print("шаг завершился с кодом %d — продолжаю" % код)
    return код


def main():
    шаг("быстрый-чек")
    шаг("ротация", "3")
    шаг("архив", "--в-тг") if os.environ.get("TG_TOKEN") else шаг("архив")
    шаг("отчёт")
    print("\nобслуживание памяти завершено")


if __name__ == "__main__":
    main()
