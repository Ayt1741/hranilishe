#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ОРУЖЕЙНАЯ В PDF — чтобы заливать в Direct, где нет интернета.

Ты сказал: в Direct топовые модели, но интернета у них нет, поэтому работать
по старой схеме — заливать готовое файлом и давать ссылку + PDF.
Этот прибор делает PDF из память/ОРУЖЕЙНАЯ.md, с кириллицей (шрифт DejaVu).

  python3 память/оружейная-pdf.py                       # → ответы/ОРУЖЕЙНАЯ.pdf
  python3 память/оружейная-pdf.py --файл память/ОРУЖЕЙНАЯ.md --выход ответы/ОРУЖЕЙНАЯ.pdf

Требует fpdf2 (не входит в стандартную библиотеку):
  pip install fpdf2
Коды: 0 готово · 2 нет fpdf2 · 3 нет входного файла.
"""
import argparse
import os
import re
import sys

БАЗА = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ШРИФТ = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
ШРИФТ_Ж = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
ШРИФТ_М = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"


def собрать(вход, выход):
    try:
        from fpdf import FPDF
    except ImportError:
        print("нет fpdf2 — поставь: pip install fpdf2")
        return 2
    if not os.path.exists(вход):
        print("нет входного файла:", вход)
        return 3

    текст = open(вход, encoding="utf-8").read()

    п = FPDF(format="A4", unit="mm")
    п.set_auto_page_break(auto=True, margin=15)
    п.set_margins(15, 15, 15)
    п.add_font("DejaVu", "", ШРИФТ)
    п.add_font("DejaVu", "B", ШРИФТ_Ж)
    п.add_font("Mono", "", ШРИФТ_М)
    п.add_page()

    def строка(т, стиль="", размер=10, шрифт="DejaVu", отступ=0):
        п.set_font(шрифт, стиль, размер)
        if отступ:
            п.set_x(15 + отступ)
        п.multi_cell(0 if not отступ else 180 - отступ, 5, т)
        п.ln(0.6)

    def чистить(т):
        # убираем markdown-разметку, но оставляем сами слова
        т = re.sub(r"\*\*(.+?)\*\*", r"\1", т)
        т = re.sub(r"`(.+?)`", r"\1", т)
        т = т.replace("\u2192", "->").replace("\u2190", "<-")
        return т

    for стр in текст.split("\n"):
        с = стр.rstrip()
        if not с:
            п.ln(1.5)
            continue
        if с.startswith("# "):
            п.add_page()
            строка(чистить(с[2:]), "B", 18)
            п.ln(2)
        elif с.startswith("## "):
            п.ln(1)
            строка(чистить(с[3:]), "B", 14)
            п.ln(0.5)
        elif с.startswith("### "):
            строка(чистить(с[4:]), "B", 11.5)
        elif с.startswith("---"):
            п.ln(1)
        elif с.startswith("| "):
            cells = [x.strip() for x in с.strip("|").split("|")]
            if all(set(x) <= set("-: ") for x in cells):
                continue
            строка(чистить("  ·  ".join(cells)), "", 8.5, "Mono")
        elif с.startswith("- "):
            строка("• " + чистить(с[2:]), "", 10, отступ=3)
        elif re.match(r"^\d+\. ", с):
            строка(чистить(с), "", 10, отступ=3)
        else:
            строка(чистить(с), "", 10)

    os.makedirs(os.path.dirname(выход) or ".", exist_ok=True)
    п.output(выход)
    размер = os.path.getsize(выход)
    print("готово:", выход, "· страниц:", п.page, "· %d КБ" % (размер // 1024))
    return 0


def main():
    р = argparse.ArgumentParser(description="ОРУЖЕЙНАЯ → PDF")
    р.add_argument("--файл", default=os.path.join(БАЗА, "память", "ОРУЖЕЙНАЯ.md"))
    р.add_argument("--выход", default=os.path.join(БАЗА, "ответы", "ОРУЖЕЙНАЯ.pdf"))
    а = р.parse_args()
    sys.exit(собрать(а.файл, а.выход))


if __name__ == "__main__":
    main()
