#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Список моделей Direct на Arena — по одному аккаунту, через браузер.

Зачем: в Battle модели анонимны (непонятно, кто ответил), поэтому сравнивать
конкретные модели по коду можно только в Direct, где имя выбирается рукой.

  python3 память/direct-модели.py            # список моделей
  python3 память/direct-модели.py --скрин    # + скриншот выпадающего списка
"""
import asyncio
import base64
import json
import os
import re
import sys
import urllib.request
import importlib.util


UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')
АККАУНТЫ = "/home/user/память/аккаунты.txt"


def знаки():
    строки = []
    for l in open(АККАУНТЫ, encoding="utf-8"):
        l = l.strip()
        if "|" in l and "@" in l and not l.startswith("#"):
            строки.append(l.split("|"))
    return строки


def вход(почта, пароль):
    r = urllib.request.Request("https://arena.ai/nextjs-api/sign-in/email",
                               data=json.dumps({'email': почта, 'password': пароль}).encode(),
                               method="POST")
    for k, v in {'content-type': 'application/json', 'user-agent': UA,
                 'origin': 'https://arena.ai', 'referer': 'https://arena.ai/text'}.items():
        r.add_header(k, v)
    with urllib.request.urlopen(r, timeout=45) as x:
        печеньки = []
        for c in x.headers.get_all("Set-Cookie") or []:
            n, rest = c.split("=", 1)
            печеньки.append((n, rest.split(";")[0]))
        полез = json.loads(x.read().decode())
    raw = "".join(v for n, v in печеньки if n.startswith("arena-auth"))
    raw = raw[7:] if raw.startswith("base64-") else raw
    js = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4)).decode())
    return js.get("access_token", ""), [
        {"name": "arena-auth-prod-v1.0", "value": "base64-" + raw[:len(raw) // 2],
         "domain": "arena.ai", "path": "/"},
        {"name": "arena-auth-prod-v1.1", "value": raw[len(raw) // 2:],
         "domain": "arena.ai", "path": "/"}], полез


async def собрать():
    from playwright.async_api import async_playwright
    почта, пароль = знаки()[0][1], знаки()[0][2]
    токен, печеньки, полез = вход(почта, пароль)
    print("вход:", (полез.get("user") or {}).get("email"))
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await b.new_context(user_agent=UA, locale="en-US", viewport={"width": 1500, "height": 950})
        await ctx.add_cookies(печеньки)
        pg = await ctx.new_page()
        await pg.goto("https://arena.ai/direct", wait_until="domcontentloaded", timeout=90000)
        await pg.wait_for_timeout(6000)
        # клик по «Direct» на стартовой заглушке
        for надпись in ("Direct", "Direct Chat"):
            try:
                кнопка = pg.get_by_role("button", name=надпись, exact=False).first
                if await кнопка.count():
                    await кнопка.click(timeout=6000)
                    await pg.wait_for_timeout(2500)
                    break
            except Exception as e:
                print("кнопка", надпись, "не нажалась:", str(e)[:80])
        await pg.wait_for_timeout(2500)
        текст = await pg.inner_text("body")
        # ищем кнопку выбора модели (обычно кнопка с именем текущей модели)
        модели = []
        for имя in ("Select model", "Choose a model", "Max", "Auto"):
            try:
                b2 = pg.get_by_role("button", name=имя, exact=False).first
                if await b2.count():
                    await b2.click(timeout=5000)
                    await pg.wait_for_timeout(2500)
                    break
            except Exception:
                pass
        # выпадающий список
        for селектор in ("[role=option]", "[role=listbox] [role=option]", "li[role=option]",
                         "[data-testid*=model]", "text=/^muse/i"):
            try:
                эл = await pg.query_selector_all(селектор)
                if эл:
                    for e in эл:
                        t = (await e.inner_text()).strip()
                        if t and len(t) < 120:
                            модели.append(t)
                    if модели:
                        break
            except Exception:
                pass
        # прокрутка выпадающего списка — иначе часть моделей не видна
        try:
            await pg.mouse.move(700, 500)
            for _ in range(12):
                await pg.mouse.wheel(0, 600)
                await pg.wait_for_timeout(700)
            await pg.wait_for_timeout(1500)
            for селектор in ("[role=option]", "[role=listbox] [role=option]"):
                эл = await pg.query_selector_all(селектор)
                for e in эл:
                    t = (await e.inner_text()).strip()
                    if t and len(t) < 120:
                        модели.append(t)
        except Exception as e:
            print("прокрутка не вышла:", str(e)[:80])

        if "--скрин" in sys.argv:
            await pg.screenshot(path="/home/user/research/direct-модели.png", full_page=True)
            print("скрин: research/direct-модели.png")
        print("текст страницы (%d симв.):" % len(текст))
        print(текст[:1200].replace("\n", " | "))
        print("\nНАЙДЕНО элементов модели:", len(модели))
        for m in dict.fromkeys(модели):
            print("  ", m)
        # полный HTML — если список не нашёлся, модели ищем в разметке
        html = await pg.content()
        if not модели:
            print("\n--- скан HTML на имена моделей ---")
            for пат in (r'"name"\s*:\s*"([^"]{2,60})"', r'"modelId"\s*:\s*"([^"]{2,60})"',
                        r'"slug"\s*:\s*"([^"]{2,60})"'):
                найдено = sorted(set(re.findall(пат, html)))
                print(пат, "->", len(найдено))
                print("   ", найдено[:60])
        await b.close()
        return модели


if __name__ == "__main__":
    asyncio.run(собрать())
