#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ХОД — один шаг переписки: дописать мой запрос и ответ агента в журнал (журнал.jsonl.gz).

  python3 память/ход.py --я "текст запроса пользователя" --а "текст ответа агента"
  python3 память/ход.py --я "..." --файл ответы/ХОД-60.md      # ответ из файла + ОБЯЗАТЕЛЬНЫЙ гейт

С хода 60 действует ПРАВИЛО ГЕЙТА (перенос Stop hook, см. память/гейт-ответа.py):
если пишется файл-ответ из папки `ответы/`, ход НЕ закрывается, пока гейт не вернёт код 0.
Аварийный обход только явным флагом --без-гейта "причина" (причина пишется в журнал).

Дописывает две записи в конец журнала в том же формате, что и остальные:
  н (номер), роль (Я/А), время, источник, симв, текст, хеш (sha256 текста), пред (хеш предыдущей записи).
Ничего не удаляет и не перезаписывает: только дозапись в конец gzip-потока.
"""
import argparse, datetime, gzip, hashlib, json, os, subprocess, sys

КОРЕНЬ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ЖУРНАЛ = os.path.join(os.path.dirname(os.path.abspath(__file__)), "журнал.jsonl.gz")
ГЕЙТ = os.path.join(КОРЕНЬ, "память", "гейт-ответа.py")


def текущий_ход():
    try:
        return open(os.path.join(КОРЕНЬ, "память", "текущий-ход.txt"), encoding="utf-8").read().strip() or "?"
    except OSError:
        return "?"


def гейт(путь, причина_обхода=""):
    """ОБЯЗАТЕЛЬНАЯ проверка перед записью ответа в журнал. Возвращает (можно_ли, пояснение)."""
    if not os.path.exists(ГЕЙТ):
        return True, "гейта нет на диске — пропускаю (записать долг)"
    ход = текущий_ход()
    р = subprocess.run([sys.executable, ГЕЙТ, путь, "--ход", ход], cwd=КОРЕНЬ,
                       capture_output=True, text=True)
    вывод = (р.stdout or "") + (р.stderr or "")
    if р.returncode == 0:
        return True, "гейт пройден (код 0)"
    if причина_обхода:
        return True, "ОБХОД ГЕЙТА: " + причина_обхода[:200]
    print("ХОД НЕ ЗАКРЫТ: гейт ответа вернул код %d" % р.returncode)
    for строка in вывод.strip().splitlines()[-6:]:
        print("  " + строка)
    print("Обход только явно: --без-гейта \"причина\"")
    return False, "гейт не пройден"


def записи():
    out = []
    with gzip.open(ЖУРНАЛ, "rt", encoding="utf-8") as f:
        for s in f:
            s = s.strip()
            if s:
                out.append(json.loads(s))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--я", default="")
    ap.add_argument("--а", default="")
    ap.add_argument("--файл", default="", help="путь к файлу с ПОЛНЫМ текстом ответа")
    ap.add_argument("--источник", default="arena")
    ap.add_argument("--пометка", default="", help="добавка к источнику, напр. «восстановлено 2026-…»")
    ap.add_argument("--без-гейта", default="", dest="без_гейта", help="аварийный обход гейта с причиной")
    a = ap.parse_args()
    if a.файл:
        try:
            a.а = open(a.файл, encoding="utf-8").read()
            a.источник = "полный ответ: " + a.файл
            if a.пометка:
                a.источник += " (" + a.пометка + ")"
        except Exception as e:
            print("не прочитал файл ответа:", e)
            return 1
    if not (a.я or a.а):
        print("нечего писать")
        return 1
    # ПРАВИЛО ГЕЙТА: ответ из папки ответы/ не попадает в журнал без кода 0
    if a.файл and os.sep + "ответы" + os.sep in os.path.abspath(a.файл) + os.sep:
        можно, пояснение = гейт(a.файл, a.без_гейта)
        if not можно:
            return 2
        print("ГЕЙТ ПЕРЕД ЗАПИСЬЮ: " + пояснение)
        if пояснение.startswith("ОБХОД"):
            a.источник += " [ОБХОД ГЕЙТА: " + a.без_гейта[:120] + "]"
    старые = записи()
    ном = max((з.get("н") or 0) for з in старые) if старые else 0
    пред = старые[-1].get("хеш", "") if старые else ""
    новые = []
    for роль, текст in (("user", a.я), ("assistant", a.а)):
        if not текст:
            continue
        ном += 1
        хеш = hashlib.sha256(текст.encode("utf-8")).hexdigest()
        новые.append({
            "н": ном, "роль": роль,
            "время": datetime.datetime.now().isoformat(timespec="seconds"),
            "источник": a.источник, "симв": len(текст), "текст": текст,
            "хеш": хеш, "пред": пред,
        })
        пред = хеш
    with gzip.open(ЖУРНАЛ, "at", encoding="utf-8") as f:
        for з in новые:
            f.write(json.dumps(з, ensure_ascii=False) + "\n")
    все = записи()
    print("дописано %d, теперь записей %d, последняя №%d" % (len(новые), len(все), ном))
    return 0


if __name__ == "__main__":
    sys.exit(main())
