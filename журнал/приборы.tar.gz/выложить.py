#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ВЫЛОЖИТЬ — закон 42: всё, что делает агент, автоматически уходит в хранилище.

Кладёт в репозиторий Ayt1741/hranilishe:
  журнал/журнал.jsonl.gz   — журнал переписки слово в слово (только если изменился)
  журнал/ответы-NN.md      — ответы ходов (только те, которых там нет)

Перед отправкой сверяет sha256 с тем, что уже лежит (api.github.com, без кэша):
совпало — не отправляет. Большой файл режется на части по 8 МБ
(журнал.jsonl.gz.часть1, .часть2 …) — GitHub API не принимает слишком большие
за один запрос, а склеить части можно командой cat.

  python3 выложить.py                 # выложить недостающее
  python3 выложить.py --только-ответы # без журнала (быстро)
  python3 выложить.py --что           # что будет выложено, ничего не отправляя

Коды: 0 всё на месте · 1 ошибка отправки · 2 нет токена (конфигурация)
"""
import argparse
import base64
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

БАЗА = os.path.dirname(os.path.abspath(__file__))
РЕПОЗИТОРИЙ = "Ayt1741/hranilishe"
ВЕТКА = "main"
ЧАСТЬ = 8 * 1024 * 1024          # 8 МБ на часть — с запасом под base64 и лимиты API
ЖУРНАЛ = os.path.join(БАЗА, "память", "журнал.jsonl.gz")
ОТВЕТЫ = os.path.join(БАЗА, "ответы")


def токен():
    путь = os.path.join(БАЗА, "память", "ключи.txt")
    if not os.path.exists(путь):
        return ""
    for строка in open(путь, encoding="utf-8"):
        if строка.strip().startswith("github="):
            return строка.strip().split("=", 1)[1]
    return ""


def sha_байт(б):
    return hashlib.sha256(б).hexdigest()


def blob_sha(б):
    """git-хэш блоба — именно его отдаёт api.github.com в поле sha (это НЕ sha256)."""
    return hashlib.sha1(b"blob %d\0" % len(б) + б).hexdigest()


def api_get(путь_в_репо, тк):
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"), ВЕТКА)
    r = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + тк, "User-Agent": "hranilishe-upload",
        "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(r, timeout=25) as о:
            return json.load(о)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def api_put(путь_в_репо, данные, тк, сообщение, старое_sha=None):
    url = "https://api.github.com/repos/%s/contents/%s" % (РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"))
    тело = {"message": сообщение, "content": base64.b64encode(данные).decode(), "branch": ВЕТКА}
    if старое_sha:
        тело["sha"] = старое_sha
    r = urllib.request.Request(url, data=json.dumps(тело).encode(), method="PUT", headers={
        "Authorization": "Bearer " + тк, "User-Agent": "hranilishe-upload",
        "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=120) as о:
        return json.load(о).get("content", {}).get("sha", "")[:12]


def api_raw(путь_в_репо, тк):
    """Скачать файл как есть (application/vnd.github.raw): до 100 МБ, без base64."""
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"), ВЕТКА)
    r = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + тк, "User-Agent": "hranilishe-upload",
        "Accept": "application/vnd.github.raw"})
    with urllib.request.urlopen(r, timeout=120) as о:
        return о.read()


def проверить():
    """Скачать всё обратно и сверить sha256 — «отправил» ещё не значит «лежит то же»."""
    тк = токен()
    if not тк:
        print("ОШИБКА КОНФИГУРАЦИИ: нет github= в память/ключи.txt")
        return 2
    задачи = план()
    print("сверяю скачанное с местным: файлов %d" % len(задачи))
    плохо = 0
    for путь, данные in задачи:
        try:
            обратно = api_raw(путь, тк)
        except Exception as e:
            плохо += 1
            print("  ✗ %-40s не скачалось: %s" % (путь, type(e).__name__))
            continue
        if sha_байт(обратно) == sha_байт(данные):
            print("  ✓ %-40s %9d б  sha256 %s…" % (путь, len(обратно), sha_байт(обратно)[:12]))
        else:
            плохо += 1
            print("  ✗ %-40s РАСХОЖДЕНИЕ: местно %s, в хранилище %s"
                  % (путь, sha_байт(данные)[:12], sha_байт(обратно)[:12]))
    print("\nИТОГ СВЕРКИ: совпало %d, расхождений %d" % (len(задачи) - плохо, плохо))
    return 0 if плохо == 0 else 1


def части(данные):
    return [данные[i:i + ЧАСТЬ] for i in range(0, len(данные), ЧАСТЬ)] or [b""]


def план():
    """Что отличается от хранилища: список (путь_в_репо, данные)."""
    задачи = []
    if os.path.exists(ЖУРНАЛ):
        местные = части(open(ЖУРНАЛ, "rb").read())
        for i, кусок in enumerate(местные, 1):
            задачи.append(("журнал/журнал.jsonl.gz.часть%d" % i, кусок))
    # ПОЛНАЯ лента действий: панель публикует только 200 последних (предел=200),
    # поэтому всё, что выпало из панели, уходит в хранилище отдельным файлом
    лента = os.path.join(БАЗА, "панель", "действия.jsonl")
    if os.path.exists(лента):
        задачи.append(("журнал/действия-все.jsonl", open(лента, "rb").read()))
    # контрольная точка — независимый свидетель: её кладём в хранилище,
    # чтобы обрезание журнала было видно даже если локальные файлы перепишут
    точка = os.path.join(БАЗА, "память", "точка.json")
    if os.path.exists(точка):
        задачи.append(("журнал/точка.json", open(точка, "rb").read()))
    сводка = os.path.join(БАЗА, "память", "сводка-журнала.txt")
    if os.path.exists(сводка):
        задачи.append(("журнал/сводка-журнала.txt", open(сводка, "rb").read()))
    if os.path.isdir(ОТВЕТЫ):
        for имя in sorted(os.listdir(ОТВЕТЫ)):
            if not имя.endswith(".md"):
                continue
            полный = os.path.join(ОТВЕТЫ, имя)
            задачи.append(("журнал/" + имя, open(полный, "rb").read()))
    return задачи


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--только_ответы", action="store_true")
    ap.add_argument("--что", action="store_true")
    ap.add_argument("--проверить", action="store_true")
    a = ap.parse_args()

    if a.проверить:
        return проверить()

    тк = токен()
    if not тк and not a.что:
        print("ОШИБКА КОНФИГУРАЦИИ: нет github= в память/ключи.txt")
        return 2

    задачи = план()
    if a.только_ответы:
        задачи = [з for з in задачи if "/ХОД-" in з[0] or "/ВСЕ-" in з[0]]
    print("к отправке проверяется файлов: %d" % len(задачи))

    отправлено, пропущено, ошибок = 0, 0, 0
    начало = time.time()
    for путь, данные in задачи:
        if a.что:
            print("  %-40s %9d б  sha256 %s…" % (путь, len(данные), sha_байт(данные)[:12]))
            continue
        try:
            текущий = api_get(путь, тк)
            if текущий and текущий.get("sha"):
                # в поле sha у GitHub лежит git-хэш блоба (sha1), не sha256
                свой = blob_sha(данные)
                if текущий["sha"] == свой:
                    пропущено += 1
                    continue
                новый = api_put(путь, данные, тк, "журнал: %s" % путь, текущий["sha"])
            else:
                новый = api_put(путь, данные, тк, "журнал: %s" % путь)
            отправлено += 1
            print("  ✓ %-40s %9d б → %s" % (путь, len(данные), новый))
        except Exception as e:
            ошибок += 1
            print("  ✗ %-40s %s: %s" % (путь, type(e).__name__, str(e)[:120]))

    if a.что:
        return 0
    print("\nИТОГ: отправлено %d, уже было %d, ошибок %d, время %.1f с"
          % (отправлено, пропущено, ошибок, time.time() - начало))
    return 0 if ошибок == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
