#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ВЫНЕСТИ — закон воркспейса (записи №31, №1925): в воркспейсе только нужное.

Дословно, как ты написал:
  №31   «после запроса в воркспейсе оставались лишь те файлы что ты мне даёшь
         конкретно после него что необходимы для продолжения работы, остальные
         чтобы ты всегда заливал в память чтобы воркспейс не переполнялся»
  №34   «уходит в память и удаляется. удаляется только в воркспейсе?
         нельзя чтобы удалялось абсолютно!»
  №1925 «нужно чтобы после запроса в воркспейсе оставались лишь нужные файлы,
         остальное заливать в память»

Порядок, который выполняет оба закона сразу (воркспейс чистый, байты не теряются):
  1. всё лишнее упаковывается в один архив с манифестом (sha256 каждого файла);
  2. архив выкладывается в хранилище по частям;
  3. архив скачивается ОБРАТНО и сверяется по sha256;
  4. каждая запись распаковывается и сверяется со своим sha256 до удаления;
  5. только после этого исходники убираются из воркспейса;
  6. всё записывается в память/вынесено.json — откуда и как вернуть.

  python3 вынести.py --что     # что будет вынесено (ничего не трогает)
  python3 вынести.py           # вынести
  python3 вынести.py --вернуть переписка/новый-файл.html   # вернуть из архива
  python3 вынести.py --проверить-возврат  # скачать архив и сверить ВСЕ файлы, не трогая воркспейс

Коды: 0 вынесено и проверено · 1 проверка не прошла (ничего не удалено) ·
      2 нет токена/сети (ничего не удалено)
"""
import argparse
import base64
import gzip
import hashlib
import io
import json
import os
import shutil
import sys
import tarfile
import time
import urllib.parse
import urllib.request

БАЗА = os.path.dirname(os.path.abspath(__file__))
КЛЮЧИ = os.path.join(БАЗА, "память", "ключи.txt")
УЧЁТ = os.path.join(БАЗА, "память", "вынесено.json")
РЕПОЗИТОРИЙ = "Ayt1741/hranilishe"
ВЕТКА = "main"
ЧАСТЬ = 8 * 1024 * 1024

# что оставляем в воркспейсе: только рабочее и то, что нужно для продолжения
ОСТАВИТЬ_ФАЙЛЫ = {
    "живо.sh", "ЗАКОНЫ.md", "КОНТРАКТ.md", "ОБЪЯСНЕНИЕ.md", "гейт-манифест.json",
}
ОСТАВИТЬ_КАТАЛОГИ = {"ответы", "research"}
# в research/ лежат и тяжелые артефакты советов (сырые планы/поиски) — их место в хранилище,
# в воркспейсе остаются только сводки (находки, СВОДКА, план, отчёт). Решение хода 60.
ТЯЖЁЛЫЕ_СОВЕТА = {"совет-60", "совет-ход55", "совет-ход58", "мои-поиски-55", "поиск-флот-52"}
РАБОЧИЕ_КАТАЛОГИ = {"флот"}
# пересобираемые файлы: их не надо ни хранить, ни считать лишними — они делаются
# одной командой из того, что уже лежит в памяти. Данные дороже снимка.
ВОССТАНОВИМОЕ = {
    "ПАНЕЛЬ.html": "python3 панель/собрать.py",
    "panel.html": "python3 панель/собрать.py",
}


def нужное(имя):
    if имя in ОСТАВИТЬ_ФАЙЛЫ or имя in ОСТАВИТЬ_КАТАЛОГИ or имя in РАБОЧИЕ_КАТАЛОГИ:
        return True
    if имя.endswith(".py"):                      # рабочие приборы
        return True
    if имя in ("память", "панель"):              # рабочая память и панель
        return True
    return False


def sha256_file(путь):
    h = hashlib.sha256()
    with open(путь, "rb") as ф:
        for кусок in iter(lambda: ф.read(1 << 20), b""):
            h.update(кусок)
    return h.hexdigest()


def кандидаты():
    out = []
    for имя in sorted(os.listdir(БАЗА)):
        if имя.startswith(".") or имя in ("__pycache__",):
            continue
        if нужное(имя) or имя in ВОССТАНОВИМОЕ:
            continue
        out.append(имя)
    # тяжёлые артефакты советов внутри research/
    р = os.path.join(БАЗА, "research")
    for имя in sorted(ТЯЖЁЛЫЕ_СОВЕТА):
        п = os.path.join(р, имя)
        if os.path.isdir(п):
            сумма = sum(os.path.getsize(os.path.join(к, ф)) for к, _, фс in os.walk(п) for ф in фс)
            if сумма > 2 * 1024 * 1024:  # только тяжёлое (>2 МБ)
                out.append(os.path.join("research", имя))
    return out


def токен():
    if not os.path.exists(КЛЮЧИ):
        return ""
    for строка in open(КЛЮЧИ, encoding="utf-8"):
        if строка.strip().startswith("github="):
            return строка.strip().split("=", 1)[1]
    return ""


def положить(путь_в_репо, данные, тк):
    url = "https://api.github.com/repos/%s/contents/%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"))
    есть = None
    try:
        r = urllib.request.Request(url + "?ref=" + ВЕТКА, headers={
            "Authorization": "Bearer " + тк, "User-Agent": "vynesti",
            "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(r, timeout=30) as о:
            есть = json.load(о).get("sha")
    except Exception:
        есть = None
    тело = {"message": "вынесено: " + путь_в_репо,
            "content": base64.b64encode(данные).decode(), "branch": ВЕТКА}
    if есть:
        тело["sha"] = есть
    r = urllib.request.Request(url, data=json.dumps(тело).encode(), method="PUT", headers={
        "Authorization": "Bearer " + тк, "User-Agent": "vynesti",
        "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=180) as о:
        return json.load(о).get("content", {}).get("sha", "")[:12]


def скачать(путь_в_репо, тк):
    url = "https://api.github.com/repos/%s/contents/%s?ref=%s" % (
        РЕПОЗИТОРИЙ, urllib.parse.quote(путь_в_репо, safe="/"), ВЕТКА)
    r = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + тк, "User-Agent": "vynesti",
        "Accept": "application/vnd.github.raw"})
    with urllib.request.urlopen(r, timeout=180) as о:
        return о.read()


def учёт():
    if os.path.exists(УЧЁТ):
        return json.load(open(УЧЁТ, encoding="utf-8"))
    return {"архивы": [], "файлы": {}}


def показать():
    сп = кандидаты()
    всего = 0
    print("к выносу (остаётся только рабочее):")
    for имя in сп:
        п = os.path.join(БАЗА, имя)
        р = os.path.getsize(п) if os.path.isfile(п) else sum(
            os.path.getsize(os.path.join(к, ф)) for к, _, фс in os.walk(п) for ф in фс)
        всего += р
        print("  %8.1f МБ  %s%s" % (р / 1048576, имя, "/" if os.path.isdir(п) else ""))
    print("итого к выносу: %.1f МБ" % (всего / 1048576))
    print("остаётся: приборы *.py, живо.sh, ЗАКОНЫ.md, КОНТРАКТ.md, гейт-манифест.json,"
          " память/, панель/, ответы/, research/")
    return 0


def вынести():
    сп = кандидаты()
    if not сп:
        print("выносить нечего: воркспейс уже содержит только рабочее")
        return 0
    тк = токен()
    if not тк:
        print("ОТКАЗ: нет токена github — ничего не тронуто (код 2)")
        return 2

    # 1. манифест и архив
    манифест = {}
    for имя in сп:
        п = os.path.join(БАЗА, имя)
        if os.path.isfile(п):
            манифест[имя] = {"размер": os.path.getsize(п), "sha256": sha256_file(п)}
        else:
            for корень, _, файлы in os.walk(п):
                for ф in файлы:
                    пу = os.path.join(корень, ф)
                    отн = os.path.relpath(пу, БАЗА)
                    манифест[отн] = {"размер": os.path.getsize(пу), "sha256": sha256_file(пу)}
    метка = time.strftime("%Y%m%d-%H%M%S")
    имя_архива = "архив-%s.tar.gz" % метка
    букв = os.path.join("/tmp", имя_архива)
    with tarfile.open(букв, "w:gz") as т:
        for имя in сп:
            т.add(os.path.join(БАЗА, имя), arcname=имя)
    данные = open(букв, "rb").read()
    хеш_архива = hashlib.sha256(данные).hexdigest()
    print("архив: %s, %.1f МБ (было %.1f МБ), sha256 %s…"
          % (имя_архива, len(данные) / 1048576,
             sum(м["размер"] for м in манифест.values()) / 1048576, хеш_архива[:12]))

    # 2. выкладка по частям
    части = [данные[i:i + ЧАСТЬ] for i in range(0, len(данные), ЧАСТЬ)] or [b""]
    пути = []
    for i, кусок in enumerate(части, 1):
        п = "журнал/вынесено/%s%s" % (имя_архива, (".часть%d" % i) if len(части) > 1 else "")
        ш = положить(п, кусок, тк)
        пути.append(п)
        print("  ↑ %s (%d б) → %s" % (п, len(кусок), ш))

    # 3. обратное скачивание и сверка
    склейка = b"".join(скачать(п, тк) for п in пути)
    if hashlib.sha256(склейка).hexdigest() != хеш_архива:
        print("ОТКАЗ: скачанное из хранилища не совпало с архивом. Ничего не удалено.")
        return 1
    print("  ✓ скачано из хранилища и совпало с архивом посимвольно")

    # 4. распаковка во временный каталог и сверка каждого файла
    вр = "/tmp/проверка-вынесенного"
    if os.path.exists(вр):
        shutil.rmtree(вр)
    os.makedirs(вр)
    with tarfile.open(fileobj=io.BytesIO(склейка), mode="r:gz") as т:
        т.extractall(вр)
    плохо = []
    for отн, м in манифест.items():
        п = os.path.join(вр, отн)
        if not os.path.exists(п) or sha256_file(п) != м["sha256"]:
            плохо.append(отн)
    if плохо:
        print("ОТКАЗ: не сошлись %d файлов (%s). Ничего не удалено."
              % (len(плохо), ", ".join(плохо[:5])))
        return 1
    print("  ✓ все %d файлов из архива совпали по sha256" % len(манифест))
    shutil.rmtree(вр)

    # 5. только теперь убираем из воркспейса
    for имя in сп:
        п = os.path.join(БАЗА, имя)
        if os.path.isdir(п):
            shutil.rmtree(п)
        else:
            os.remove(п)
    print("  ✓ убрано из воркспейса: %d объектов (байты в хранилище)" % len(сп))

    # 6. учёт: откуда вернуть
    у = учёт()
    у["архивы"].append({"архив": имя_архива, "части": пути, "sha256": хеш_архива,
                        "время": time.strftime("%Y-%m-%dT%H:%M:%S"), "файлов": len(манифест)})
    у["файлы"].update(манифест)
    json.dump(у, open(УЧЁТ, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("учёт: память/вынесено.json — %d файлов, %d архив(ов)" % (len(у["файлы"]), len(у["архивы"])))
    print("\nИТОГ: воркспейс очищен, байты сохранены и проверены дважды — код 0")
    return 0


def вернуть(путь):
    у = учёт()
    if путь not in у["файлы"]:
        print("нет такого файла в учёте: %s" % путь)
        return 1
    тк = токен()
    if not тк:
        print("ОТКАЗ: нет токена — вернуть не смогу (код 2)")
        return 2
    for арх in у["архивы"]:
        данные = b"".join(скачать(п, тк) for п in арх["части"])
        if hashlib.sha256(данные).hexdigest() != арх["sha256"]:
            print("ОТКАЗ: архив %s не совпал по sha256" % арх["архив"])
            return 1
        with tarfile.open(fileobj=io.BytesIO(данные), mode="r:gz") as т:
            try:
                уч = т.getmember(путь)
            except KeyError:
                continue
            т.extract(уч, БАЗА)
    п = os.path.join(БАЗА, путь)
    if os.path.exists(п) and sha256_file(п) == у["файлы"][путь]["sha256"]:
        print("вернул: %s (%d б), sha256 совпал" % (путь, у["файлы"][путь]["размер"]))
        return 0
    print("ОТКАЗ: после возврата файл не совпал")
    return 1


def проверить_возврат():
    """Доказательство обратимости: скачиваю архивы из хранилища, распаковываю во
    временный каталог и сверяю каждый перенесённый файл по sha256. Воркспейс не трогаю."""
    у = учёт()
    if not у["архивы"]:
        print("переносов ещё не было — проверять нечего")
        return 0
    тк = токен()
    if not тк:
        print("ОТКАЗ: нет токена — проверить возврат нечем (код 2)")
        return 2
    всего = 0
    for арх in у["архивы"]:
        данные = b"".join(скачать(п, тк) for п in арх["части"])
        if hashlib.sha256(данные).hexdigest() != арх["sha256"]:
            print("ОТКАЗ: %s не совпал по sha256" % арх["архив"])
            return 1
        вр = "/tmp/возврат-" + арх["архив"]
        if os.path.exists(вр):
            shutil.rmtree(вр)
        os.makedirs(вр)
        with tarfile.open(fileobj=io.BytesIO(данные), mode="r:gz") as т:
            т.extractall(вр)
        плохо = 0
        проверено = 0
        for отн, м in у["файлы"].items():
            п2 = os.path.join(вр, отн)
            if not os.path.exists(п2):
                continue
            проверено += 1
            if sha256_file(п2) != м["sha256"]:
                плохо += 1
                print("  ✗ %s" % отн)
        арх["размер"] = len(данные)
        всего += проверено
        print("  ✓ %s: скачан, распакован, сверено %d файлов, расхождений %d"
              % (арх["архив"], проверено, плохо))
        if плохо:
            return 1
        shutil.rmtree(вр)
    json.dump(у, open(УЧЁТ, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("ИТОГ: возврат доказан для %d файлов — ни один не потерян (закон #34)" % всего)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--что", action="store_true")
    ap.add_argument("--вернуть", default="")
    ap.add_argument("--проверить-возврат", action="store_true")
    a = ap.parse_args()
    if a.вернуть:
        return вернуть(a.вернуть)
    if a.проверить_возврат:
        return проверить_возврат()
    if a.что:
        return показать()
    return вынести()


if __name__ == "__main__":
    sys.exit(main())
